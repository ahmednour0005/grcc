<a href="javascript:void(0)" class="btn btn-sm btn-warning edit_answer_btn" data-id="<?php echo e($id); ?>" data-url="<?php echo e(route('admin.answers.edit',['question'=>$question_id,'answer'=>$id])); ?>"><i class="fa fa-edit fa-sm"></i><?php echo e(__('locale.Edit')); ?></a>
<a href="javascript:void(0)" class="btn btn-sm btn-danger delete_answer_btn" data-url="<?php echo e(route('admin.answers.destroy',['question'=>$question_id,'answer'=>$id])); ?>"><i class="fa fa-close fa-sm"></i> <?php echo e(__('locale.Delete')); ?></a>


<?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/admin/content/assessment/answers/actions.blade.php ENDPATH**/ ?>