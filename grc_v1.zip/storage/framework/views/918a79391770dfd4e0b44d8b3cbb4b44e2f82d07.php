

<?php $__env->startSection('title', __('asset.Assets')); ?>

<?php $__env->startSection('vendor-style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('fonts/fontawesome-6.2.1/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/toastr.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/pickers/pickadate/pickadate.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/forms/select/select2.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/pickers/pickadate/pickadate.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/animate/animate.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/sweetalert2.min.css'))); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-style'); ?>
    
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/base/plugins/extensions/ext-component-toastr.css'))); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/base/plugins/forms/pickers/form-flat-pickr.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/base/plugins/forms/pickers/form-flat-pickr.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/base/plugins/forms/pickers/form-pickadate.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css'))); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset(mix('vendors/css/forms/wizard/bs-stepper.min.css'))); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset(mix('css/base/plugins/forms/form-wizard.css'))); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- Advanced Search -->
    <?php if (isset($component)) { $__componentOriginal2011f880b337ea6f6538ee8d440aa358f08a856f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Content\Asset_management\Asset\Search::class, ['id' => 'advanced-search-datatable','assetValues' => $assetValues,'assetCategories' => $assetCategories,'locations' => $locations,'createModalID' => 'add-new-asset']); ?>
<?php $component->withName('asset-search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2011f880b337ea6f6538ee8d440aa358f08a856f)): ?>
<?php $component = $__componentOriginal2011f880b337ea6f6538ee8d440aa358f08a856f; ?>
<?php unset($__componentOriginal2011f880b337ea6f6538ee8d440aa358f08a856f); ?>
<?php endif; ?>
    <!--/ Advanced Search -->

    <!-- Create Form -->
    <?php if(auth()->user()->hasPermission('asset.create')): ?>
        <?php if (isset($component)) { $__componentOriginal24bd06e02ab5ae9b8c67effdddbb4c1410e460d0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Content\Asset_management\Asset\Form::class, ['id' => 'add-new-asset','title' => ''.e(__('locale.AddANewAsset')).'','assetValues' => $assetValues,'assetCategories' => $assetCategories,'assetEnvironmentCategories' => $assetEnvironmentCategories,'locations' => $locations,'teams' => $teams,'tags' => $tags,'operatingSystems' => $operatingSystems]); ?>
<?php $component->withName('asset-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal24bd06e02ab5ae9b8c67effdddbb4c1410e460d0)): ?>
<?php $component = $__componentOriginal24bd06e02ab5ae9b8c67effdddbb4c1410e460d0; ?>
<?php unset($__componentOriginal24bd06e02ab5ae9b8c67effdddbb4c1410e460d0); ?>
<?php endif; ?>
    <?php endif; ?>
    <!--/ Create Form -->

    <!-- Update Form -->
    <?php if(auth()->user()->hasPermission('asset.update')): ?>
        <?php if (isset($component)) { $__componentOriginal24bd06e02ab5ae9b8c67effdddbb4c1410e460d0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Content\Asset_management\Asset\Form::class, ['id' => 'edit-asset','title' => ''.e(__('locale.Edit Assets')).'','assetValues' => $assetValues,'assetCategories' => $assetCategories,'assetEnvironmentCategories' => $assetEnvironmentCategories,'locations' => $locations,'teams' => $teams,'tags' => $tags,'operatingSystems' => $operatingSystems]); ?>
<?php $component->withName('asset-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal24bd06e02ab5ae9b8c67effdddbb4c1410e460d0)): ?>
<?php $component = $__componentOriginal24bd06e02ab5ae9b8c67effdddbb4c1410e460d0; ?>
<?php unset($__componentOriginal24bd06e02ab5ae9b8c67effdddbb4c1410e460d0); ?>
<?php endif; ?>
    <?php endif; ?>
    <!--/ Update Form -->


    <div class="modal fade" id="exampleModalLong" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-fullscreen" role="document">
            <div class="modal-content">
                <div class="modal-header">

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <div class="modal-body">

                        <section class="modern-horizontal-wizard">
                            <div class="bs-stepper wizard-modern modern-wizard-example">
                                <div class="bs-stepper-header">
                                    <?php $__currentLoopData = $assetValueCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="step" data-target="#asset-value-<?php echo e($category->id); ?>" role="tab"
                                            id="asset-value-<?php echo e($category->id); ?>-trigger">
                                            <button type="button" class="step-trigger">
                                                <span class="bs-stepper-box">
                                                    <i data-feather="file-text" class="font-medium-3"></i>
                                                </span>
                                                <span class="bs-stepper-label">
                                                    <span class="bs-stepper-title"><?php echo e($category->name); ?></span>

                                                </span>
                                            </button>
                                        </div>

                                        <?php if(!$loop->last): ?>
                                            <div class="line">
                                                <i data-feather="chevron-right" class="font-medium-2"></i>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                                <div class="bs-stepper-content">

                                    <?php $__currentLoopData = $assetValueCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div id="asset-value-<?php echo e($category->id); ?>"
                                            class="content category-content <?php if($category->type == 1): ?> category-avg-content <?php endif; ?>"
                                            role="tabpanel" aria-labelledby="asset-value-<?php echo e($category->id); ?>-trigger">
                                            <div class="content-header">
                                                <h5 class="mb-0"><?php echo e($category->name); ?></h5>

                                            </div>
                                            <div class="row">
                                                <div class="col-12">
                                                    <?php $__currentLoopData = $category->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="row category-row">
                                                         <div class="mb-1 col-md-5">
                                                            <input type="text" class="form-control" value="<?php echo e($question->question); ?>" id="" readonly>
                                                            </div>
                                                            <?php if($category->type == 0): ?>
                                                                <div class="mb-1 col-md-5">
                                                                    <select class="select2 w-100 select-item">
                                                                        <option value="0"><?php echo e(__('locale.No')); ?>

                                                                        </option>
                                                                        <option value="1"><?php echo e(__('locale.Yes')); ?>

                                                                        </option>
                                                                    </select>
                                                                </div>
                                                                <div class="mb-1 col-md-1">
                                                                    <input type="text"
                                                                        class="form-control select-item-value"
                                                                        value="0" readonly>
                                                                </div>
                                                            <?php else: ?>
                                                                <div class="mb-1 col-md-6">
                                                                    <select class="select2 w-100 select-item">
                                                                        <?php $__currentLoopData = json_decode($question->answers, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($answer['value']); ?>">
                                                                                <?php echo e($answer['answer']); ?></option>
                                                                            <?php if($loop->first): ?>
                                                                                <?php
                                                                                    $firstValue = $answer['value'];
                                                                                ?>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </div>

                                                                <div class="mb-1 col-md-1">
                                                                    <input type="text"
                                                                        class="form-control select-item-value"
                                                                        value="<?php echo e($firstValue); ?>" readonly>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-7">
                                                    <input type="hidden" class="total-category-input-number">
                                                    <div class="alert alert-primary p-2 total-category-number"
                                                        role="alert">
                                                        <?php echo e(__('locale.Total')); ?> ( <?php echo e($category->name); ?> )
                                                        <?php echo e(__('locale.Number')); ?> : <span> </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php if($loop->last): ?>
                                                <div class="row">
                                                    <div class="col-7">
                                                        <input type="hidden" class="return-total-impact-input-number">
                                                        <div class="alert alert-primary p-2 total-impact-input-number"
                                                            role="alert">
                                                            <?php echo e(__('locale.businessImpactAnalysis')); ?> : <span> ( 0 )
                                                            </span>
                                                        </div>
                                                        <div class="alert alert-danger p-2 check-valid-impact d-none"
                                                            role="alert">
                                                            <span> <?php echo e(__('locale.not_invaild_value_please_check_again')); ?>

                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>


                                            <div class="d-flex justify-content-between">
                                                <?php if($loop->first): ?>
                                                    <button class="btn btn-outline-secondary btn-prev" disabled>
                                                        <i data-feather="arrow-left"
                                                            class="align-middle me-sm-25 me-0"></i>
                                                        <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('locale.Previous')); ?> </span>
                                                    </button>
                                                <?php else: ?>
                                                    <button class="btn btn-primary btn-prev">
                                                        <i data-feather="arrow-left"
                                                            class="align-middle me-sm-25 me-0"></i>
                                                        <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('locale.Previous')); ?> </span>
                                                    </button>
                                                <?php endif; ?>
                                                <?php if($loop->last): ?>
                                                    <button class="btn btn-primary  category-impact-submit"><?php echo e(__('locale.Save')); ?> </button>
                                                <?php else: ?>
                                                    <button class="btn btn-primary btn-next">
                                                        <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('locale.Next')); ?> </span>
                                                        <i data-feather="arrow-right"
                                                            class="align-middle ms-sm-25 ms-0"></i>
                                                    </button>
                                                <?php endif; ?>

                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </div>
                            </div>
                        </section>

                    </div>

                </div>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
    <script src="<?php echo e(asset('js/scripts/components/components-dropdowns-font-awesome.js')); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/buttons.print.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/forms/select/select2.full.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/picker.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/picker.date.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/picker.time.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/legacy.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/extensions/sweetalert2.all.min.js'))); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
    <script src="<?php echo e(asset(mix('js/scripts/forms/form-select2.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/extensions/toastr.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/forms/wizard/bs-stepper.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('js/scripts/forms/form-wizard.js'))); ?>"></script>
    <script>
        var assetValueLevels = <?php echo json_encode($assetValueLevels->toArray()); ?>;

        $(document).on('change', '.select-item', function() {
            $(this).parents('.category-row').find('.select-item-value').val($(this).val());
            updateCategoryTotalNumber($(this));
            totalImpactNumber();
        });

        function totalImpactNumber() {
            var maxVal = 0;
            $('.total-category-input-number').each(function(index, element) {
                var currentVal = parseInt($(this).val()) || 0;
                if (currentVal > maxVal) {
                    maxVal = currentVal;
                }
            });
            var correspondingObject = assetValueLevels.find(function(obj) {
                return obj.level == maxVal;
            });

            if (correspondingObject) {
                var correspondingName = correspondingObject.name;
                var correspondingId = correspondingObject.id;

                $('.total-impact-input-number span').text(' ( ' + maxVal + ' ) - ( ' + correspondingName + ' ) ');
                $('.asset_value_impact').val(' ( ' + maxVal + ' ) - ( ' + correspondingName + ' ) ');
                $('.return-total-impact-input-number').val(correspondingId);
                $('.check-valid-impact').addClass('d-none');
            } else {
                $('.asset_value_impact').val('');
                $('.total-impact-input-number span').text(maxVal);
                $('.return-total-impact-input-number').val('');

            }

        }

        function updateCategoryTotalNumber(_that) {
            var totalElement = _that.parents('.category-content').find('.total-category-number span');
            var inputElement = _that.parents('.category-content').find('.total-category-input-number');

            var isAvgContent = _that.parents('.category-content').hasClass('category-avg-content');

            var values = _that.parents('.category-content').find('.category-row .select-item-value');
            var total = 0;

            values.each(function() {
                total += parseInt($(this).val());
            });

            if (isAvgContent) {
                var average = total / values.length;
                var roundedAverage = Math.round(average);
                totalElement.text(' (  ' + roundedAverage + ' ) ');
                inputElement.val(roundedAverage);
            } else {
                totalElement.text(' ( ' + total + ' ) ');
                inputElement.val(total);
            }
        }

        $(document).on('click', '.category-impact-submit', function() {

            valId = $('.return-total-impact-input-number').val();

            if (valId != '') {
                $('.check-valid-impact').addClass('d-none');
                totalImpactNumber();
                $('.asset_value_impact_level').val(valId);
                $('#exampleModalLong').modal('hide');

            } else {
                $('.check-valid-impact').removeClass('d-none');

            }


        });

        // Example of calling the function
        // Pass the element that triggered the update (e.g., a button or select)
        var buttonElement = $('.example-button');
        updateCategoryTotalNumber(buttonElement);




        
    </script>
    
    <script>
        const verifiedTranslation = "<?php echo e(__('locale.Verified')); ?>",
            UnverifiedAssetsTranslation = "<?php echo e(__('asset.UnverifiedAssets')); ?>",
            customDay = "<?php echo e(trans_choice('locale.custom_days', 1)); ?>",
            customDays = "<?php echo e(trans_choice('locale.custom_days', 3)); ?>",
            assetInQuery = "<?php echo e($assetInQuery); ?>";

        var permission = [],
            lang = [],
            URLs = [];
        permission['edit'] = <?php echo e(auth()->user()->hasPermission('asset.update')? 1: 0); ?>;
        permission['delete'] = <?php echo e(auth()->user()->hasPermission('asset.delete')? 1: 0); ?>;

        lang['DetailsOfItem'] = "<?php echo e(__('locale.DetailsOfItem', ['item' => __('asset.asset')])); ?>";

        URLs['ajax_list'] = "<?php echo e(route('admin.asset_management.ajax.index')); ?>";
    </script>

    <script src="<?php echo e(asset('ajax-files/asset_management/asset/index.js')); ?>"></script>

    <script>
        // Submit form for creating asset
        $('#add-new-asset form').submit(function(e) {
            e.preventDefault();
            $.ajax({
                url: $(this).attr('action'),
                type: "POST",
                data: $(this).serialize(),
                success: function(data) {
                    if (data.status) {
                        makeAlert('success', data.message, "<?php echo e(__('locale.Success')); ?>");
                        $('#add-new-asset').modal('hide');
                        redrawDatatable();
                    } else {
                        showError(data['errors']);
                    }
                },
                error: function(response, data) {
                    responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "<?php echo e(__('locale.Error')); ?>");
                    showError(responseData.errors);
                }
            });
        });

        // Submit form for editing asset
        $('#edit-asset form').submit(function(e) {
            e.preventDefault();
            const id = $(this).find('input[name="id"]').val();
            let url = "<?php echo e(route('admin.asset_management.ajax.update', ':id')); ?>";
            url = url.replace(':id', id);
            $.ajax({
                url: url,
                type: "PUT",
                data: $(this).serialize(),
                success: function(data) {
                    if (data.status) {
                        makeAlert('success', data.message, "<?php echo e(__('locale.Success')); ?>");
                        $('#edit-asset form').trigger("reset");
                        $('#edit-asset').modal('hide');
                        redrawDatatable();
                    } else {
                        showError(data['errors']);
                    }
                },
                error: function(response, data) {
                    responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "<?php echo e(__('locale.Error')); ?>");
                    showError(responseData.errors);
                }
            });
        });

        function DeleteAsset(id) {
            let url = "<?php echo e(route('admin.asset_management.ajax.destroy', ':id')); ?>";
            url = url.replace(':id', id);
            $.ajax({
                url: url,
                type: "DELETE",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(data) {
                    if (data.status) {
                        makeAlert('success', data.message, "<?php echo e(__('locale.Success')); ?>");
                        redrawDatatable();
                    }
                },
                error: function(response, data) {
                    responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "<?php echo e(__('locale.Error')); ?>");
                }
            });
        }

        // Show modal for editing
        function ShowModalEditAsset(id) {
            let url = "<?php echo e(route('admin.asset_management.ajax.edit', ':id')); ?>";
            url = url.replace(':id', id);
            $.ajax({
                url: url,
                type: "GET",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response.status) {
                        const editForm = $("#edit-asset form");

                        // Start Assign asset data to modal
                        editForm.find('input[name="id"]').val(id);
                        editForm.find("input[name='name']").val(response.data.name);
                        editForm.find("input[name='ip']").val(response.data.ip);
                        editForm.find(
                                `select[name='asset_value_id'] option[value='${response.data.asset_value_id}']`)
                            .attr('selected', true).trigger('change');
                        editForm.find(
                                `select[name='asset_category_id'] option[value='${response.data.asset_category_id}']`
                            )
                            .attr('selected', true).trigger('change');
                            editForm.find(
                                `select[name='asset_environment_category_id'] option[value='${response.data.asset_environment_category_id}']`
                            )
                            .attr('selected', true).trigger('change');
                            editForm.find(
                                `select[name='os'] option[value='${response.data.os}']`
                            )
                            .attr('selected', true).trigger('change');
                             editForm.find(
                                `select[name='physical_virtual_type'] option[value='${response.data.physical_virtual_type}']`
                            )
                            .attr('selected', true).trigger('change');

                        editForm.find(`select[name='location_id'] option[value='${response.data.location_id}']`)
                            .attr('selected', true).trigger('change');
                        response.data.teams.forEach(teamId => {
                            editForm.find(`select[name='teams[]'] option[value='${teamId}']`).attr(
                                'selected', true).trigger('change');
                        });
                        response.data.tags.forEach(tagId => {
                            editForm.find(`select[name='tags[]'] option[value='${tagId}']`).attr(
                                'selected', true).trigger('change');
                        });

                        editForm.find("input[name='expiration_date']").val(response.data.expiration_date);
                        editForm.find("input[name='start_date']").val(response.data.start_date);
                        editForm.find("input[name='alert_period']").val(response.data.alert_period);
                        editForm.find("textarea[name='details']").val(response.data.details);
                        editForm.find("input[name='url']").val(response.data.url);
                        editForm.find("input[name='os_version']").val(response.data.os_version);
                        editForm.find("input[name='owner_email']").val(response.data.owner_email);
                        editForm.find("input[name='owner_manager_email']").val(response.data.owner_manager_email);
                        editForm.find("input[name='project_vlan']").val(response.data.project_vlan);
                        editForm.find("input[name='vlan']").val(response.data.vlan);
                        editForm.find("input[name='vendor_name']").val(response.data.vendor_name);
                        editForm.find("input[name='model']").val(response.data.model);
                        editForm.find("input[name='firmware']").val(response.data.firmware);
                        editForm.find("input[name='rack_location']").val(response.data.rack_location);
                        editForm.find("input[name='city']").val(response.data.city);
                        editForm.find("input[name='mac_address']").val(response.data.mac_address);
                        editForm.find("input[name='subnet_mask']").val(response.data.subnet_mask);
                        editForm.find("input[name='verified']").attr('checked', response.data.verified);
                        if (response.data.verified) {
                            editForm.find("input[name='verified']").attr('checked', true);
                        } else {
                            editForm.find("input[name='verified']").attr('checked', false);
                        }
                        var correspondingObject = assetValueLevels.find(function(obj) {
                            return obj.id == response.data.asset_value_level_id;
                        });

                        if (correspondingObject) {
                            var correspondingName = correspondingObject.name;
                            var correspondingLevel = correspondingObject.level;
                            editForm.find(".asset_value_impact").val(' ( ' + correspondingLevel + ' ) - ( ' +
                                correspondingName + ' ) ');
                        } else {
                            editForm.find(".asset_value_impact").val('');
                        }
                        editForm.find("input[name='asset_value']").val(response.data.asset_value_level_id);

                        // End Assign asset data to modal
                        $('.dtr-bs-modal').modal('hide');
                        $('#edit-asset').modal('show');
                    }
                    // alert(1);
                },
                error: function(response, data) {
                    responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "<?php echo e(__('locale.Error')); ?>");
                }
            });
        }

        // Show delete alert modal
        function ShowModalDeleteAsset(id) {
            $('.dtr-bs-modal').modal('hide');
            Swal.fire({
                title: "<?php echo e(__('locale.AreYouSureToDeleteThisRecord')); ?>",
                text: '<?php echo app('translator')->get('locale.YouWontBeAbleToRevertThis'); ?>',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: "<?php echo e(__('locale.ConfirmDelete')); ?>",
                cancelButtonText: "<?php echo e(__('locale.Cancel')); ?>",
                customClass: {
                    confirmButton: 'btn btn-relief-success ms-1',
                    cancelButton: 'btn btn-outline-danger ms-1'
                },
                buttonsStyling: false
            }).then(function(result) {
                if (result.value) {
                    DeleteAsset(id);
                }
            });
        }

        // Reset form
        function resetFormData(form) {
            $('.error').empty();
            form.trigger("reset")
            form.find('input:not([name="_token"])').val('');
            form.find('select.multiple-select2 option[selected]').attr('selected', false);
            form.find('select.select2 option').attr('selected', false);
            form.find("select.select2").each(function(index) {
                $(this).find('option').first().attr('selected', true);
            });
            form.find('select').trigger('change');
        }

        $('.modal').on('hidden.bs.modal', function() {
            resetFormData($(this).find('form'));
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/admin/content/asset_management/asset/index.blade.php ENDPATH**/ ?>