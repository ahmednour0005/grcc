

<?php $__env->startSection('title', __('vulnerability.VulnerabilityManagement')); ?>

<?php $__env->startSection('vendor-style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('fonts/fontawesome-6.2.1/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/toastr.min.css'))); ?>">
<link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css'))); ?>">
<link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css'))); ?>">

<link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css'))); ?>">
<link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/forms/select/select2.min.css'))); ?>">
<link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/animate/animate.min.css'))); ?>">
<link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/sweetalert2.min.css'))); ?>">
<link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css'))); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/base/plugins/forms/pickers/form-flat-pickr.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset(mix('css/base/plugins/forms/pickers/form-flat-pickr.css'))); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-style'); ?>
<link rel="stylesheet" href="<?php echo e(asset(mix('css/base/plugins/extensions/ext-component-toastr.css'))); ?>">
<link rel="stylesheet" href="<?php echo e(asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css'))); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- Advanced Search -->
<?php if (isset($component)) { $__componentOriginal94dc115c656322ed17f355205320c5f918b3d531 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Content\Vulnerability_management\Search::class, ['id' => 'advanced-search-datatable','assets' => $assets,'teams' => $teams,'createModalID' => 'add-new-vulnerability-management']); ?>
<?php $component->withName('vulnerability-management-search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal94dc115c656322ed17f355205320c5f918b3d531)): ?>
<?php $component = $__componentOriginal94dc115c656322ed17f355205320c5f918b3d531; ?>
<?php unset($__componentOriginal94dc115c656322ed17f355205320c5f918b3d531); ?>
<?php endif; ?>
<!--/ Advanced Search -->

<!-- Create Form -->
<?php if(auth()->user()->hasPermission('vulnerability_management.create')): ?>
<?php if (isset($component)) { $__componentOriginal0d05d6236e8ef9384bf7d351a0b742c5d025ef9f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Content\Vulnerability_management\Form::class, ['id' => 'add-new-vulnerability-management','assets' => $assets,'teams' => $teams,'ips' => $ips,'title' => ''.e(__('vulnerability.AddANewVulnerability')).'']); ?>
<?php $component->withName('vulnerability-management-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0d05d6236e8ef9384bf7d351a0b742c5d025ef9f)): ?>
<?php $component = $__componentOriginal0d05d6236e8ef9384bf7d351a0b742c5d025ef9f; ?>
<?php unset($__componentOriginal0d05d6236e8ef9384bf7d351a0b742c5d025ef9f); ?>
<?php endif; ?>
<?php endif; ?>
<!--/ Create Form -->

<!-- Update Form -->
<?php if(auth()->user()->hasPermission('vulnerability_management.update')): ?>
<?php if (isset($component)) { $__componentOriginal0d05d6236e8ef9384bf7d351a0b742c5d025ef9f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Content\Vulnerability_management\Form::class, ['id' => 'edit-vulnerability-management','assets' => $assets,'teams' => $teams,'ips' => $ips,'title' => ''.e(__('vulnerability.EditVulnerability')).'']); ?>
<?php $component->withName('vulnerability-management-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0d05d6236e8ef9384bf7d351a0b742c5d025ef9f)): ?>
<?php $component = $__componentOriginal0d05d6236e8ef9384bf7d351a0b742c5d025ef9f; ?>
<?php unset($__componentOriginal0d05d6236e8ef9384bf7d351a0b742c5d025ef9f); ?>
<?php endif; ?>
<?php endif; ?>

<!--/ Update Form -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<script src="<?php echo e(asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js'))); ?>"></script>
<script src="<?php echo e(asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js'))); ?>"></script>
<script src="<?php echo e(asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js'))); ?>"></script>
<script src="<?php echo e(asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.js'))); ?>"></script>
<script src="<?php echo e(asset(mix('vendors/js/tables/datatable/buttons.print.min.js'))); ?>"></script>
<script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js'))); ?>"></script>
<script src="<?php echo e(asset(mix('vendors/js/forms/select/select2.full.min.js'))); ?>"></script>
<script src="<?php echo e(asset(mix('vendors/js/extensions/sweetalert2.all.min.js'))); ?>"></script>
<script src="<?php echo e(asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js'))); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-script'); ?>

<script src="<?php echo e(asset(mix('vendors/js/extensions/toastr.min.js'))); ?>"></script>
<script>
    permission = [];
    permission['edit'] = <?php echo e(auth()->user()->hasPermission('vulnerability_management.update')? 1 : 0); ?>;
    permission['delete'] = <?php echo e(auth()->user()->hasPermission('vulnerability_management.delete')? 1 : 0); ?>;

    const lang = []
        URLs = [];

        URLs['ajax_list'] = "<?php echo e(route('admin.vulnerability_management.ajax.index')); ?>";
        URLs['update'] = "<?php echo e(route('admin.vulnerability_management.ajax.update', ':id')); ?>";
        URLs['delete'] = "<?php echo e(route('admin.vulnerability_management.ajax.destroy', ':id')); ?>";
        URLs['edit'] = "<?php echo e(route('admin.vulnerability_management.ajax.edit', ':id')); ?>";
        URLs['get_ip_assets'] = "<?php echo e(route('admin.vulnerability_management.ajax.getIpAssets')); ?>";

        lang['user'] = "<?php echo e(__('locale.User')); ?>";
        lang['confirmDelete'] = "<?php echo e(__('locale.ConfirmDelete')); ?>";
        lang['cancel'] = "<?php echo e(__('locale.Cancel')); ?>";
        lang['success'] = "<?php echo e(__('locale.Success')); ?>";
        lang['error'] = "<?php echo e(__('locale.Error')); ?>";
        lang['confirmDeleteFileMessage'] = "<?php echo e(__('locale.AreYouSureToDeleteThisFile')); ?>";
        lang['confirmDeleteRecordMessage'] = "<?php echo e(__('locale.AreYouSureToDeleteThisRecord')); ?>";
        lang['revert'] = "<?php echo e(__('locale.YouWontBeAbleToRevertThis')); ?>";
        lang['Open'] = "<?php echo e(__('locale.Open')); ?>";
        lang['Closed'] = "<?php echo e(__('locale.Closed')); ?>";
        lang['In Progress'] = "<?php echo e(__('locale.In Progress')); ?>";
lang['Overdue'] = "<?php echo e(__('locale.Overdue')); ?>";
        lang['Critical'] = "<?php echo e(__('locale.Critical')); ?>";
        lang['High'] = "<?php echo e(__('locale.High')); ?>";
        lang['Medium'] = "<?php echo e(__('locale.Medium')); ?>";
        lang['Low'] = "<?php echo e(__('locale.Low')); ?>";
        lang['Informational'] = "<?php echo e(__('locale.Informational')); ?>";
        lang['DetailsOfItem'] = "<?php echo e(__('locale.DetailsOfItem', ['item' => __('vulnerability.VulnerabilityManagement')])); ?>";
        lang['selectOption'] = "<?php echo e(__('locale.select-option')); ?>";
</script>

<script src="<?php echo e(asset('ajax-files/vulnerability_management/index.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/admin/content/vulnerability_management/index.blade.php ENDPATH**/ ?>