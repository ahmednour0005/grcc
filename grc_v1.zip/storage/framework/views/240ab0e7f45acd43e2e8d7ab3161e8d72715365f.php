<?php if($paginator->hasPages()): ?>
    <nav>
        <ul class="pagination custom">
            
            <?php if($paginator->onFirstPage()): ?>
                <li class="disabled" aria-disabled="true">
                    <span class="btn btn-primary disabled" style="width: 30px;height: 25px;text-align: center;padding: 5px">&#8249;</span>
                </li>
            <?php else: ?>
                <li>
                    <a class="btn btn-primary " style="width: 30px;height: 25px;text-align: center;padding: 5px" onclick="event.preventDefault()" data-url="<?php echo e($paginator->previousPageUrl()); ?>" href="javascript:void(0)" rel="prev"> &#8249; </a>
                </li>
            <?php endif; ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li>
                    <a class="btn btn-primary  " style="width: 30px;height: 25px;text-align: center;padding: 5px;" onclick="event.preventDefault()" data-url="<?php echo e($paginator->nextPageUrl()); ?>" href="javascript:void(0)" rel="next"> &#8250; </a>
                </li>
            <?php else: ?>
                <li class="disabled" aria-disabled="true">
                    <span class="btn btn-primary disabled " style="width: 30px;height: 25px;text-align: center;padding: 5px;">&#8250; </span>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?>
<?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/vendor/pagination/simple-default.blade.php ENDPATH**/ ?>