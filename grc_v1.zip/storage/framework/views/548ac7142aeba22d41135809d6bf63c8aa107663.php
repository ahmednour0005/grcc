<div class="modal modal-slide-in basic-select2 fade bootstrap-select" id="<?php echo e($id); ?>">
    <div class="modal-dialog sidebar-sm">
        <form action="<?php echo e(route('admin.asset_management.ajax.store')); ?>" method="POST" class="modal-content pt-0">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id">
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">×</button>
            <div class="modal-header mb-1">
                <h5 class="modal-title"><?php echo e($title); ?></h5>
            </div>
            <div class="modal-body flex-grow-1">
                
                <div class="mb-1">
                    <label class="form-label"><?php echo e(__('asset.AssetName')); ?></label>
                    <input type="text" name="name" class="form-control dt-post"
                        aria-label="<?php echo e(__('asset.AssetName')); ?>" required />
                    <span class="error error-name "></span>
                </div>
                
                <div class="mb-1">
                    <label class="form-label"><?php echo e(__('locale.IPAddress')); ?></label>
                    <input type="text" name="ip" minlength="7" maxlength="15" size="15"
                        pattern="^((\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.){3}(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$"
                        class="form-control dt-post" aria-label="<?php echo e(__('locale.IPAddress')); ?>"
                        oninvalid="this.setCustomValidity(`<?php echo e(__('locale.IPFormatNotRecognized')); ?>`)"
                        oninput="this.setCustomValidity('')" />
                    <span class="error error-ip "></span>
                </div>
                
                
                <input type="hidden" name="asset_value" class="asset_value_impact_level">
                <div class="mb-1">
                    <label class="form-label "><?php echo e(__('asset.AssetValue')); ?></label>
                    <div class="input-group">
                        <input type="text" class="form-control asset_value_impact"
                            placeholder="<?php echo e(__('asset.AssetValue')); ?>" aria-describedby="button-addon2" readonly
                            required>
                        <div class="input-group-append" id="button-addon2">
                            
                            <button type="button" class="btn btn-outline-primary waves-effect" data-bs-toggle="modal"
                                data-bs-target="#exampleModalLong"><?php echo e(__('locale.Calculate')); ?></button>
                        </div>
                    </div>
                    <span class="error error-asset_value"></span>
                </div>
                
                <div class="mb-1">
                    <label class="form-label "><?php echo e(__('locale.AssetCategory')); ?></label>
                    <select class="select2 form-select" name="asset_category_id" required>
                        <option value="" disabled hidden selected><?php echo e(__('locale.select-option')); ?></option>
                        <?php $__currentLoopData = $assetCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assetCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($assetCategory->id); ?>"><?php echo e($assetCategory->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="error error-asset_category_id"></span>
                </div>
                
                <div class="mb-1">
                    <label class="form-label "><?php echo e(__('locale.AssetEnvironmentCategory')); ?></label>
                    <select class="select2 form-select" name="asset_environment_category_id" >
                        <option value="" selected><?php echo e(__('locale.select-option')); ?></option>
                        <?php $__currentLoopData = $assetEnvironmentCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assetEnvironmentCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($assetEnvironmentCategory->id); ?>"><?php echo e($assetEnvironmentCategory->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="error error-asset_environment_category_id"></span>
                </div>


                
                <div class="mb-1">
                    <label class="form-label"> <?php echo e(__('locale.Teams')); ?></label>
                    <select name="teams[]" class="form-select multiple-select2" multiple="multiple">
                        <option value="" disabled hidden><?php echo e(__('locale.select-option')); ?></option>
                        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($team->id); ?>"><?php echo e($team->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="error error-teams "></span>
                </div>
                
                <div class="mb-1">
                    <label class="form-label"> <?php echo e(__('locale.Tags')); ?></label>
                    <select name="tags[]" class="form-select multiple-select2" multiple="multiple">
                        <option value="" disabled hidden><?php echo e(__('locale.select-option')); ?></option>
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->tag); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="error error-tags "></span>
                </div>
                
                <div class=" mb-1">
                    <label class="form-label" for="fp-default"> <?php echo e(__('locale.StartDate')); ?></label>
                    <input name="start_date" class="form-control flatpickr-date-time-compliance"
                        placeholder="YYYY-MM-DD" />
                    <span class="error error-start_date "></span>
                </div>
                
                <div class=" mb-1">
                    <label class="form-label" for="fp-default"> <?php echo e(__('locale.EndDate')); ?></label>
                    <input name="expiration_date" class="form-control flatpickr-date-time-compliance"
                        placeholder="YYYY-MM-DD" />
                    <span class="error error-expiration_date "></span>
                </div>
                
                <div class=" mb-1">
                    <label class="form-label" for="fp-default"> <?php echo e(__('locale.alert_period')); ?>

                        (<?php echo e(__('locale.days')); ?>)</label>
                    <input type="number" min="1" name="alert_period" class="form-control" />
                    <span class="error error-alert_period "></span>
                </div>


                
                <div class="mb-1">
                    <label class="form-label"><?php echo e(__('asset.AssetUrl')); ?></label>
                    <input type="url" name="url" class="form-control "
                        aria-label="<?php echo e(__('asset.AssetUrl')); ?>"  />
                    <span class="error error-url "></span>
                </div>

                
                <div class="mb-1">
                    <label class="form-label "><?php echo e(__('locale.so')); ?></label>
                    <select class="select2 form-select" name="os" >
                        <option value="" selected><?php echo e(__('locale.select-option')); ?></option>
                        <?php $__currentLoopData = $operatingSystems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operatingSystem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($operatingSystem->id); ?>"><?php echo e($operatingSystem->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="error error-os"></span>
                </div>

                
                <div class="mb-1">
                    <label class="form-label"><?php echo e(__('asset.AssetOsVersion')); ?></label>
                    <input type="text" name="os_version" class="form-control "
                        aria-label="<?php echo e(__('asset.Assetos_version')); ?>"  />
                    <span class="error error-os_version "></span>
                </div>

                
                <div class="mb-1">
                    <label class="form-label "><?php echo e(__('locale.physical_virtual_type')); ?></label>
                    <select class="select2 form-select" name="physical_virtual_type" >
                        <option value="" selected><?php echo e(__('locale.select-option')); ?></option>
                        <option value="0"><?php echo e(__('locale.Virtual')); ?> </option>
                        <option value="1"><?php echo e(__('locale.Physical')); ?> </option>
                    </select>
                    <span class="error error-physical_virtual_type"></span>
                </div>

                
                <div class="mb-1">
                    <label class="form-label"><?php echo e(__('asset.owner_email')); ?></label>
                    <input type="email" name="owner_email" class="form-control "
                        aria-label="<?php echo e(__('asset.owner_email')); ?>"  />
                    <span class="error error-owner_email "></span>
                </div>

                
                <div class="mb-1">
                    <label class="form-label"><?php echo e(__('asset.owner_manager_email')); ?></label>
                    <input type="email" name="owner_manager_email" class="form-control "
                        aria-label="<?php echo e(__('asset.owner_manager_email')); ?>"  />
                    <span class="error error-owner_manager_email "></span>
                </div>

                
                <div class="mb-1">
                    <label class="form-label"><?php echo e(__('asset.project_vlan')); ?></label>
                    <input type="text" name="project_vlan" class="form-control "
                        aria-label="<?php echo e(__('asset.project_vlan')); ?>"  />
                    <span class="error error-project_vlan "></span>
                </div>

                
                <div class="mb-1">
                    <label class="form-label"><?php echo e(__('asset.vlan')); ?></label>
                    <input type="text" name="vlan" class="form-control " aria-label="<?php echo e(__('asset.vlan')); ?>"
                         />
                    <span class="error error-vlan "></span>
                </div>

                
                <div class="mb-1">
                    <label class="form-label"><?php echo e(__('asset.vendor_name')); ?></label>
                    <input type="text" name="vendor_name" class="form-control "
                        aria-label="<?php echo e(__('asset.vendor_name')); ?>"  />
                    <span class="error error-vendor_name "></span>
                </div>

                
                <div class="mb-1">
                    <label class="form-label"><?php echo e(__('asset.model')); ?></label>
                    <input type="text" name="model" class="form-control " aria-label="<?php echo e(__('asset.model')); ?>"
                         />
                    <span class="error error-model "></span>
                </div>

                
                <div class="mb-1">
                    <label class="form-label"><?php echo e(__('asset.firmware')); ?></label>
                    <input type="text" name="firmware" class="form-control "
                        aria-label="<?php echo e(__('asset.firmware')); ?>"  />
                    <span class="error error-firmware "></span>
                </div>

                
                <div class="mb-1">
                    <label class="form-label "><?php echo e(__('asset.AssetSiteLocation')); ?></label>
                    <select class="select2 form-select" name="location_id">
                        <option value="" disabled hidden selected><?php echo e(__('locale.select-option')); ?></option>
                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($location->id); ?>"><?php echo e($location->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="error error-location_id"></span>
                </div>

                
                <div class="mb-1">
                    <label class="form-label"><?php echo e(__('asset.rack_location')); ?></label>
                    <input type="text" name="rack_location" class="form-control "
                        aria-label="<?php echo e(__('asset.rack_location')); ?>"  />
                    <span class="error error-rack_location "></span>
                </div>


                
                <div class="mb-1">
                    <label class="form-label"><?php echo e(__('asset.city')); ?></label>
                    <input type="text" name="city" class="form-control " aria-label="<?php echo e(__('asset.city')); ?>"
                         />
                    <span class="error error-city "></span>
                </div>

                
                <div class="mb-1">
                    <label class="form-label"><?php echo e(__('asset.mac_address')); ?></label>
                    <input type="text" name="mac_address" class="form-control "
                        aria-label="<?php echo e(__('asset.mac_address')); ?>"  />
                    <span class="error error-mac_address "></span>
                </div>

                
                <div class="mb-1">
                    <label class="form-label"><?php echo e(__('asset.subnet_mask')); ?></label>
                    <input type="text" name="subnet_mask" class="form-control "
                        aria-label="<?php echo e(__('asset.subnet_mask')); ?>"  />
                    <span class="error error-subnet_mask "></span>
                </div>

                
                <div class="mb-1">
                    <label class="form-label"
                        for="exampleFormControlTextarea1"><?php echo e(__('asset.AssetDetails')); ?></label>
                    <textarea class="form-control" name="details" rows="3"></textarea>
                    <span class="error error-details "></span>
                </div>

                
                <div class=" mb-1">
                    <div class="d-flex flex-column">
                        <label class="form-label"> <?php echo e(__('asset.VerifiedAssets')); ?></label>
                        <div class="form-check form-switch form-check-success">
                            <input type="checkbox" name="verified" class="form-check-input" id="customSwitch111" />
                            <label class="form-check-label" for="customSwitch111">
                                <span class="switch-icon-left"><i data-feather="check"></i></span>
                                <span class="switch-icon-right"><i data-feather="x"></i></span>
                            </label>
                        </div>
                    </div>
                </div>


                <button type="Submit" class="btn btn-primary data-submit me-1"> <?php echo e(__('locale.Submit')); ?></button>
                <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    <?php echo e(__('locale.Cancel')); ?></button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/components/admin/content/asset_management/asset/form.blade.php ENDPATH**/ ?>