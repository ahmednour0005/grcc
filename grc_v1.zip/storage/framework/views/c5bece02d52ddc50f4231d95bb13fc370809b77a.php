<section id="<?php echo e($id); ?>">
    <div class="row">
        <div class="col-12">
            <div class="card">

                <div class="card-header border-bottom p-1">
                    <div class="head-label">
                        <h4 class="card-title"><?php echo e(__('locale.FilterBy')); ?></h4>
                    </div>
                    <div class="dt-action-buttons text-end">
                        <div class="dt-buttons d-inline-flex">
                            <?php if(auth()->user()->hasPermission('vulnerability_management.create')): ?>
                                <button class="dt-button btn btn-primary me-2" type="button" data-bs-toggle="modal"
                                    data-bs-target="#<?php echo e($createModalID); ?>">
                                    <?php echo e(__('vulnerability.AddANewVulnerability')); ?>

                                </button>
                            <?php endif; ?>
                            <?php if(auth()->user()->hasPermission('vulnerability_management.create')): ?>
                                <a href="<?php echo e(route('admin.vulnerability_management.notificationsSettings')); ?>"
                                    class="dt-button btn btn-primary me-2" target="_self">
                                    <?php echo e(__('locale.NotificationsSettings')); ?>

                                </a>
                            <?php endif; ?>
                            <!-- Import and export container -->
                            <?php if (isset($component)) { $__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Export_Import::class, ['name' => ' '.e(__('vulnerability.VulnerabilityManagement')).'','createPermissionKey' => 'vulnerability_management.create','exportPermissionKey' => 'vulnerability_management.export','exportRouteKey' => 'admin.vulnerability_management.ajax.export','importRouteKey' => [
                                    ["route" => "admin.vulnerability_management.import", "name" => __("locale.ImportNewVulnerabilities")],
                                    ["route" => "admin.vulnerability_management.closeVulnerabilities", "name" => __("locale.CloseVulnerabilities")]
                                ]]); ?>
<?php $component->withName('export-import'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180)): ?>
<?php $component = $__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180; ?>
<?php unset($__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180); ?>
<?php endif; ?>
                              
                            <!--/ Import and export container -->

                        </div>
                    </div>
                </div>
                <!--Search Form -->
                <div class="card-body mt-2">
                    <form class="dt_adv_search" method="POST">
                        <div class="row g-1 mb-md-1">
                            <div class="col-md-4">
                                <label class="form-label"><?php echo e(__('locale.pluginId')); ?>:</label>
                                <input class="form-control dt-input" name="filter_plugin_id" data-column="1"
                                    data-column-index="0" type="text">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label"><?php echo e(__('locale.Name')); ?>:</label>
                                <input class="form-control dt-input" name="filter_name" data-column="2"
                                    data-column-index="1" type="text">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label"><?php echo e(__('vulnerability.CVE')); ?>:</label>
                                <input class="form-control dt-input" name="filter_cve" data-column="2"
                                    data-column-index="1" type="text">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label"><?php echo e(__('vulnerability.Asset')); ?>:</label>
                                <select class="form-control dt-input dt-select select2" name="filter_assets"
                                    id="asset" data-column="3" data-column-index="2">
                                    <option value=""><?php echo e(__('locale.select-option')); ?></option>
                                    <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($asset->name); ?>"><?php echo e($asset->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label"><?php echo e(__('locale.Teams')); ?>:</label>
                                <select class="form-control dt-input dt-select select2" name="filter_teams"
                                    data-column="4" data-column-="3">
<option value=""><?php echo e(__('locale.select-option')); ?></option>
                                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($team->name); ?>"><?php echo e($team->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label"><?php echo e(__('locale.Severity')); ?>:</label>
                                <select class="form-control dt-input dt-select select2" name="filter_severity"
                                    data-column="5" data-column-index="4">
                                    <option value=""><?php echo e(__('locale.select-option')); ?></option>
                                    <option value="<?php echo e(__('locale.Critical')); ?>"><?php echo e(__('locale.Critical')); ?></option>
                                    <option value="<?php echo e(__('locale.High')); ?>"><?php echo e(__('locale.High')); ?></option>
                                    <option value="<?php echo e(__('locale.Medium')); ?>"><?php echo e(__('locale.Medium')); ?></option>
                                    <option value="<?php echo e(__('locale.Low')); ?>"><?php echo e(__('locale.Low')); ?></option>
                                    <option value="<?php echo e(__('locale.Informational')); ?>"><?php echo e(__('locale.Informational')); ?>

                                    </option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label"><?php echo e(__('locale.Status')); ?>:</label>
                                <select class="form-control dt-input dt-select select2" name="filter_status"
                                    data-column="6" data-column-index="5">
                                    <option value=""><?php echo e(__('locale.select-option')); ?></option>
                                    <option value='Open'> <?php echo e(__('locale.Open')); ?></option>
                                    <option value='Closed'> <?php echo e(__('locale.Closed')); ?></option>
                                    <option value='In Progress'> <?php echo e(__('locale.In Progress')); ?></option>
                                </select>
                            </div>
                        </div>
                </div>

                </form>
            </div>
            <hr class="my-0" />
            <div class="card-datatable">
                <table class="dt-advanced-server-search table">
                    <thead>
                        <tr>
                            <th><?php echo e(__('locale.#')); ?></th>
                            <th><?php echo e(__('locale.PluginId')); ?></th>
                            <th><?php echo e(__('locale.PluginName')); ?></th>
                            <th><?php echo e(__('vulnerability.CVE')); ?></th>
                            <th><?php echo e(__('vulnerability.Assets')); ?></th>
                            <th><?php echo e(__('locale.Teams')); ?></th>
                            <th><?php echo e(__('locale.Severity')); ?></th>
                            <th><?php echo e(__('locale.Status')); ?></th>
                            <th><?php echo e(__('locale.CreatedDate')); ?></th>
                            <th><?php echo e(__('locale.Actions')); ?></th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th><?php echo e(__('locale.#')); ?></th>
                            <th><?php echo e(__('locale.PluginId')); ?></th>
                            <th><?php echo e(__('locale.PluginName')); ?></th>
                            <th><?php echo e(__('vulnerability.CVE')); ?></th>
                            <th><?php echo e(__('vulnerability.Assets')); ?></th>
                            <th><?php echo e(__('locale.Teams')); ?></th>
                            <th><?php echo e(__('locale.Severity')); ?></th>
                            <th><?php echo e(__('locale.Status')); ?></th>
                            <th><?php echo e(__('locale.CreatedDate')); ?></th>
                            <th><?php echo e(__('locale.Actions')); ?></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    </div>
</section>
<?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/components/admin/content/vulnerability_management/search.blade.php ENDPATH**/ ?>