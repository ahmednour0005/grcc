
<div class="modal modal-slide-in basic-select2 fade bootstrap-select" id="<?php echo e($id); ?>">
    <div class="modal-dialog sidebar-sm">
        <form action="<?php echo e(route('admin.vulnerability_management.ajax.store')); ?>" method="POST" class="modal-content pt-0">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id">
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">×</button>
            <div class="modal-header mb-1">
                <h5 class="modal-title"><?php echo e($title); ?></h5>
            </div>
            <div class="modal-body flex-grow-1">

                <div class="mb-1">
<label class="form-label"><?php echo e(__('locale.PluginId')); ?></label>
<input type="text" name="plugin_id" class="form-control dt-post" aria-label="<?php echo e(__('locale.PluginId')); ?>" />
<span class="error error-plugin_id "></span>
</div>

<div class="mb-1">
    <label class="form-label"><?php echo e(__('locale.PluginName')); ?></label>
    <input type="text" name="name" class="form-control dt-post" aria-label="<?php echo e(__('locale.PluginName')); ?>" />
                    <span class="error error-name "></span>
                </div>

                
                <div class="mb-1">
                    <label class="form-label"><?php echo e(__('vulnerability.CVE')); ?></label>
<input type="text" name="cve" class="form-control dt-post" aria-label="<?php echo e(__('vulnerability.CVE')); ?>" />
                    <span class="error error-cve "></span>
                </div>

<div class="mb-1">
    <label class="form-label"><?php echo e(__('locale.NetbiosName')); ?></label>
    <input type="text" name="netbios_name" class="form-control dt-post" aria-label="<?php echo e(__('locale.NetbiosName')); ?>" />
    <span class="error error-netbios_name "></span>
</div>


<div class="mb-1">
    <label class="form-label"><?php echo e(__('locale.DnsName')); ?></label>
    <input type="text" name="dns_name" class="form-control dt-post" aria-label="<?php echo e(__('locale.DnsName')); ?>" />
    <span class="error error-dns_name "></span>
</div>
                
                <div class="mb-1">
                    <label class="form-label"> <?php echo e(__('vulnerability.IpAddress')); ?></label>
                    <select name="ip_address" class="form-select multiple-select2">
                        <option value="" disabled hidden><?php echo e(__('locale.select-option')); ?></option>
                        <option value="no_ip"><?php echo e(__('locale.NoIpAddress')); ?></option>
                        <?php $__currentLoopData = $ips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ip); ?>"><?php echo e($ip); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="error error-ip_address "></span>
                </div>  

                 
                <div class="mb-1">
                    <label class="form-label"> <?php echo e(__('vulnerability.Assets')); ?></label>
                    <select name="assets[]" class="form-select multiple-select2" multiple="multiple">
                        <option value="" disabled hidden><?php echo e(__('locale.select-option')); ?></option>

                    </select>
                    <span class="error error-assets "></span>
                </div>

                 
                <div class="mb-1">
                    <label class="form-label"> <?php echo e(__('locale.Teams')); ?></label>
                    <select name="teams[]" class="form-select multiple-select2" multiple="multiple">
                        <option value="" disabled hidden><?php echo e(__('locale.select-option')); ?></option>
                        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($team->id); ?>"><?php echo e($team->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="error error-teams "></span>
                </div>

<div class="mb-1">
    <label class="form-label"><?php echo e(__('locale.Port')); ?></label>
    <input type="number" min="0" step="1" name="port" class="form-control dt-post"
        aria-label="<?php echo e(__('locale.Port')); ?>" />
    <span class="error error-port "></span>
</div>

<div class="mb-1">
    <label class="form-label"><?php echo e(__('locale.Protocol')); ?></label>
    <input type="text" name="protocol" class="form-control dt-post" aria-label="<?php echo e(__('locale.Protocol')); ?>" />
    <span class="error error-protocol "></span>
</div>

<div class="mb-1">
    <label class="form-label "><?php echo e(__('locale.Severity')); ?></label>
    <select name="severity" class="form-select select2">
        <option value="" disabled hidden selected><?php echo e(__('locale.select-option')); ?></option>
        <option value='Critical'> <?php echo e(__('locale.Critical')); ?></option>
        <option value='High'> <?php echo e(__('locale.High')); ?></option>
        <option value='Medium'> <?php echo e(__('locale.Medium')); ?></option>
        <option value='Low'> <?php echo e(__('locale.Low')); ?></option>
        <option value='Informational'> <?php echo e(__('locale.Informational')); ?></option>
    </select>
    <span class="error error-severity"></span>
</div>

<div class="mb-1">
    <label class="form-label "><?php echo e(__('locale.Exploit')); ?></label>
    <select name="exploit" class="form-select select2">
        <option value="" disabled hidden selected><?php echo e(__('locale.select-option')); ?></option>
        <option value='yes'> <?php echo e(__('locale.Yes')); ?></option>
        <option value='no'> <?php echo e(__('locale.No')); ?></option>
    </select>
    <span class="error error-exploit"></span>
</div>

<div class="mb-1">
    <label class="form-label"><?php echo e(__('locale.Synopsis')); ?></label>
    <textarea class="form-control" name="synopsis" rows="3"></textarea>
    <span class="error error-synopsis "></span>
</div>
                
                <div class="mb-1">
                    <label class="form-label"><?php echo e(__('locale.Description')); ?></label>
                    <textarea  class="form-control" name="description" rows="3"></textarea>
                    <span class="error error-description "></span>
                </div>
                
                <div class="mb-1">
<label class="form-label"><?php echo e(__('locale.Solution')); ?></label>
                    <textarea  class="form-control" name="recommendation" rows="3"></textarea>
                    <span class="error error-recommendation "></span>
                </div>
                
                <div class="mb-1">
<label class="form-label"><?php echo e(__('locale.PluginOutput')); ?></label>
                    <textarea  class="form-control" name="plan" rows="3"></textarea>
                    <span class="error error-plan "></span>
                </div>

<div class="mb-1">
    <label class="form-label "><?php echo e(__('locale.FirstDiscovered')); ?></label>
    <input name="first_discovered" class="form-control flatpickr-date-time-compliance" placeholder="YYYY-MM-DD" />
    <span class="error error-first_discovered"></span>
</div>

<div class="mb-1">
    <label class="form-label "><?php echo e(__('locale.LastObserved')); ?></label>
    <input name="last_observed" class="form-control flatpickr-date-time-compliance" placeholder="YYYY-MM-DD" />
    <span class="error error-last_observed"></span>
</div>

<div class="mb-1">
    <label class="form-label "><?php echo e(__('locale.PluginPublicationDate')); ?></label>
    <input name="plugin_publication_date" class="form-control flatpickr-date-time-compliance"
        placeholder="YYYY-MM-DD" />
    <span class="error error-plugin_publication_date"></span>
</div>

<div class="mb-1">
    <label class="form-label "><?php echo e(__('locale.PluginModificationDate')); ?></label>
    <input name="plugin_modification_date" class="form-control flatpickr-date-time-compliance"
        placeholder="YYYY-MM-DD" />
    <span class="error error-plugin_modification_date"></span>
</div>
                
                <div class="mb-1">
                    <label class="form-label "><?php echo e(__('locale.Status')); ?></label>
                    <select name="status" class="form-select select2">
                        <option value='Open' selected> <?php echo e(__('locale.Open')); ?></option>
                        <option value='Closed'> <?php echo e(__('locale.Closed')); ?></option>
                        <option value='In Progress'> <?php echo e(__('locale.In Progress')); ?></option>
<option value='Overdue'> <?php echo e(__('locale.Overdue')); ?></option>
                    </select>
                    <span class="error error-status"></span>
                </div>

                <button type="Submit" class="btn btn-primary data-submit me-1"> <?php echo e(__('locale.Submit')); ?></button>
                <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    <?php echo e(__('locale.Cancel')); ?></button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/components/admin/content/vulnerability_management/form.blade.php ENDPATH**/ ?>