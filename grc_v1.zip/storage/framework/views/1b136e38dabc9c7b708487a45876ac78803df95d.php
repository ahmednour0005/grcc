

<?php $__env->startSection('title', __('compliance.Active Audits')); ?>

<?php $__env->startSection('vendor-style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('fonts/fontawesome-6.2.1/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/toastr.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/forms/select/select2.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/animate/animate.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/sweetalert2.min.css'))); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/base/plugins/extensions/ext-component-toastr.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css'))); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Advanced Search -->
    <section id="advanced-search-datatable">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header border-bottom p-1">
                        <div class="head-label">
                            <h4 class="card-title"><?php echo e(__('compliance.Active Audits')); ?></h4>
                        </div>
                        <div class="dt-action-buttons text-end">
                            <div class="dt-buttons d-inline-flex">
                                <!-- Import and export container -->
                                <?php if (isset($component)) { $__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Export_Import::class, ['name' => ' '.e(__('compliance.Active Audits')).'','createPermissionKey' => '_','exportPermissionKey' => 'audits.export','exportRouteKey' => 'admin.compliance.audit.ajax.active.export','importRouteKey' => 'will-added-TODO']); ?>
<?php $component->withName('export-import'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180)): ?>
<?php $component = $__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180; ?>
<?php unset($__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180); ?>
<?php endif; ?>
                                <!--/ Import and export container -->
                            </div>

                            <?php if(auth()->user()->hasPermission('audits.create')): ?>
                                <a href="<?php echo e(route('admin.compliance.notificationsSettingsActiveAduit')); ?>"
                                    class="dt-button btn btn-primary me-2" target="_self">
                                    <?php echo e(__('locale.NotificationsSettings')); ?>

                                </a>
                            <?php endif; ?>
                        </div>

                    </div>
                    <!--Search Form -->
                    <div class="card-body mt-2">
                        <form class="dt_adv_search" method="POST">
                            <div class="row g-1 mb-md-1">

                                <div class="col-md-4">
                                    <label class="form-label"><?php echo e(__('compliance.framework')); ?></label>
                                    <select class="form-control dt-input dt-select select2" name="filter_framework"
                                        id="framework" data-column="1" data-column-index="0">
                                        <option value=""><?php echo e(__('locale.select-option')); ?></option>
                                        <?php $__currentLoopData = $frameworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $framework): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($framework->name); ?>" data-id="<?php echo e($framework->id); ?>">
                                                <?php echo e($framework->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                

                                <div class="col-md-4">
                                    <label class="form-label"><?php echo e(__('compliance.Control')); ?></label>
                                    <select class="form-control dt-input dt-select select2"
                                        name="filter_FrameworkControlWithFramworks" id="control" data-column="3"
                                        data-column-index="2">
                                        <option value=""><?php echo e(__('locale.select-option')); ?></option>
                                        <?php $__currentLoopData = $controls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $control): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($control->short_name); ?>"><?php echo e($control->short_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label"><?php echo e(__('compliance.TestNumber')); ?></label>
                                    <select class="form-control dt-input dt-select select2"
                                        name="filter_test_number" id="test_number" data-column="3"
                                        data-column-index="2">
                                        <option value=""><?php echo e(__('locale.select-option')); ?></option>
                                        <?php $__currentLoopData = $testNumbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testNumber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($testNumber); ?>"><?php echo e($testNumber); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                

                            </div>
                        </form>
                    </div>
                    <hr class="my-0" />

                    <div class="card-datatable">
                        <table class="dt-advanced-server-search table">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('locale.#')); ?></th>
                                    <th><?php echo e(__('compliance.framework')); ?></th>
                                    <th><?php echo e(__('compliance.Control')); ?></th>
                                    <th><?php echo e(__('compliance.test-name')); ?></th>
                                    <th><?php echo e(__('compliance.TestNumber')); ?></th>
                                    <th><?php echo e(__('compliance.tester')); ?></th>
                                    <th><?php echo e(__('compliance.InitiationDate')); ?></th>
                                    <th><?php echo e(__('compliance.last-test')); ?></th>
                                    <th><?php echo e(__('compliance.next-test')); ?></th>
                                    <th><?php echo e(__('locale.Actions')); ?></th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th><?php echo e(__('locale.#')); ?></th>
                                    <th><?php echo e(__('compliance.framework')); ?></th>
                                    <th><?php echo e(__('compliance.Control')); ?></th>
                                    <th><?php echo e(__('compliance.test-name')); ?></th>
                                    <th><?php echo e(__('compliance.TestNumber')); ?></th>
                                    <th><?php echo e(__('compliance.tester')); ?></th>
                                    <th><?php echo e(__('compliance.InitiationDate')); ?></th>
                                    <th><?php echo e(__('compliance.last-test')); ?></th>
                                    <th><?php echo e(__('compliance.next-test')); ?></th>
                                    <th><?php echo e(__('locale.Actions')); ?></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ Advanced Search -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/forms/select/select2.full.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/extensions/sweetalert2.all.min.js'))); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
    <script src="<?php echo e(asset(mix('js/scripts/forms/form-select2.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/extensions/toastr.min.js'))); ?>"></script>
    <script>
        var permission = [],
            URLs = [];
        permission['delete'] = <?php echo e(auth()->user()->hasPermission('audits.delete')? 1: 0); ?>;
        permission['result'] = <?php echo e(auth()->user()->hasPermission('audits.result')? 1: 0); ?>;
        let lang = [];
        lang['success'] = "<?php echo e(__('locale.Success')); ?>";
        lang['error'] = "<?php echo e(__('locale.Error')); ?>";
        lang['selectOption'] = "<?php echo e(__('locale.select-option')); ?>";
        lang['DetailsOfItem'] = "<?php echo e(__('locale.DetailsOfItem', ['item' => __('compliance.ActiveAudit')])); ?>";
        URLs['ajax_list'] = "<?php echo e(route('admin.compliance.ajax.get-audits')); ?>";
        URLs['get_framework_controls'] = "<?php echo e(route('admin.compliance.ajax.getFrameworkControls','')); ?>";
    </script>
    <script src="<?php echo e(asset('ajax-files/compliance/active-audit.js')); ?>"></script>

    <script>
        function showResultAudit(id) {
            var url = "<?php echo e(route('admin.compliance.audit.edit', ':id')); ?>";
            url = url.replace(':id', id);
            window.location.href = url;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/admin/content/compliance/active-audit/index.blade.php ENDPATH**/ ?>