<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>Advanced Controls</title>

    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('website/css/reset.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('website/css/simplegrid.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('website/css/icomoon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('website/css/lightcase.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('website/js/owl-carousel/owl.carousel.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('website/js/owl-carousel/owl.theme.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('website/js/owl-carousel/owl.transitions.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('website/style.css')); ?>">

    <!-- Google Fonts -->
    


    
</head>
<body id="home">
    <!-- Header -->
    <header id="top-header" class="header-home">
        <div class="grid">
            <div class="col-1-1">
                <div class="content">
                    <div class="logo-wrap" style="max-width:100%">
                        <a href="#0" class="logo" style="0max-width:100%">Advanced Controls IT</a>
                    </div>
                    <nav class="navigation">
                        <input type="checkbox" id="nav-button">
                        <label for="nav-button" onclick></label>
                        <ul class="nav-container">
                            <li><a href="#home" class="current">Home</a></li>
                            <li><a href="#services">CyberMode Features</a></li>
                            <li><a href="#work">Screen shot</a></li>
                            <li><a href="#blog">System Reqirments</a></li>
                            <li><a href="#pricing">Pricing</a></li>
                            <li><a href="#team">Request Demo</a></li>
                            <li><a href="#contact">Contact</a></li>
                            <?php if(auth()->guard()->check()): ?>
                            <li><a class="external" href="<?php echo e(route('admin.dashboard')); ?>">System</a></li>
                            <?php endif; ?>
                            <?php if(auth()->guard()->guest()): ?>
                            <li><a class="external" href="<?php echo e(route('login')); ?>">Login</a></li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- End Header -->

    <!-- Parallax Section -->
    <div class="parallax-section parallax1">
        <div class="grid grid-pad">
            <div class="col-1-1">
                <div class="content content-header">
                    <h2>We Are Creative Cybersecurity Solutions Provider</h2>
                    <p>
                        <img border="0" src="<?php echo e(asset('website/images/cybermode.png')); ?>" width="500" height="203" style="object-fit: contain"></p>
                    <p>first platform (cyber security information Management Center and platform) which is considered the first of its kind in the Arab world and third globally in the field of cybersecurity governance and management of facilities, which were designed with Saud Arabian minds and hands to encourage the direction of our great state, the kingdom of Saudi Arabia and our wise leadership in the vision of 2030.</p>
                </div>
            </div>
        </div>
    </div>
    <!-- End Parallax Section -->

    <!-- CurveUp -->
    <svg class="curveUpColor" xmlns="http://www.w3.org/2000/svg" version="1.1" width="100%" height="100" viewBox="0 0 100 100" preserveAspectRatio="none">
        <path d="M0 100 C 20 0 50 0 100 100 Z"></path>
    </svg>

    <!-- Services Section -->
    <div class="wrap services-wrap" id="services">
        <section class="grid grid-pad services">
            <h2>&nbsp;</h2>
            <h2>CyberMode Features</h2>
            <div class="col-1-4 service-box service-1">
                <div class="content">
                    <div class="service-icon">
                        <i class="circle-icon icon-display"></i>
                    </div>
                    <div class="service-entry">
                        <h3>Cybersecurity Frameworks</h3>
                        <h3>Cybersecurity Controls
                        </h3>

                        <h3>Audit
                            and Compliance Assessment
                        </h3>

                        <p>.</p>
                    </div>
                </div>
            </div>
            <div class="col-1-4 service-box service-2">
                <div class="content">
                    <div class="service-icon">
                        <i class="circle-icon icon-display"></i>
                    </div>
                    <div class="service-entry">
                        <h3>Register and Manage Risks </h3>
                        <h3>Gap
                            Analysis
                        </h3>

                        <h3>Publish
                            Documents and Policies
                        </h3>

                        <p>.</p>
                    </div>
                </div>
            </div>
            <div class="col-1-4 service-box service-3">
                <div class="content">
                    <div class="service-icon">
                        <i class="circle-icon icon-display"></i>
                    </div>
                    <div class="service-entry">
                        <h3>Audit and Compliance Assessment </h3>
                        <h3>Manage
                            Assets and Subscription
                        </h3>

                        <h3>Manage
                            Structure, Employee,
                            R&R and KPIs
                        </h3>

                        <p>.</p>
                    </div>
                </div>
            </div>
            <div class="col-1-4 service-box service-4">
                <div class="content">
                    <div class="service-icon">
                        <i class="circle-icon icon-display"></i>
                    </div>
                    <div class="service-entry">
                        <h3>Cybersecurity Awareness and Assessment </h3>
                        <h3>Vulnerabilities
                            Management
                        </h3>

                        <h3>Change
                            Management and workflow
                        </h3>

                        <p>.</p>
                    </div>
                </div>
            </div>




        </section>
    </div>
    <!-- End Services Section -->

    <!-- CurveDown -->
    <svg class="curveDownColor" xmlns="http://www.w3.org/2000/svg" version="1.1" width="100%" height="100" viewBox="0 0 100 100" preserveAspectRatio="none">
        <path d="M0 0 C 50 100 80 100 100 0 Z"></path>
    </svg>

    <!-- Work Section -->
    <div class="wrap grey recent-wrap" id="work">
        <section class="grid grid-pad">
            <h2>Some of Screenshot</h2>
            <!-- Start of Filter section -->
            <div class="col-1-1 mix">
                <ul class="filters">
                    <li class="filter active" data-filter="all">Framworks</li>
                    <li class="filter" data-filter=".illustration">Risk Management</li>
                    <li class="filter" data-filter=".web-design">Security Awareness</li>
                    <li class="filter" data-filter=".photography">Dhashboards</li>
                </ul>
            </div>
            <!-- End of Filter section -->
            <div class="portfolio-items">
                <div class="col-1-3 mix illustration">
                    <div class="content">
                        <div class="recent-work">
                            <img src="<?php echo e(asset('website/images/work/1-small.jpg')); ?>" alt="">
                            <div class="overlay">
                                <span>&#1589;&#1608;&#1585;&#1577;</span>
                                <h2><a class="img-wrap" data-rel="lightcase:illustration" title="Asian tourist - Illustration" href="images/work/1-big.jpg">...</a></h2>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-1-3 mix illustration">
                    <div class="content">
                        <div class="recent-work">
                            <img src="<?php echo e(asset('website/images/work/2-small.jpg')); ?>" alt="">
                            <div class="overlay">
                                <span>&#1589;&#1608;&#1585;&#1577;</span>
                                <h2><a class="img-wrap" data-rel="lightcase:illustration" title="Batman Wannabe - Illustration" href="images/work/2-big.jpg">...</a></h2>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-1-3 mix photography">
                    <div class="content">
                        <div class="recent-work">
                            <img src="<?php echo e(asset('website/images/work/8-small.jpg')); ?>" alt="">
                            <div class="overlay">
                                <span>&#1589;&#1608;&#1585;&#1577;</span>
                                <h2><a class="img-wrap" data-rel="lightcase:photography" title="Big city and dreams - Photography" href="images/work/8-big.jpg">...</a></h2>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-1-3 mix web-design">
                    <div class="content">
                        <div class="recent-work">
                            <img src="<?php echo e(asset('website/images/work/6-small.jpg')); ?>" alt="">
                            <div class="overlay">
                                <span>&#1589;&#1608;&#1585;&#1577;</span>
                                <h2><a class="img-wrap" data-rel="lightcase:webdesign" title="Minimal nature - Web Design" href="images/work/6-big.jpg">...</a></h2>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-1-3 mix web-design">
                    <div class="content">
                        <div class="recent-work">
                            <img src="<?php echo e(asset('website/images/work/3-small.jpg')); ?>" alt="">
                            <div class="overlay">
                                <span>&#1589;&#1608;&#1585;&#1577;</span>
                                <h2><a class="img-wrap" data-rel="lightcase:illustration" title="Jack the sailor - Illustration" href="images/work/3-big.jpg">...</a></h2>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-1-3 mix photography">
                    <div class="content">
                        <div class="recent-work">
                            <img src="<?php echo e(asset('website/images/work/7-small.jpg')); ?>" alt="">
                            <div class="overlay">
                                <span>&#1589;&#1608;&#1585;&#1577;</span>
                                <h2><a class="img-wrap" data-rel="lightcase:photography" title="Enjoy live - Photography" href="images/work/7-big.jpg">...</a></h2>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-1-3 mix illustration">
                    <div class="content">
                        <div class="recent-work">
                            <img src="<?php echo e(asset('website/images/work/4-small.jpg')); ?>" alt="">
                            <div class="overlay">
                                <span>&#1589;&#1608;&#1585;&#1577;</span>
                                <h2><a class="img-wrap" data-rel="lightcase:illustration" title="Run kitty run - Photography" href="images/work/4-big.jpg">...</a></h2>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-1-3 mix illustration">
                    <div class="content">
                        <div class="recent-work">
                            <img src="<?php echo e(asset('website/images/work/9-small.jpg')); ?>" alt="">
                            <div class="overlay">
                                <span>&#1589;&#1608;&#1585;&#1577;</span>
                                <h2><a class="img-wrap" data-rel="lightcase:webdesign" title="Would you? - Web Design" href="images/work/9-big.jpg">...</a></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-1-1"><a class="btn" href="#0">View More</a></div>

        </section>
    </div>
    <!-- End Work Section -->

    <!-- CurveUp -->
    <svg class="curveUpColor" xmlns="http://www.w3.org/2000/svg" version="1.1" width="100%" height="100" viewBox="0 0 100 100" preserveAspectRatio="none">
        <path d="M0 100 C 20 0 50 0 100 100 Z"></path>
    </svg>

    <!-- Quotes Section -->
    <div class="wrap services-wrap">
        <section class="grid grid-pad">
            <div class="col-1-1 service-box cl-client-carousel-container">
                <div class="content">
                    <div class="cl-client-carousel">

                        <div class="item client-carousel-item">
                            <!-- Start of item -->
                            <div class="quotes-icon">
                                <i class="icon-quotes-left"></i>
                            </div>
                            <p>feedback 1</p>
                            <h4>-----</h4>
                        </div><!-- End of item -->

                        <div class="item client-carousel-item">
                            <!-- Start of item -->
                            <div class="quotes-icon">
                                <i class="icon-quotes-left"></i>
                            </div>
                            <p>feedback 2</p>
                            <h4>-----</h4>
                        </div><!-- End of item -->
                        <div class="item client-carousel-item">
                            <!-- Start of item -->
                            <div class="quotes-icon">
                                <i class="icon-quotes-left"></i>
                            </div>
                            <p>feedback 3</p>
                            <h4>----</h4>
                        </div><!-- End of item -->

                    </div>
                </div>
            </div>
        </section>
    </div>
    <!-- End Quotes Section -->

    <!-- CurveDown -->
    <svg class="curveDownColor" xmlns="http://www.w3.org/2000/svg" version="1.1" width="100%" height="100" viewBox="0 0 100 100" preserveAspectRatio="none">
        <path d="M0 0 C 50 100 80 100 100 0 Z"></path>
    </svg>

    <!-- Blog Section -->
    <div class="wrap blog-grid grey" id="blog">
        <div class="grid grid-pad">
            <div class="content">
                <h2>System Requirments</h2>
                <div class="col-1-2">
                    <article class="post-wrap">
                        <div class="post-img">
                            <a href="#0"><img src="<?php echo e(asset('website/images/post/post-n1.jpg')); ?>" alt=""></a>
                        </div>
                        <div class="post">
                            <h2 class="entry-title"><a href="#0">on premise</a></h2>
                            <div class="post-meta">
                                <a href="#0">specifications</a> <span class="mid-sep">·</span> <a href="#0"></a>
                            </div>
                            <p>Linux OS,
                                PHP 7.4.28 CLI,
                                Zend engine v3.4.0,
                                Zend OPCache v7.4.28,
                                mySQL ver 15.1 Distrib 10.6.7-MariaDB , for Linux (X86-64) using readline 5.1,
                                Apache /2.4.52 (unix)
                            </p>
                        </div>
                    </article>
                </div>
                <div class="col-1-2">
                    <article class="post-wrap">
                        <div class="post-img">
                            <a href="#0"><img src="<?php echo e(asset('website/images/post/post-n2.jpg')); ?>" alt=""></a>
                        </div>
                        <div class="post">
                            <h2 class="entry-title"><a href="#0">Cloud</a></h2>
                            <div class="post-meta">
                                <a href="#0">specifications</a> <span class="mid-sep">·</span> <a href="#0"></a>
                            </div>
                            <p>
                                Linux OS,
                                PHP 7.4.28 CLI,
                                Zend engine v3.4.0,
                                Zend OPCache v7.4.28,
                                mySQL ver 15.1 Distrib 10.6.7-MariaDB , for Linux (X86-64) using readline 5.1,
                                Apache /2.4.52 (unix)
                            </p>
                        </div>
                    </article>
                </div>

                <div class="col-1-1"></div>
            </div>
        </div>
    </div>
    <!-- End Blog Section -->

    <!-- CurveUp -->
    <svg class="curveUpColor" xmlns="http://www.w3.org/2000/svg" version="1.1" width="100%" height="100" viewBox="0 0 100 100" preserveAspectRatio="none">
        <path d="M0 100 C 20 0 50 0 100 100 Z"></path>
    </svg>

    <!-- Pricing Section -->
    <div class="wrap" id="pricing">
        <div class="grid grid-pad">
            <div class="content">
                <div class="col-1-1">
                    <section id="price-tables">
                        <br></br>
                        <h2>Pricing Tables</h2>



                        To connect:
                        E: sales@dsshield.com
                        T: 00966114579181



                    </section>
                </div>
            </div>
        </div>
    </div>
    <!-- End Pricing Section -->

    <!-- CurveDown -->
    <svg class="curveDownColor" xmlns="http://www.w3.org/2000/svg" version="1.1" width="100%" height="100" viewBox="0 0 100 100" preserveAspectRatio="none">
        <path d="M0 0 C 50 100 80 100 100 0 Z"></path>
    </svg>

    <!-- Parallax Section - Counter -->
    <div class="parallax-section parallax2">
        <div class="wrap">
            <section class="grid grid-pad callout">
                <div class="col-1-3">
                    <div class="content">
                        <div class="info-counter">
                            <div class="info-counter-row">

                            </div>
                            <div class="info-counter-content">
                                <h5 class="info-counter-number">
                                </h5>
                                <div class="info-counter-text"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-1-3">
                    <div class="content">
                        <div class="info-counter">
                            <div class="info-counter-row">

                            </div>
                            <div class="info-counter-content">
                                <h5 class="info-counter-number">

                                </h5>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-1-3">
                    <div class="content">
                        <div class="info-counter">
                            <div class="info-counter-row">

                            </div>
                            <div class="info-counter-content">
                                <h5 class="info-counter-number">
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <!-- End Parallax Section -->

    <!-- CurveUp -->
    <svg class="curveUpColor curveGrey" xmlns="http://www.w3.org/2000/svg" version="1.1" width="100%" height="100" viewBox="0 0 100 100" preserveAspectRatio="none">
        <path d="M0 100 C 20 0 50 0 100 100 Z"></path>
    </svg>

    <!-- Team Section -->
    <div class="wrap team-wrap grey" id="team">
        <div class="grid grid-pad">
            <div class="content">
                <h2>Request Demo</h2>

                To connect:
                E: sales@dsshield.com
                T: 00966114579181

            </div>
        </div>
    </div>
    <!-- End Team Section -->

    <!-- CurveUp -->
    <svg class="curveUpColor" xmlns="http://www.w3.org/2000/svg" version="1.1" width="100%" height="100" viewBox="0 0 100 100" preserveAspectRatio="none">
        <path d="M0 100 C 20 0 50 0 100 100 Z"></path>
    </svg>






    <!-- CurveDown -->
    <svg class="curveDownColor curveMapUp" xmlns="http://www.w3.org/2000/svg" version="1.1" width="100%" height="100" viewBox="0 0 100 100" preserveAspectRatio="none">
        <path d="M0 0 C 50 100 80 100 100 0 Z"></path>
    </svg>

    <!-- Parallax Section -->
    
    <!-- End Parallax Section -->

    <!-- CurveUp -->
    

    <!-- Contact Section -->
    <div class="wrap contact" id="contact">
        <div class="grid grid-pad">
            <br></br><br></br><br></br>
            <h2>Contact</h2>
            <div class="col-1-2">
                <div class="content address">
                    <h3>Talk to us</h3>
                    <p>Saudi Arabia</p>
                    <address>
                        <div>
                            <div class="box-icon">
                                <i class="icon-location"></i>
                            </div>
                            <span>Address:</span>
                            <p>Verdun Tower 7775 King Fahad Rd. Al Olaya 2970, Riyadh 12212</p>
                        </div>

                        <div>
                            <div class="box-icon">
                                <i class="icon-clock"></i>
                            </div>
                            <span>Work Time:</span>
                            <p>Sunday - Thursday from 8am to 5pm</p>
                        </div>

                        <div>
                            <div class="box-icon">
                                <i class="icon-phone"></i>
                            </div>
                            <span>Phone:</span>
                            <p>00966114579181</p>
                        </div>
                    </address>
                </div>
            </div>
            <div class="col-1-2 pleft-25">
                <div class="content contact-form">

                </div>
            </div>
        </div>
    </div>
    <!-- End Contact Section -->

    <!-- CurveDown -->
    <svg class="curveDownColor" xmlns="http://www.w3.org/2000/svg" version="1.1" width="100%" height="100" viewBox="0 0 100 100" preserveAspectRatio="none">
        <path d="M0 0 C 50 100 80 100 100 0 Z"></path>
    </svg>

    <!-- Footer -->
    <footer class="wrap">
        <div class="grid grid-pad">
            <div class="col-1-4">
                <div class="content">
                    <div class="footer-widget">
                    </div>
                </div>
            </div>
            <div class="col-1-4">
                <div class="content">
                    <div class="footer-widget">
                    </div>
                </div>
            </div>
            <div class="col-1-4">
                <div class="content">
                    <div class="footer-widget">
                    </div>
                </div>
            </div>
            <div class="col-1-4">
                <div class="content">
                    <div class="footer-widget">
                    </div>
                </div>
            </div>
        </div>
        <div class="social-footer">
            <div class="grid grid-pad">
                <div class="col-1-1">
                    <div class="content">
                        <div class="social-set">
                        </div>
                        <p class="source-org copyright">© 2022 | All Rights Reserved for Advanced Controls</a></p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- End Footer -->

    <div class="loader-overlay">
        <div class="loader">
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
        </div>
    </div>

    <!-- JS -->
    <script src="<?php echo e(asset('website/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('website/js/mixitup.js')); ?>"></script>
    <script src="<?php echo e(asset('website/js/smoothscroll.js')); ?>"></script>
    <script src="<?php echo e(asset('website/js/jquery.nav.js')); ?>"></script>
    <script src="<?php echo e(asset('website/js/owl-carousel/owl.carousel.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('cdn/waypoints.min.js')); ?>"></script>

    <script src="<?php echo e(asset('website/js/jquery.counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('website/js/lightcase.min.js')); ?>"></script>
    <script src="<?php echo e(asset('website/js/main.js')); ?>"></script>
</body>
</html>
<?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/website/index.blade.php ENDPATH**/ ?>