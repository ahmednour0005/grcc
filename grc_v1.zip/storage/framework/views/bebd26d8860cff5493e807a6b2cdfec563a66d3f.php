<body class="horizontal-layout horizontal-menu <?php echo e($configData['contentLayout']); ?> <?php echo e($configData['horizontalMenuType']); ?> <?php echo e($configData['blankPageClass']); ?> <?php echo e($configData['bodyClass']); ?> <?php echo e($configData['footerType']); ?>" data-open="hover" data-menu="horizontal-menu" data-col="<?php echo e($configData['showMenu'] ? $configData['contentLayout'] : '1-column'); ?>" data-framework="laravel" data-asset-path="<?php echo e(asset('/')); ?>">

    <!-- BEGIN: Header-->
    <?php echo $__env->make('admin.panels.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php if((isset($configData['showMenu']) && $configData['showMenu'] === true)): ?>
    <?php echo $__env->make('admin.panels.horizontalMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <!-- BEGIN: Content-->
    <div class="app-content content <?php echo e($configData['pageClass']); ?>">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>

        <?php if(($configData['contentLayout']!=='default') && isset($configData['contentLayout'])): ?>
        <div class="content-area-wrapper <?php echo e($configData['layoutWidth'] === 'boxed' ? 'container-xxl p-0' : ''); ?>">
            <div class="<?php echo e($configData['sidebarPositionClass']); ?>">
                <div class="sidebar">
                    
                    <?php echo $__env->yieldContent('content-sidebar'); ?>
                </div>
            </div>
            <div class="<?php echo e($configData['contentsidebarClass']); ?>">
                <div class="content-wrapper">
                    <div class="content-body">
                        
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php else: ?>
        <div class="content-wrapper <?php echo e($configData['layoutWidth'] === 'boxed' ? 'container-xxl p-0' : ''); ?>">
            
            <?php if($configData['pageHeader'] == true): ?>
            <?php echo $__env->make('admin.panels.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <div class="content-body">

                
                <?php echo $__env->yieldContent('content'); ?>

            </div>
        </div>
        <?php endif; ?>

    </div>
    <!-- End: Content-->

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

    
    <?php echo $__env->make('admin.panels.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('admin.panels.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        let appContentDefaultPaddingTopValue = 170.8; // for solve issue set value may be null by default
        var detectHorizontalMenuWrapLines = function(className) {

            let yAccess = new Set();
            var items = document.querySelectorAll(className);

            for (var i = 0; i < items.length; i++) {
                yAccess.add(items[i].getBoundingClientRect().top);
            };

            if (items.length > 0)
                return {
                    count: yAccess.size
                    , height: items[0].getBoundingClientRect().height
                };
            else
                return false;
        }

        $(window).on('load', function() {
            if (feather) {
                feather.replace({
                    width: 14
                    , height: 14
                });
            }

            const appContentPaddingTop = $('.horizontal-layout.navbar-floating:not(.blank-page) .app-content').css('padding-top'); // Get app content top padding value
            let appContentPaddingTopValue = parseFloat(appContentPaddingTop.slice(0, appContentPaddingTop.length - 2)).toFixed(1); // remove last 2 letters (px)
            if (appContentDefaultPaddingTopValue === null || appContentDefaultPaddingTopValue < 80) {
                appContentDefaultPaddingTopValue = appContentPaddingTopValue;
            }

            // changeFrameTitle();
            var iframe = document.querySelector('frame');
            if (iframe) {
                document.title= iframe.contentWindow.document.title;
            }
        });

        function recalculateAppMenuPadding() {
            var wrappedItems = detectHorizontalMenuWrapLines('.horizontal-menu-wrapper .header-navbar.navbar-expand-sm.navbar.navbar-horizontal.navbar-shadow.menu-border .navbar-container.main-menu-content ul.nav.navbar-nav li.nav-item');

            if (wrappedItems === false)
                return;

            if (wrappedItems.count > 5) {
                wrappedItems = detectHorizontalMenuWrapLines('.horizontal-menu-wrapper .header-navbar.navbar-expand-sm.navbar.navbar-horizontal.navbar-shadow.menu-border .navbar-container.main-menu-content ul.nav.navbar-nav li.nav-item');
                return;
            }
            const appContentPaddingTop = $('.horizontal-layout.navbar-floating:not(.blank-page) .app-content').css('padding-top'); // Get app content top padding value
            let appContentPaddingTopValue = parseFloat(appContentPaddingTop.slice(0, appContentPaddingTop.length - 2)).toFixed(1); // remove last 2 letters (px)
            if (appContentDefaultPaddingTopValue === null || appContentDefaultPaddingTopValue < 80) {
                appContentDefaultPaddingTopValue = appContentPaddingTopValue;
            }

            let addedPaddingValue = ((wrappedItems.count - 1) * wrappedItems.height).toFixed(1);

            $('.horizontal-layout.navbar-floating:not(.blank-page) .app-content').css('padding-top', `${(parseFloat(appContentDefaultPaddingTopValue) + parseFloat(addedPaddingValue)).toFixed(1)}px`);
        }

        window.onresize = function(event) {
            $.app.menu.changeMenu(Unison.fetch.now().name);
        };

        
        // <frame onload="var iframe = document.querySelector('frame'); if (iframe) { document.title= iframe.contentWindow.document.title;}">
        /* function changeFrameTitle() { // called every time frame is loaded (<frame onload="changeFrameTitle();">)
            var iframe = document.querySelector('frame');
            if (iframe) {
                $('title').text = iframe.contentWindow.document.title;
            }
        } */

    </script>
</body>

</html>
<?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/admin/layouts/horizontalLayoutMaster.blade.php ENDPATH**/ ?>