<section id="<?php echo e($id); ?>">
    <div class="row">
        <div class="col-12">
            <div class="card">

                <div class="card-header border-bottom p-1">
                    <div class="head-label">
                        <h4 class="card-title"><?php echo e(__('locale.FilterBy')); ?></h4>
                    </div>
                    <div class="dt-action-buttons text-end">
                        <div class="dt-buttons d-inline-flex">
                            <?php if(auth()->user()->hasPermission('department.create')): ?>                            
                                <button class="dt-button btn btn-primary me-2" type="button" data-bs-toggle="modal" data-bs-target="#<?php echo e($createModalID); ?>">
                                    <?php echo e(__('locale.AddANewDepartment')); ?>

                                </button>
                                <a href="<?php echo e(route('admin.hierarchy.department.notificationsSettingsDepartement')); ?>" class="dt-button btn btn-primary me-2"
                                target="_self">
                                <?php echo e(__('hierarchy.NotificationsSettingsDepartement')); ?>

                                </a>
                                
                            <?php endif; ?>

                            <!-- Import and export container -->
                                <?php if (isset($component)) { $__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Export_Import::class, ['name' => ' '.e(__('locale.Department')).'','createPermissionKey' => 'department.create','exportPermissionKey' => 'department.export','exportRouteKey' => 'admin.hierarchy.department.ajax.export','importRouteKey' => 'admin.hierarchy.department.import']); ?>
<?php $component->withName('export-import'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180)): ?>
<?php $component = $__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180; ?>
<?php unset($__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180); ?>
<?php endif; ?>
                            <!--/ Import and export container -->
                                                    
                        </div>
                    </div>
                </div>
                <!--Search Form -->
                <div class="card-body mt-2">
                    <form class="dt_adv_search" method="POST">
                        <div class="row g-1 mb-md-1">
                            <div class="col-md-4">
                                <label class="form-label"><?php echo e(__('locale.Name')); ?>:</label>
                                <input class="form-control dt-input " name="filter_name" data-column="1" data-column-index="0" type="text">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label"><?php echo e(__('locale.Code')); ?>:</label>
                                <input class="form-control dt-input " name="filter_code" data-column="2" data-column-index="1" type="text">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label"><?php echo e(__('locale.ParentDepartment')); ?>:</label>
                                <select class="form-control dt-input dt-select select2 " name="filter_parentDepartment" id="ParentDepartment" data-column="3" data-column-index="2">
                                    <option value=""><?php echo e(__('locale.select-option')); ?></option>
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($department->name); ?>"><?php echo e($department->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                             <div class="col-md-4">
                                <label class="form-label"><?php echo e(__('locale.ChildDepartments')); ?>:</label>
                                <select class="form-control dt-input dt-select select2 " name="filter_departments" id="ChildDepartments" data-column="4" data-column-index="3">
                                    <option value=""><?php echo e(__('locale.select-option')); ?></option>
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($department->name); ?>"><?php echo e($department->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label"><?php echo e(__('locale.Manager')); ?>:</label>
                                <select class="form-control dt-input dt-select select2 " name="filter_manager"  id="Manager" data-column="7" data-column-index="6">
                                    <option value=""><?php echo e(__('locale.select-option')); ?></option>
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <?php if($department->manager): ?>
                                        <option value="<?php echo e($department->manager->name); ?>"><?php echo e($department->manager->name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                </div>

                </form>
            </div>
            <hr class="my-0" />
            <div class="card-datatable">
                <table class="dt-advanced-server-search table">
                    <thead>
                        <tr>
                            <th><?php echo e(__('locale.#')); ?></th>
                            <th><?php echo e(__('locale.Name')); ?></th>
                            <th><?php echo e(__('locale.Code')); ?></th>
                            <th><?php echo e(__('locale.ParentDepartment')); ?></th>
                            <th><?php echo e(__('locale.ChildDepartments')); ?></th>
                            <th><?php echo e(__('locale.RequiredNumberOfEmplyees')); ?></th>
                            <th><?php echo e(__('locale.ActualNumberOfEmplyees')); ?></th>
                            <th><?php echo e(__('locale.Manager')); ?></th>
                            <th><?php echo e(__('locale.CreatedDate')); ?></th>
                            <th><?php echo e(__('locale.Actions')); ?></th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th><?php echo e(__('locale.#')); ?></th>
                            <th><?php echo e(__('locale.Name')); ?></th>
                            <th><?php echo e(__('locale.Code')); ?></th>
                            <th><?php echo e(__('locale.ParentDepartment')); ?></th>
                            <th><?php echo e(__('locale.ChildDepartments')); ?></th>
                            <th><?php echo e(__('locale.RequiredNumberOfEmplyees')); ?></th>
                            <th><?php echo e(__('locale.ActualNumberOfEmplyees')); ?></th>
                            <th><?php echo e(__('locale.Manager')); ?></th>
                            <th><?php echo e(__('locale.CreatedDate')); ?></th>
                            <th><?php echo e(__('locale.Actions')); ?></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    </div>
</section>
<?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/components/admin/content/hierarchy/department/search.blade.php ENDPATH**/ ?>