

<?php $__env->startSection('title', __('risk.Submit Risk')); ?>

<?php $__env->startSection('vendor-style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('fonts/fontawesome-6.2.1/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/toastr.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css'))); ?>">

    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/forms/select/select2.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/animate/animate.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/sweetalert2.min.css'))); ?>">
<?php $__env->stopSection(); ?>
<style>
    #risk_addational_notes_submit {
        height: 93px;

    }

    .ql-spanblock:after {
        content: "<sb/>";
    }

    .spanblock {
        background-color: #F8F8F8;
        border: 1px solid #CCC;
        line-height: 19px;
        padding: 6px 10px;
        border-radius: 3px;
        margin: 15px 0;
    }
</style>

<?php $__env->startSection('page-style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/base/plugins/extensions/ext-component-toastr.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css'))); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Advanced Search -->
    <?php if (isset($component)) { $__componentOriginal1c6519668a19bd41e2d300b11162002a973aec86 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Content\RiskManagement\SubmitRisk\Search::class, ['id' => 'advanced-search-datatable','createModalID' => 'add-new-risk']); ?>
<?php $component->withName('submit-risk-search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1c6519668a19bd41e2d300b11162002a973aec86)): ?>
<?php $component = $__componentOriginal1c6519668a19bd41e2d300b11162002a973aec86; ?>
<?php unset($__componentOriginal1c6519668a19bd41e2d300b11162002a973aec86); ?>
<?php endif; ?>
    <!--/ Advanced Search -->

    <!-- Create Form -->
    <?php if(auth()->user()->hasPermission('riskmanagement.create')): ?>
        <?php if (isset($component)) { $__componentOriginal04aed04cade54694d29de021134c71de7db5fdfd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Content\RiskManagement\SubmitRisk\Form::class, ['id' => 'add-new-risk','title' => ''.e(__('risk.AddANewRisk')).'','riskGroupings' => $riskGroupings,'threatGroupings' => $threatGroupings,'locations' => $locations,'frameworks' => $frameworks,'assets' => $assets,'assetGroups' => $assetGroups,'categories' => $categories,'technologies' => $technologies,'teams' => $teams,'enabledUsers' => $enabledUsers,'riskSources' => $riskSources,'riskScoringMethods' => $riskScoringMethods,'riskLikelihoods' => $riskLikelihoods,'impacts' => $impacts,'tags' => $tags,'owners' => $owners]); ?>
<?php $component->withName('submit-risk-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal04aed04cade54694d29de021134c71de7db5fdfd)): ?>
<?php $component = $__componentOriginal04aed04cade54694d29de021134c71de7db5fdfd; ?>
<?php unset($__componentOriginal04aed04cade54694d29de021134c71de7db5fdfd); ?>
<?php endif; ?>
    <?php endif; ?>
    <!--/ Create Form -->

    <!-- Update Form -->
    
    <!--/ Update Form -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/buttons.print.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/forms/select/select2.full.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/extensions/sweetalert2.all.min.js'))); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
    <script src="<?php echo e(asset(mix('js/scripts/forms/form-select2.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/extensions/toastr.min.js'))); ?>"></script>
    <script src="<?php echo e(asset('cdn/ckeditor.js')); ?>"></script>

    
    <script>
        let URLs = [],
            lang = [];
        lang['confirmDelete'] = "<?php echo e(__('locale.ConfirmDelete')); ?>";
        lang['cancel'] = "<?php echo e(__('locale.Cancel')); ?>";
        lang['success'] = "<?php echo e(__('locale.Success')); ?>";
        lang['error'] = "<?php echo e(__('locale.Error')); ?>";
        lang['confirmDeleteMessage'] = "<?php echo e(__('locale.AreYouSureToDeleteThisRecord')); ?>";
        lang['revert'] = "<?php echo e(__('locale.YouWontBeAbleToRevertThis')); ?>";
        lang['DetailsOfItem'] = "<?php echo e(__('locale.DetailsOfItem', ['item' => __('locale.risk')])); ?>";
        permission = [];
        permission['show'] = <?php echo e(auth()->user()->hasPermission('riskmanagement.view')? 1: 0); ?>;
        permission['delete'] = <?php echo e(auth()->user()->hasPermission('riskmanagement.delete')? 1: 0); ?>;
        URLs['ajax_list'] = "<?php echo e(route('admin.risk_management.ajax.index')); ?>";
        URLs['show'] = "<?php echo e(route('admin.risk_management.show', ':id')); ?>";
        URLs['create'] = "<?php echo e(route('admin.risk_management.ajax.store')); ?>";
        URLs['delete'] = "<?php echo e(route('admin.risk_management.ajax.destroy', ':id')); ?>";
    </script>
    <script src="<?php echo e(asset('ajax-files/risk_management/index.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/admin/content/risk_management/index.blade.php ENDPATH**/ ?>