<?php
    $configData = Helper::applClasses();
?>


<?php $__env->startSection('title', __('locale.license_key')); ?>

<?php $__env->startSection('vendor-style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/toastr.min.css'))); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/base/plugins/extensions/ext-component-toastr.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/base/pages/page-misc.css'))); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Not authorized-->
    <div class="misc-wrapper">
        <a class="brand-logo" href="https://www.advancedcontrols.sa/">
            <h2 class="brand-text text-primary ms-1">Cyber Mode</h2>
        </a>
        <div class="misc-inner p-2 p-sm-3">
            <div class="w-100 text-center">
                <h2 class="mb-1"><?php echo e(__('locale.license_key_has_been_expired')); ?> 🔐</h2>
                <p class="mb-2"><?php echo e(__('locale.Please contact us as soon as possible To purchase a new license key')); ?><a
                        href="tel:00966114579181">📞</a> 📩</p>
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo e(__('locale.please_enter_license_key')); ?></h4>
                    </div>
                    <div class="card-body">
                        <form class="form form-vertical" action="<?php echo e(route('serial.check')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">

                                <div class="col-12">
                                    <div class="mb-1">
                                        <label class="form-label"
                                            for="first-name-icon"><?php echo e(__('locale.license_key')); ?></label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i data-feather="user"></i></span>
                                            <input type="text" id="first-name-icon" class="form-control"
                                                name="serial_number" placeholder="XXXX-XXXX-XXXX-XXXX" />
                                        </div>
                                        <span class="error error-serial_number"></span>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary me-1"><?php echo e(__('locale.Submit')); ?></button>
                                    <button type="reset"
                                        class="btn btn-outline-secondary"><?php echo e(__('locale.Reset')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- / Not authorized-->
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
    <script src="<?php echo e(asset(mix('vendors/js/extensions/toastr.min.js'))); ?>"></script>
    <script>
        // status [warning, success, error]
        function makeAlert($status, message, title) {
            // On load Toast
            if (title == 'Success')
                title = '👋' + title;
            toastr[$status](message, title, {
                closeButton: true,
                tapToDismiss: false,
            });
        }

        // function to show error validation 
        function showError(data) {
            $('.error').empty();
            $.each(data, function(key, value) {
                $('.error-' + key).empty();
                $('.error-' + key).append(value);
            });
        }

        let lang = [];
        lang['error'] = "<?php echo e(__('locale.Error')); ?>";
        lang['success'] = "<?php echo e(__('locale.Success')); ?>";

        // Submit form for editing asset
        $('form').on('submit', function(e) {
            $('.error').empty();
            e.preventDefault();
            let url = $(this).attr('action');
            $.ajax({
                url: url,
                type: "post",
                data: $(this).serialize(),
                success: function(response) {
                    console.log(response);
                    if (response.status) {
                        makeAlert('success', response.message, lang['success']);
                        window.location.href = response.redirectTo;
                    } else {
                        showError(response['errors']);
                    }
                },
                error: function(response, data) {
                    responseData = response.responseJSON;
                    console.log(responseData);
                    makeAlert('error', responseData.message, lang['error']);
                    showError(responseData.errors);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/fullLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/admin/content/serial/index.blade.php ENDPATH**/ ?>