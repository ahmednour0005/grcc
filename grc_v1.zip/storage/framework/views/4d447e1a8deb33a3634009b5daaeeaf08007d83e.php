<?php if(auth()->user()->hasPermission($createPermissionKey) ||
        auth()->user()->hasPermission($exportPermissionKey)): ?>
    <div id="import-export-container" class="text-center">
        <!-- Export form -->
        <form target="_blank" class="d-none" id="export-form" method="post" action="<?php echo e(route($exportRouteKey)); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="type" value="excel">
        </form>

        
        <?php if(auth()->user()->hasPermission($exportPermissionKey)): ?>
            <div class="btn-group dropdown dropdown-icon-wrapper me-1">
                <button type="button" class="btn btn-primary submit-export"
                    data-type="excel"><?php echo e(__('locale.Export')); ?></button>
                <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split"
                    data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fa-regular fa-file-excel"></i>
                </button>
                <div class="dropdown-menu dropdown-menu-end export-types">
                    <span class="dropdown-item" data-type="excel">
                        <span class="px-1"><?php echo e(__('locale.Excel')); ?></span>
                        <i class="fa-regular fa-file-excel"></i>
                    </span>
                    
                </div>
            </div>
        <?php endif; ?>

        
        <?php if(is_array($importRouteKey) && !empty($importRouteKey)): ?>


            <?php if(auth()->user()->hasPermission($createPermissionKey) &&
                    $createOtherCondition &&
                    $importRouteKey != 'will-added-TODO'): ?>
                <div class="btn-group dropdown">
                    <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <?php echo e(__('locale.Import')); ?>

                    </button>
                    <div class="dropdown-menu" style="min-width:20rem">
                        <?php $__currentLoopData = $importRouteKey; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $button): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route($button['route'])); ?>" class="dropdown-item"><?php echo e($button['name']); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                

             

                </div>
            <?php endif; ?>
        <?php else: ?>
        
            <?php if(auth()->user()->hasPermission($createPermissionKey) && $importRouteKey != 'will-added-TODO'): ?>
                <a href="<?php echo e(route($importRouteKey)); ?>" class="dt-button btn btn-primary me-2" target="_self">
                    <?php echo e(__('locale.Import')); ?>

                </a>
            <?php endif; ?>
    </div>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/components/admin/export_import.blade.php ENDPATH**/ ?>