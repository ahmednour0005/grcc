<section id="<?php echo e($id); ?>">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom p-1">
                    <div class="head-label">
                        <h4 class="card-title"><?php echo e(__('locale.FilterBy')); ?></h4>
                    </div>
                    <div class="dt-action-buttons text-end">
                        <div class="dt-buttons d-inline-flex">
                            <?php if(auth()->user()->hasPermission('asset.create')): ?>
                            <button class="dt-button btn btn-primary me-1" type="button" data-bs-toggle="modal"
                                data-bs-target="#<?php echo e($createModalID); ?>">
                                <?php echo e(__('asset.AddANewAsset')); ?>

                            </button>
                            <a href="<?php echo e(route('admin.asset_management.notificationsSettingsActiveAsset')); ?>"
                                class="dt-button btn btn-primary me-2" target="_self">
                                <?php echo e(__('locale.NotificationsSettings')); ?>

                            </a>
                            <?php endif; ?>

                            <!-- Import and export container -->
                            <?php if (isset($component)) { $__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Export_Import::class, ['name' => ' '.e(__('locale.Asset')).'','createPermissionKey' => 'asset.create','exportPermissionKey' => 'asset.export','exportRouteKey' => 'admin.asset_management.ajax.export','importRouteKey' => 'admin.asset_management.import']); ?>
<?php $component->withName('export-import'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180)): ?>
<?php $component = $__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180; ?>
<?php unset($__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180); ?>
<?php endif; ?>
                            <!--/ Import and export container -->
                        </div>
                    </div>
                </div>
                <!--Search Form -->
                <div class="card-body mt-2">
                    <form class="dt_adv_search" method="POST">
                        <div class="row g-1 mb-md-1">
                            <div class="col-md-3">
                                <label class="form-label"><?php echo e(__('locale.AssetName')); ?>:</label>
                                <input class="form-control dt-input" name="filter_name" data-column="1"
                                    data-column-index="0" type="text">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label"><?php echo e(__('locale.IPAddress')); ?>:</label>
                                <input class="form-control dt-input" name="filter_ip" data-column="2"
                                    data-column-index="1" type="text">
                            </div>
                            
                            <input hidden name="filter_tags">
                            <div class="col-md-3">
                                <label class="form-label"><?php echo e(__('locale.AssetSiteLocation')); ?>:</label>
                                <select class="form-control dt-input dt-select select2" name="filter_location"
                                    id="AssetSiteLocation" data-column="5" data-column-index="3">
                                    <option value=""><?php echo e(__('locale.select-option')); ?></option>
                                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($location->name); ?>"><?php echo e($location->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label"><?php echo e(__('locale.AssetCategory')); ?>:</label>
                                <select class="form-control dt-input dt-select select2" name="filter_assetCategory"
                                    id="AssetCategory" data-column="4" data-column-index="4">
                                    <option value=""><?php echo e(__('locale.select-option')); ?></option>
                                    <?php $__currentLoopData = $assetCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assetCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($assetCategory->name); ?>"><?php echo e($assetCategory->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                </div>

                </form>
            </div>
            <hr class="my-0" />
            <div class="card-datatable">
                <table class="dt-advanced-server-search table">
                    <thead>
                        <tr>
                            <th><?php echo e(__('locale.#')); ?></th>
                            <th><?php echo e(__('asset.AssetName')); ?></th>
                            <th><?php echo e(__('locale.IPAddress')); ?></th>
                            <th><?php echo e(__('locale.AssetValue')); ?></th>
                            <th><?php echo e(__('locale.AssetCategory')); ?></th>
                            <th><?php echo e(__('locale.AssetSiteLocation')); ?></th>
                            <th><?php echo e(__('locale.so')); ?></th>
                            <th><?php echo e(__('locale.AssetEnvironmentCategory')); ?></th>
                            <th><?php echo e(__('asset.owner_email')); ?></th>
                            <th><?php echo e(__('asset.model')); ?></th>
                            <th><?php echo e(__('locale.CreatedDate')); ?></th>
<th><?php echo e(__('locale.UpdatedDate')); ?></th>
                            <th><?php echo e(__('locale.VerifiedAssets')); ?></th>
                            <th><?php echo e(__('locale.Actions')); ?></th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th><?php echo e(__('locale.#')); ?></th>
                            <th><?php echo e(__('asset.AssetName')); ?></th>
                            <th><?php echo e(__('locale.IPAddress')); ?></th>
                            <th><?php echo e(__('locale.AssetValue')); ?></th>
                            <th><?php echo e(__('locale.AssetCategory')); ?></th>
                            <th><?php echo e(__('locale.AssetSiteLocation')); ?></th>
                            <th><?php echo e(__('locale.so')); ?></th>
                            <th><?php echo e(__('locale.AssetEnvironmentCategory')); ?></th>
                            <th><?php echo e(__('asset.owner_email')); ?></th>
                            <th><?php echo e(__('asset.model')); ?></th>
                            <th><?php echo e(__('locale.CreatedDate')); ?></th>
<th><?php echo e(__('locale.UpdatedDate')); ?></th>
                            <th><?php echo e(__('locale.VerifiedAssets')); ?></th>
                            <th><?php echo e(__('locale.Actions')); ?></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    </div>
</section><?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/components/admin/content/asset_management/asset/search.blade.php ENDPATH**/ ?>