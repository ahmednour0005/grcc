<div class="sidebar-menu-list">
    <div class="list-group list-group-filters">
        <div class="tab CategoryList" id="tabs">
            <?php $__currentLoopData = $assessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button class="list-group-item list-group-item-action tablinks sideNavBtn <?php echo e($loop->first ?'active':''); ?>"
                        data-name="<?php echo e($assessment->name); ?>" id="<?php echo e($assessment ->id); ?>">
                    <?php echo e($assessment->name); ?>

                </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>


    <div class="customPgination" style="width: 100px;margin: auto">
        <?php echo $assessments->links('vendor.pagination.simple-default'); ?>

        
        
        
        
    </div>


</div>
<?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/admin/content/assessment/paginated_data.blade.php ENDPATH**/ ?>