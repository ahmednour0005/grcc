<?php if($configData['mainLayoutType'] === 'horizontal' && isset($configData['mainLayoutType'])): ?>
    <nav class="header-navbar navbar-expand-lg navbar navbar-fixed align-items-center navbar-shadow navbar-brand-center <?php echo e($configData['navbarColor']); ?>"
        data-nav="brand-center">
        <div class="navbar-header d-xl-block d-none w-100 text-center" style="left: 0;right:0; z-index: 0">
            <a class="navbar-brand justify-content-center" href="<?php echo e(route('admin.dashboard')); ?>">
                <h2 class="brand-text mb-0">
                    <?php echo e(session()->get('locale') == 'ar' ? getSystemSetting('APP_OWNER_AR', 'اسم الشركة') : getSystemSetting('APP_OWNER_EN', 'Company Name')); ?>

                </h2>
            </a>
        </div>
    <?php else: ?>
        <nav
            class="header-navbar navbar navbar-expand-lg align-items-center <?php echo e($configData['navbarClass']); ?> navbar-light navbar-shadow <?php echo e($configData['navbarColor']); ?> <?php echo e($configData['layoutWidth'] === 'boxed' && $configData['verticalMenuNavbarType'] === 'navbar-floating' ? 'container-xxl' : ''); ?>">
<?php endif; ?>
<div class="navbar-container d-flex content">
    <div class="bookmark-wrapper d-flex align-items-center">
        <ul class="nav navbar-nav d-xl-none">
            <li class="nav-item"><a class="nav-link menu-toggle" href="javascript:void(0);"><i class="ficon"
                        data-feather="menu"></i></a></li>
        </ul>
        <ul class="nav navbar-nav bookmark-icons">
            <?php if(auth()->user()->hasPermission('task.list')): ?>
                <li class="nav-item d-none d-lg-block"><a class="nav-link" href="<?php echo e(route('admin.task.calendar')); ?>"
                        data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo e(__('locale.Calendar')); ?>"><i
                            class="ficon" data-feather="calendar"></i></a></li>
                <li class="nav-item d-none d-lg-block"><a class="nav-link"
                        href="<?php echo e(route('admin.task.assigned_to_me')); ?>" data-bs-toggle="tooltip"
                        data-bs-placement="bottom" title="Todo"><i class="ficon" data-feather="check-square"></i></a>
                </li>
            <?php endif; ?>
            <li class="nav-item d-none d-lg-block"><a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>"
                    data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo e(__('locale.Home')); ?>"><i
                        class="ficon" data-feather="home"></i></a></li>
        </ul>
    </div>
    <ul class="nav navbar-nav align-items-center ms-auto">

        <li class="nav-item dropdown dropdown-user">
            <a class="nav-link dropdown-toggle dropdown-user-link" id="dropdown-user" href="javascript:void(0);"
                data-bs-toggle="dropdown" aria-haspopup="true">
                <div class="user-nav d-sm-flex d-none">
                    <span class="selected-language">
                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(session()->has('locale')): ?>
                                <?php if(session()->get('locale') == $language): ?>
                                    <?php echo e(trans('locale.' . $name)); ?>

                                <?php endif; ?>
                            <?php else: ?>
                                <?php if(app()->getLocale() == $language): ?>
                                    <?php echo e(trans('locale.' . $name)); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </span>
                </div>

            </a>
            <div class="dropdown-menu dropdown-menu-end">

                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="dropdown-item" href="<?php echo e(url()->current() . '?lang=' . $language); ?>">
                        <?php echo e(trans('locale.' . $name)); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </li>



        <?php if(Auth::check()): ?>
            <li class="nav-item dropdown dropdown-notification me-25">
                <a class="nav-link" href="javascript:void(0);" data-bs-toggle="dropdown">
                    <i class="ficon" data-feather="bell"></i>
                    <span
                        class="badge rounded-pill bg-danger badge-up"><?php echo e($notificationsData['countUnreadNotification']); ?></span>
                </a>
                <ul class="dropdown-menu dropdown-menu-media dropdown-menu-end">
                    <li class="dropdown-menu-header">
                        <div class="dropdown-header d-flex">
                            <h4 class="notification-title mb-0 me-auto"><?php echo e(__('locale.Notifications')); ?></h4>
                            <div class="badge rounded-pill badge-light-primary">
                                <?php echo e($notificationsData['countNotification']); ?> <?php echo e(__('locale.ALL')); ?> </div>
                        </div>
                    </li>
                    <li class="scrollable-container media-list">
                        <?php $__currentLoopData = $notificationsData['notifications']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="d-flex  <?php echo e(notification_type($notification->is_read)); ?>"
                                id="notification<?php echo e($notification->id); ?>" href="javascript:void(0)"
                                link="<?php echo e(notification_meta($notification->meta, 'link')); ?>"
                                onclick="makeNotificationRead(<?php echo e($notification->id); ?>)">
                                <div class="list-item d-flex align-items-start">
                                    <div class="me-1">
                                        <div class="avatar">
                                            <img src="<?php echo e(asset('images/notification.png')); ?>" alt="avatar"
                                                width="32" height="32">
                                        </div>
                                    </div>
                                    <div class="list-item-body flex-grow-1">
                                        <p class="media-heading"><?php echo $notification->message; ?></p>
                                        <small class="notification-text"> <?php echo e($notification->created_at); ?></small>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </li>
                    <?php if($notificationsData['countNotification'] > 0): ?>
                        <li class="dropdown-menu-footer">
                            <a class="btn btn-primary w-100"
                                href="<?php echo e(route('notifications.more')); ?>"><?php echo e(__('locale.ReadAllNotifications')); ?> </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <li class="nav-item dropdown dropdown-user">
            <a class="nav-link dropdown-toggle dropdown-user-link" id="dropdown-user" href="javascript:void(0);"
                data-bs-toggle="dropdown" aria-haspopup="true">
                <div class="user-nav d-sm-flex d-none">
                    <span class="user-name fw-bolder">
                        <?php if(Auth::check()): ?>
                            <?php echo e(Auth::user()->name); ?>

                        <?php else: ?>
                            <?php echo e(session()->get('locale') == 'ar' ? getSystemSetting('APP_OWNER_AR', 'اسم الشركة') : getSystemSetting('APP_OWNER_EN', 'Company Name')); ?>

                        <?php endif; ?>
                    </span>
                    <span class="user-status">
                        <?php echo e(Auth::user()->role->name); ?>

                    </span>
                </div>
                
            </a>
            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdown-user">
                <h6 class="dropdown-header">Manage Profile</h6>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item"
                    href="<?php echo e(Route::has('admin.configure.userprofile.index') ? route('admin.configure.userprofile.index') : 'javascript:void(0)'); ?>">
                    <i class="me-50" data-feather="user"></i> Profile
                </a>
                
                

                

                
                <?php if(Auth::check()): ?>
                    <a class="dropdown-item" href="javascript:"
                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="me-50" data-feather="power"></i> Logout
                    </a>
                    <form method="POST" id="logout-form" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                    </form>
                <?php else: ?>
                    <a class="dropdown-item"
                        href="<?php echo e(Route::has('login') ? route('login') : 'javascript:void(0)'); ?>">
                        <i class="me-50" data-feather="log-in"></i> Login
                    </a>
                <?php endif; ?>
            </div>
        </li>
    </ul>
</div>
</nav>
<!-- END: Header-->
<?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/admin/panels/navbar.blade.php ENDPATH**/ ?>