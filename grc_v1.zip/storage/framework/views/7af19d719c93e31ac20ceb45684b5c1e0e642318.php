

<?php $__env->startSection('title', __('assessment.Questions')); ?>

<?php $__env->startSection('vendor-style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('fonts/fontawesome-6.2.1/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/toastr.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css'))); ?>">

    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/forms/select/select2.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/animate/animate.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/sweetalert2.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/editors/quill/quill.snow.css'))); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset(mix('vendors/css/forms/wizard/bs-stepper.min.css'))); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset(mix('css/base/plugins/forms/form-wizard.css'))); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-style'); ?>
    
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/base/plugins/extensions/ext-component-toastr.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css'))); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section>
        <div class="row">
            <div class="col-12">
                <div class="card">


                    <div class="card-header border-bottom p-1">
                        <div class="head-label">
                            <h4 class="card-title"><?php echo e(__('assessment.Questions')); ?></h4>
                        </div>
                        <div class="dt-action-buttons text-end">
                            <div class="dt-buttons d-inline-flex">


                                <button class="dt-button btn btn-primary me-2" type="button" data-bs-toggle="modal"
                                    data-bs-target="#addNewAnswer">
                                    <?php echo e(__('assessment.AnswerCreate')); ?>

                                </button>


                            </div>
                        </div>
                    </div>
                    <!--Search Form -->
                    <div class="card-body mt-2">

                        <?php echo e(__('assessment.Question')); ?>: <span class="text-warning"><?php echo e($question->question); ?></span>
                    </div>

                </div>
                <hr class="my-0" />
                <div class="card-datatable">
                    <table class="dt-advanced-server-search table text-center">
                        <thead>
                            <tr>
                                <th><?php echo e(__('#')); ?></th>
                                <th><?php echo e(__('assessment.Question')); ?></th>
                                <th><?php echo e(__('assessment.Answer')); ?></th>
                                <th><?php echo e(__('assessment.SubmitRisk')); ?></th>
                                <th><?php echo e(__('assessment.FailControl')); ?></th>
                                <th><?php echo e(__('assessment.MaturityControl')); ?></th>
                                <th><?php echo e(__('assessment.Actions')); ?></th>
                            </tr>
                        </thead>

                    </table>
                </div>
            </div>
        </div>
        </div>
    </section>

    <div class="modal fade" id="addNewAnswer" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-fullscreen" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <section class="modern-vertical-wizard">
                        <form action="<?php echo e(route('admin.answers.store', $question->id)); ?>" id="addNewAnswerForm"
                            method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="question_id" value="<?php echo e($question->id); ?>">
                            <div class="bs-stepper vertical wizard-modern modern-vertical-wizard-example">
                                <div class="bs-stepper-header">
                                    <div class="step" data-target="#answer" role="tab" id="answer-toggle">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box">
                                                <i data-feather="check-square" class="font-medium-3"></i>
                                            </span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title"><?php echo e(__('assessment.AnswerDetails')); ?></span>
                                                <span class="bs-stepper-subtitle"><?php echo e(__('assessment.AddAnswer')); ?></span>
                                            </span>
                                        </button>
                                    </div>
                                    <?php if($question->question_logic): ?>
                                        <div class="step" data-target="#question_logic" role="tab"
                                            id="question_logic_toggle">
                                            <button type="button" class="step-trigger">
                                                <span class="bs-stepper-box">
                                                    <i data-feather="alert-triangle" class="font-medium-3"></i>
                                                </span>
                                                <span class="bs-stepper-label">
                                                    <span
                                                        class="bs-stepper-title"><?php echo e(__('assessment.QuestionLogic')); ?></span>
                                                    <span
                                                        class="bs-stepper-subtitle"><?php echo e(__('assessment.AddQuestionLogic')); ?></span>
                                                </span>
                                            </button>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($question->risk_assessment): ?>
                                        <div class="step" data-target="#risk_assessment" role="tab"
                                            id="risk_assessment_toggle">
                                            <button type="button" class="step-trigger">
                                                <span class="bs-stepper-box">
                                                    <i data-feather="alert-triangle" class="font-medium-3"></i>
                                                </span>
                                                <span class="bs-stepper-label">
                                                    <span class="bs-stepper-title"><?php echo e(__('assessment.Risk')); ?></span>
                                                    <span
                                                        class="bs-stepper-subtitle"><?php echo e(__('assessment.SubmitRisk')); ?></span>
                                                </span>
                                            </button>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($question->compliance_assessment): ?>
                                        <div class="step" data-target="#compliance_assessment" role="tab"
                                            id="compliance_assessment_toggle">
                                            <button type="button" class="step-trigger">
                                                <span class="bs-stepper-box">
                                                    <i data-feather="alert-triangle" class="font-medium-3"></i>
                                                </span>
                                                <span class="bs-stepper-label">
                                                    <span
                                                        class="bs-stepper-title"><?php echo e(__('assessment.ComplianceAssessment')); ?></span>
                                                    
                                                </span>
                                            </button>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($question->maturity_assessment): ?>
                                        <div class="step" data-target="#maturity_assessment" role="tab"
                                            id="maturity_assessment_toggle">
                                            <button type="button" class="step-trigger">
                                                <span class="bs-stepper-box">
                                                    <i data-feather="alert-triangle" class="font-medium-3"></i>
                                                </span>
                                                <span class="bs-stepper-label">
                                                    <span
                                                        class="bs-stepper-title"><?php echo e(__('assessment.MaturityAssessment')); ?></span>
                                                    
                                                </span>
                                            </button>
                                        </div>
                                    <?php endif; ?>

                                </div>

                                <div class="bs-stepper-content">
                                    <div id="answer" class="content" role="tabpanel" aria-labelledby="answer-toggle">
                                        <div class="content-header">
                                            <h5 class="mb-0"><?php echo e(__('assessment.AnswerDetails')); ?></h5>
                                            <small class="text-muted"><?php echo e(__('assessment.AddAnswer')); ?></small>
                                        </div>

                                        <div class="row">
                                            <div class="mb-1 col-md-12">
                                                <label class="form-label"><?php echo e(__('assessment.Answer')); ?></label>
                                                <div class="create_answer"></div>
                                                <span class="error-answer error"></span>
                                            </div>
                                            <div class="mt-5"></div>

                                        </div>
                                    </div>

                                    <?php if($question->question_logic): ?>
                                        <div id="question_logic" class="content" role="tabpanel"
                                            aria-labelledby="question_logic_toggle">
                                            <div class="content-header">
                                                <h5 class="mb-0"><?php echo e(__('assessment.QuestionLogic')); ?></h5>
                                                <small><?php echo e(__('assessment.AddQuestionLogic')); ?></small>
                                            </div>

                                            <div class="row">
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label"
                                                        for="assessment_id"><?php echo e(__('assessment.Assessment')); ?></label>
                                                    <select name="sub_question_assessment_id" class="form-control select2"
                                                        id="assessment_id">
                                                        <option value=" ">----</option>
                                                        <?php $__currentLoopData = $data['assessments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($assessment->id); ?>"><?php echo e($assessment->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </select>
                                                </div>
                                                

                                                <div class="mb-1 col-md-12">
                                                    <div class="mb-2">
                                                        <button type="button"
                                                            class="btn btn-primary btn-sm select-all-btn"><?php echo e(__('locale.SelectAll')); ?></button>
                                                        <button type="button"
                                                            class="btn btn-primary btn-sm unselect-all-btn"><?php echo e(__('locale.UnSelectAll')); ?></button>
                                                    </div>
                                                    <label class="form-label"
                                                        for="sub_questions"><?php echo e(__('assessment.AssessmentSubQuestion')); ?></label>
                                                    <span class="text-success sub_questions_count">0 Selected</span>
                                                    <select name="sub_questions[]" class="form-control select2" multiple
                                                        id="sub_questions">
                                                        <?php $__currentLoopData = $data['questions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($sub_question->id); ?>">
                                                                <?php echo e($sub_question->question); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>

                                        </div>
                                    <?php endif; ?>
                                    <?php if($question->risk_assessment): ?>
                                        <div id="risk_assessment" class="content" role="tabpanel"
                                            aria-labelledby="risk_assessment_toggle">
                                            <div class="content-header">
                                                <h5 class="mb-0"><?php echo e(__('assessment.RiskAssessment')); ?></h5>
                                                <small><?php echo e(__('assessment.SubmitRisk')); ?></small>
                                            </div>

                                            <div class="row">
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label"
                                                        for="submit_risk"><?php echo e(__('assessment.SubmitRisk')); ?></label>
                                                    <input type="checkbox" id="submit_risk" name="submit_risk"
                                                        value="true">
                                                </div>
                                                <div class="mb-1 col-md-12 risk_details d-none">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <label
                                                                for="risk_subject"><?php echo e(__('assessment.Subject')); ?></label>
                                                            <input type="text" class="form-control"
                                                                name="risk_subject" id="risk_subject">
                                                        </div>
                                                    </div>
                                                    <div class="row mt-2">
                                                        <div class="col-md-4">
                                                            <label
                                                                for="assessment_scoring_id"><?php echo e(__('assessment.RiskScoringMethod')); ?></label>
                                                            <select name="risk_scoring_method_id"
                                                                id="assessment_scoring_id" class="form-control select2">
                                                                <?php $__currentLoopData = $data['riskScoringMethods']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($method->id); ?>">
                                                                        <?php echo e($method->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <label
                                                                for="current_likelihood_id"><?php echo e(__('assessment.CurrentLikelihood')); ?></label>
                                                            <select name="likelihood_id" id="current_likelihood_id"
                                                                class="form-control select2">
                                                                <?php $__currentLoopData = $data['likelihoods']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $likelihood): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($likelihood->id); ?>">
                                                                        <?php echo e($likelihood->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <label
                                                                for="impact_id"><?php echo e(__('assessment.CurrentImpact')); ?></label>
                                                            <select name="impact_id" id="impact_id"
                                                                class="form-control select2">
                                                                <?php $__currentLoopData = $data['impacts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $impact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($impact->id); ?>">
                                                                        <?php echo e($impact->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="row mt-2">
                                                        <div class="col-md-12">
                                                            <label for="owner_id"><?php echo e(__('assessment.Owner')); ?></label>
                                                            <select name="owner_id" id="owner_id"
                                                                class="form-control select2">
                                                                <?php $__currentLoopData = $data['enabledUsers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($user->id); ?>">
                                                                        <?php echo e($user->username); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="row mt-2">
                                                        <div class="col-md-12">
                                                            <label
                                                                for="affected_assets"><?php echo e(__('assessment.AffectedAssets')); ?></label>
                                                            <select name="assets_ids[]" id="affected_assets"
                                                                class="form-control select2" multiple>
                                                                <?php if(count($data['assetGroups'])): ?>
                                                                    <optgroup label="<?php echo e(__('assessment.AssetGroups')); ?>">
                                                                        <?php $__currentLoopData = $data['assetGroups']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assetGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($assetGroup->id); ?>_group">
                                                                                <?php echo e($assetGroup->name); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </optgroup>
                                                                <?php endif; ?>
                                                                <optgroup
                                                                    label="<?php echo e(__('assessment.Standards')); ?> <?php echo e(__('assessment.Assets')); ?>">
                                                                    <?php $__currentLoopData = $data['assets']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($asset->id); ?>_asset">
                                                                            <?php echo e($asset->name); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </optgroup>

                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="row mt-2">
                                                        <div class="col-md-12">
                                                            <label for="tags"><?php echo e(__('assessment.Tags')); ?></label>
                                                            <select name="tags_ids[]" id="tags"
                                                                class="form-control select2" multiple>
                                                                <?php $__currentLoopData = $data['tags']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($tag->id); ?>">
                                                                        <?php echo e($tag->tag); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="row mt-2">
                                                        <div class="col-md-12">
                                                            <label
                                                                for="migrationControls"><?php echo e(__('assessment.Controls')); ?></label>
                                                            <select name="framework_controls_ids" id="migrationControls"
                                                                class="form-control select2">
                                                                <?php $__currentLoopData = $data['migration_controls']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $control): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($control->id); ?>">
                                                                        <?php echo e($control->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    <?php endif; ?>
                                    <?php if($question->compliance_assessment): ?>
                                        <div id="compliance_assessment" class="content" role="tabpanel"
                                            aria-labelledby="compliance_assessment_toggle">
                                            <div class="content-header">
                                                <h5 class="mb-0"><?php echo e(__('assessment.ComplianceAssessment')); ?></h5>
                                                
                                            </div>

                                            <div class="row">
                                                <div class="mb-1 col-md-6 form-group">
                                                    <label class="form-label" for="fail_control">
                                                        <?php echo e(__('assessment.FailControl')); ?> </label>
                                                    <input type="checkbox" class="" name="fail_control"
                                                        value="true" id="fail_control">

                                                </div>

                                            </div>

                                        </div>
                                    <?php endif; ?>
                                    <?php if($question->maturity_assessment): ?>
                                        <div id="maturity_assessment" class="content" role="tabpanel"
                                            aria-labelledby="maturity_assessment_toggle">
                                            <div class="content-header">
                                                <h5 class="mb-0"><?php echo e(__('assessment.MaturityAssessment')); ?></h5>
                                                
                                            </div>

                                            <div class="row">
                                                <div class="mb-1 col-md-6">
                                                    <label class="form-label"
                                                        for="vertical-modern-google"><?php echo e(__('assessment.ControlMaturity')); ?></label>
                                                    <select name="maturity_control_id" id="control_maturity"
                                                        class="select2 form-control">
                                                        <option value=" ">---</option>
                                                        <?php $__currentLoopData = $data['maturity_controls']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $control): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($control->id); ?>"><?php echo e($control->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>

                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-label-secondary"
                                    data-bs-dismiss="modal"><?php echo e(__('locale.Close')); ?></button>
                                <button type="submit" class="btn btn-primary"><?php echo e(__('locale.SaveAnswer')); ?></button>
                            </div>
                        </form>
                    </section>


                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/buttons.print.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/forms/select/select2.full.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/extensions/sweetalert2.all.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/editors/quill/quill.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/forms/wizard/bs-stepper.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('js/scripts/forms/form-wizard.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/extensions/toastr.min.js'))); ?>"></script>
    <?php echo $__env->make('admin.content.partials._helperJs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <script>
        var quill = new Quill('.create_answer', {

            theme: 'snow'
        });
    </script>
    
    <script>
        let datatable_url = '<?php echo e(route('admin.answers.list', $question->id)); ?>'
        var answers_datatable = $('.dt-advanced-server-search').DataTable({
            lengthChange: true,
            processing: false,
            serverSide: true,
            ajax: {
                url: datatable_url,
                data: function(d) {
                    d.answer = $('input[name="filter_answer"]').val();
                }
            },
            language: {
                "sProcessing": "<?php echo e(__('locale.Processing')); ?>",
                "sSearch": "<?php echo e(__('locale.Search')); ?>",
                "sLengthMenu": "<?php echo e(__('locale.lengthMenu')); ?>",
                "sInfo": "<?php echo e(__('locale.info')); ?>",
                "sInfoEmpty": "<?php echo e(__('locale.infoEmpty')); ?>",
                "sInfoFiltered": "<?php echo e(__('locale.infoFiltered')); ?>",
                "sInfoPostFix": "",
                "sSearchPlaceholder": "",
                "sZeroRecords": "<?php echo e(__('locale.emptyTable')); ?>",
                "sEmptyTable": "<?php echo e(__('locale.NoDataAvailable')); ?>",
                "oPaginate": {
                    "sFirst": "",
                    "sPrevious": "<?php echo e(__('locale.Previous')); ?>",
                    "sNext": "<?php echo e(__('locale.NextStep')); ?>",
                    "sLast": ""
                },
                "oAria": {
                    "sSortAscending": "<?php echo e(__('locale.sortAscending')); ?>",
                    "sSortDescending": "<?php echo e(__('locale.sortDescending')); ?>"
                }
            },
            columns: [{
                    name: 'DT_RowIndex',
                    data: "DT_RowIndex",
                    searchable: false,
                    sortable: false,
                    orderable: false
                },
                {
                    name: 'question.question',
                    data: "question.question",
                    orderable: false,
                    sortable: false
                },
                {
                    name: 'answer',
                    data: "answer",
                    render: function(d) {
                        var template = document.createElement('div');
                        template.innerHTML = d;
                        return template.innerText || template.textContent || "";

                    }
                },
                {
                    name: 'submit_risk',
                    data: "submit_risk",
                    searchable: false,
                    render: function(d) {
                        var icon = '<i class="fa fa-close fa-sm text-danger"></i>';
                        if (d) {
                            icon = '<i class="fa fa-check text-success"></i>';
                        }
                        return icon;
                    }
                },
                {
                    name: 'fail_control',
                    data: "fail_control",
                    searchable: false,
                    render: function(d) {
                        var icon = '<i class="fa fa-close fa-sm text-danger"></i>';
                        if (d) {
                            icon = '<i class="fa fa-check text-success"></i>';
                        }
                        return icon;
                    }
                },

                {
                    name: 'maturity_control.name',
                    data: "maturity_control",
                    sortable: false,
                    orderable: false,
                    searchable: true,
                    render: function(d) {
                        var icon = '<i class="fa fa-close fa-sm text-danger"></i>';
                        if (d) {
                            icon = '<span class="text-success">' + d.name + '</span>';
                        }
                        return icon;
                    }

                },


                {
                    name: 'actions',
                    data: "actions",
                    searchable: false,
                    sortable: false,
                    orderable: false
                },
            ],
            columnDefs: [{}]
        });
        $('input[name="filter_answer"]').on('input', function() {
            answers_datatable.page(answers_datatable.page.info().page).draw('page');
        })
    </script>
    
    <script>
        function resetModalForm() {
            $('.modal form').find('form').trigger('reset');
            $('.modal form').find('select option:selected').prop('selected', false);
            $('.modal form').find('select').trigger('change');
            $('.modal form').find('input:checkbox:checked').prop('checked', false);
            $('.modal form').attr('id', 'addNewAnswerForm').removeAttr('data-url');
            $('.modal input[name="risk_subject"]').val('');
            quill.setText('');
            $('.risk_details').not('.d-none') ? $('.risk_details').addClass('d-none') : '';
            $('.step:first').find('button.step-trigger').trigger('click');
            $('.modal form').find('.error').empty();

        }

        $('.modal').on('hide.bs.modal', function() {
            resetModalForm();
        })
    </script>
    <script>
        var assesment_edit = null;
        $('#assessment_id').on('change', function(e) {
            assessment_id = $(this).val();
            url = "<?php echo e(route('admin.questions.fetch_questions_from_assessment')); ?>";
            $.ajax({
                type: "GET",
                url,
                data: {
                    assessment_id: assessment_id
                },
                success: function(response) {
                    $('#sub_questions').empty();
                    $.each(response, function(index, option) {
                        $('#sub_questions').append('<option value="' + option.id + '">' + option
                            .question + ' </option>');;
                    });
                },
                error: function(xhr) {

                }
            });

        });
        $(".select-all-btn").click(function() {
            $("#sub_questions").find("option").prop("selected", true);
            $("#sub_questions").trigger("change");
        });

        $(".unselect-all-btn").click(function() {
            $("#sub_questions").find("option").prop("selected", false);
            $("#sub_questions").trigger("change");
        });


        /* var that = $(this);
             $('#sub_questions option').each(function() {
                 if ($(this).data('assessment_id') == that.val()) {
                     $(this).prop('selected', true)
                 } else {
                     $(this).prop('selected', false)
                 }
             });
             $('#sub_questions').parents('div').find('.sub_questions_count').text($('#sub_questions option:selected')
                 .length + ' Selected');
             $('#sub_questions').trigger('change'); */

        $('#sub_questions').on('change', function() {
            $(this).parents('div').find('.sub_questions_count').text($('#sub_questions option:selected').length +
                ' Selected');
        })
    </script>

    
    <script>
        
        $('#addNewAnswerForm').on('submit', function(e) {
            e.preventDefault();
            if ($(this).is('#EditAnswerForm')) {
                return;
            }
            var url = $(this).attr('action');
            var data = new FormData(this);
            if (quill.getLength() == 1) {
                $('.error-answer').empty().append('Answer is Required').css('display', 'inline-block');
                makeAlert('error', "Answer Is Required", "<?php echo e(__('locale.Error')); ?>");
                return;
            }
            var answer = $('.create_answer .ql-editor').html();
            data.append('answer', answer);
            data.append('_token', '<?php echo e(csrf_token()); ?>');
            $.ajax({
                type: "POST",
                data: data,
                headers: {
                    'X-CSRF-TOKEN': $('meta[namee="csrf-token"]').attr('content')
                },
                processData: false,
                cache: false,
                contentType: false,
                success: function(response) {
                    answers_datatable.page(answers_datatable.page.info().page).draw('page');
                    Swal.fire({
                        title: "<?php echo e(__('Locale.Success')); ?>",
                        text: "<?php echo e(__('assessment.Answer Added successfully , Do you Want To Add  Another Answer ?')); ?>",
                        icon: 'question',
                        showCancelButton: true,
                        confirmButtonText: "<?php echo e(__('Locale.Yes')); ?>",
                        cancelButtonText: "<?php echo e(__('Locale.No')); ?>",
                        customClass: {
                            confirmButton: 'btn btn-relief-success ms-1',
                            cancelButton: 'btn btn-outline-danger ms-1'
                        },
                        buttonsStyling: false
                    }).then(function(result) {
                        if (result.value) {
                            resetModalForm();
                        } else {
                            $('.modal').modal('hide');
                        }
                    });


                },
                error: function(xhr) {
                    makeAlert('error', xhr.responseJSON[0], "<?php echo e(__('locale.Error')); ?>");
                }
            })
        });
        /* @Click  on Edit Button*/
        $(document).on('click', '.edit_answer_btn', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var url = $(this).data('url');

            $.ajax({
                type: "GET",
                url,
                success: function(answer) {
                    var form = $('.modal form');
                    $('.create_answer .ql-editor ').html(answer.answer);


                    if (answer.fail_control) {
                        $('input[name="fail_control"]').prop('checked', true);
                    }
                    if (answer.maturity_control_id) {
                        $('#control_maturity option[value="' + answer.maturity_control_id + '"]').prop(
                            'selected', true);
                        $('#control_maturity').trigger('change');
                    }
                    if (answer.sub_question_assessment_id) {
                        $('#assessment_id option[value="' + answer.sub_question_assessment_id + '"]')
                            .prop('selected', true);
                        $('#assessment_id').trigger('change.select2');
                    }
                    if (answer.sub_questions && answer.sub_questions.length > 0) {
                        var sub_questions = answer.sub_questions;
                        $.each(sub_questions, function(index, question) {
                            $('#sub_questions option[value="' + question.pivot.question_id +
                                '"]').prop('selected', true);
                        });
                        $('#sub_questions').trigger('change');
                    }

                    if (answer.submit_risk) {
                        $('#submit_risk').trigger('click');
                        $('#risk_subject').val(answer.risk_subject);
                        $('#assessment_scoring_id option[value="' + answer.risk_scoring_method_id +
                            '"]').prop('selected', true);
                        $('#current_likelihood_id option[value="' + answer.likelihood_id + '"]').prop(
                            'selected', true);
                        $('#impact_id option[value="' + answer.impact_id + '"]').prop('selected', true);
                        $('#owner_id option[value="' + answer.owner_id + '"]').prop('selected', true);
                        var assets_ids = JSON.parse(answer.assets_ids),
                            tags_ids = JSON.parse(answer.tags_ids),
                            framework_controls_ids = answer.framework_controls_ids;

                        $.each(assets_ids, function(index, asset_id) {
                            $('#affected_assets option[value="' + asset_id + '"]').prop(
                                'selected', true);
                        });
                        $.each(tags_ids, function(index, tag_id) {
                            $('#tags option[value="' + tag_id + '"]').prop('selected', true);
                        });

                        $('#migrationControls option[value="' + framework_controls_ids + '"]').prop(
                            'selected', true);

                        $('#assessment_scoring_id , #current_likelihood_id , #impact_id ,#owner_id, #affected_assets,#tags ,#migrationControls')
                            .trigger('change');
                    }

                    var edit_answer_form_url =
                        '<?php echo e(route('admin.answers.update', ['question' => $question->id, 'answer' => ':answer_id'])); ?>';
                    edit_answer_form_url = edit_answer_form_url.replace(':answer_id', answer.id);
                    form.attr('id', 'EditAnswerForm');
                    form.attr('data-url', edit_answer_form_url);
                    form.attr('action', edit_answer_form_url);

                },
                error: function(xhr) {

                }
            }).then(() => {
                $('#addNewAnswer').modal('show')
            })
        });
        /*on Update Answer*/
        $(document).on('submit', '#EditAnswerForm', function(e) {
            e.preventDefault();
            e.stopPropagation();

            var url = $(this).attr('action');
            var data = new FormData(this);
            var answer = $('.create_answer .ql-editor').html();
            data.append('_method', 'put');
            data.append('answer', answer);
            $.ajax({
                type: "POST",
                data: data,
                url: url,
                processData: false,
                cache: false,
                contentType: false,
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                },
                success: function(response) {
                    answers_datatable.page(answers_datatable.page.info().page).draw('page');
                    $('.modal').modal('hide');
                    makeAlert('success', response, 'Success')
                },
                error: function(xhr) {

                }
            })
        });
        
        $(document).on('click', '.delete_answer_btn', function(e) {

            e.preventDefault();
            var url = $(this).data('url');

            deleteRecord(url, callback);

            function callback(response) {
                makeAlert('success', response, "<?php echo e(__('locale.Success')); ?>");
                answers_datatable.page(answers_datatable.page.info().page).draw('page');

            };
        });
    </script>
    <script>
        /*on check/uncheck submit risk*/
        $('#submit_risk').on('click', function() {
            if ($(this).is(':checked')) {
                $('.risk_details').removeClass('d-none');
            } else {
                $('.risk_details').addClass('d-none');
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/admin/content/assessment/answers/index.blade.php ENDPATH**/ ?>