<!-- Risk Modal -->
<div class="modal fade" id="<?php echo e($id); ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-add-new-role">
        <div class="modal-content">
            <div class="modal-header bg-transparent">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body px-2 px-md-5 pb-3">
                <div class="text-center mb-4">
                    <h1 class="role-title"><?php echo e($title); ?></h1>
                </div>
                <!-- Risk form -->
                <form class="row" onsubmit="return false" enctype="multipart/form-data" >
                    <?php echo csrf_field(); ?>
                    <div class="col-12 mb-2">
                        <label class="form-label"><?php echo e(__('locale.Subject')); ?></label>
                        <input type="text" name="subject" class="form-control" tabindex="-1" required />
                        <span class="error error-subject"></span>
                    </div>
                    <div class="col-12">
                        
                        <div class="mb-1">
                            <label class="form-label "><?php echo e(__('report.RiskMapping')); ?></label>
                            <select name="risk_catalog_mapping_id[]" class="form-select multiple-select2"
                                multiple="multiple">
                                <?php $__currentLoopData = $riskGroupings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riskGrouping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <optgroup label="<?php echo e($riskGrouping->name); ?>">
                                        <?php $__currentLoopData = $riskGrouping->RiskCatalogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riskCatalog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($riskCatalog->id); ?>">
                                                <?php echo e($riskCatalog->number . ' - ' . $riskCatalog->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </optgroup>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="error error-risk_catalog_mapping_id"></span>
                        </div>
                        
                        <div class="mb-1">
                            <label class="form-label "><?php echo e(__('report.ThreatMapping')); ?></label>
                            <select name="threat_catalog_mapping_id[]" class="form-select multiple-select2"
                                multiple="multiple">
                                <?php $__currentLoopData = $threatGroupings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $threatGrouping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <optgroup label="<?php echo e($threatGrouping->name); ?>">
                                        <?php $__currentLoopData = $threatGrouping->ThreatCatalogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ThreatCatalog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($ThreatCatalog->id); ?>">
                                                <?php echo e($ThreatCatalog->number . ' - ' . $ThreatCatalog->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </optgroup>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="error error-threat_catalog_mapping_id"></span>
                        </div>
                    </div>

                    <div class="col-12 col-md-6">
                        
                        <div class="mb-1">
                            <label class="form-label "><?php echo e(__('report.Category')); ?></label>
                            <select class="select2 form-select" name="category_id">
                                <option value="" selected><?php echo e(__('locale.select-option')); ?></option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="error error-category_id"></span>
                        </div>
                        
                        <div class="mb-1">
                            <label class="form-label "><?php echo e(__('locale.SiteLocation')); ?></label>
                            <select class="form-select multiple-select2" name="location_id[]" multiple="multiple">
                                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($location->id); ?>"><?php echo e($location->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="error error-location_id"></span>
                        </div>
                        
                        <div class="mb-1">
                            <label class="form-label"><?php echo e(__('report.ExternalReferenceId')); ?></label>
                            <input type="text" name="reference_id" class="form-control dt-post"
                                aria-label="<?php echo e(__('report.ExternalReferenceId')); ?>" />
                            <span class="error error-reference_id "></span>
                        </div>
                        
                        <div class="mb-1">
                            <label class="form-label "><?php echo e(__('report.ControlRegulation')); ?></label>
                            <select class="select2 form-select" name="framework_id">
                                <option value="" selected><?php echo e(__('locale.select-option')); ?></option>
                                <?php $__currentLoopData = $frameworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $framework): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($framework->id); ?>"
                                        data-controls="<?php echo e(json_encode($framework->FrameworkControls)); ?>">
                                        <?php echo e($framework->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="error error-framework_id"></span>
                        </div>
                        
                        <div class="mb-1">
                            <label class="form-label "><?php echo e(__('report.ControlNumber')); ?></label>

                            <select class="select2 form-select" name="control_id">
                                <option value="" selected><?php echo e(__('locale.select-option')); ?></option>
                            </select>
                            <span class="error error-control_id"></span>
                        </div>
                        
                        <div class="mb-1">
                            <label class="form-label "><?php echo e(__('report.AffectedAssets')); ?></label>
                            <select name="affected_asset_id[]" class="form-select multiple-select2" multiple="multiple">
                                <?php if(count($assetGroups)): ?>
                                    <optgroup label="<?php echo e(__('risk.AssetGroups')); ?>">
                                        <?php $__currentLoopData = $assetGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assetGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($assetGroup->id); ?>_group"><?php echo e($assetGroup->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </optgroup>
                                <?php endif; ?>
                                <optgroup label="<?php echo e(__('locale.Standards')); ?> <?php echo e(__('report.Assets')); ?>">
                                    <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($asset->id); ?>_asset"><?php echo e($asset->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </optgroup>
                            </select>
                            <span class="error error-affected_asset_id"></span>
                        </div>
                        
                        <div class="mb-1">
                            <label class="form-label "><?php echo e(__('locale.Technology')); ?></label>
                            <select name="technology_id[]" class="form-select multiple-select2" multiple="multiple">
                                <?php $__currentLoopData = $technologies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technology): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($technology->id); ?>"><?php echo e($technology->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="error error-technology_id"></span>
                        </div>
                        
                        <div class="mb-1">
                            <label class="form-label "><?php echo e(__('locale.Team')); ?></label>
                            <select name="team_id[]" class="form-select multiple-select2" multiple="multiple">
                                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($team->id); ?>"><?php echo e($team->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="error error-team_id"></span>
                        </div>
                        
                        <div class="mb-1">
                            <label class="form-label "><?php echo e(__('locale.AdditionalStakeholders')); ?></label>
                            <select name="additional_stakeholder_id[]" class="form-select multiple-select2"
                                multiple="multiple">
                                <?php $__currentLoopData = $enabledUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $additionalStakeholder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($additionalStakeholder->id); ?>">
                                        <?php echo e($additionalStakeholder->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="error error-additional_stakeholder_id"></span>
                        </div>
                        
                        <div class="mb-1">
                            <label class="form-label "><?php echo e(__('locale.Owner')); ?></label>
                            <select class="select2 form-select" name="owner_id">
                                <option value="" selected><?php echo e(__('locale.select-option')); ?></option>
                                <?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($owner->id); ?>"
                                        data-manager="<?php echo e(json_encode($owner->manager)); ?>"><?php echo e($owner->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="error error-owner_id"></span>
                        </div>
                        
                        <div class="mb-1">
                            <label class="form-label "><?php echo e(__('locale.OwnersManager')); ?></label>
                            <select class="select2 form-select" name="owner_manager_id">
                                <option value="" selected><?php echo e(__('locale.select-option')); ?></option>
                            </select>
                            <span class="error error-owners_manager_id"></span>
                        </div>

                    </div>

                    <div class="col-12 col-md-6">
                        
                        <div class="mb-1">
                            <label class="form-label "><?php echo e(__('locale.ImpactScope')); ?></label>
                            <select class="select2 form-select" name="risk_source_id">
                                <option value="" selected><?php echo e(__('locale.select-option')); ?></option>
                                <?php $__currentLoopData = $riskSources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riskSource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($riskSource->id); ?>"><?php echo e($riskSource->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="error error-risk_source_id"></span>
                        </div>
                        
                        <div class="mb-1">
                            <label class="form-label "><?php echo e(__('report.RiskScoringMethod')); ?></label>
                            <select class="select2 form-select" name="risk_scoring_method_id">
                                <option value="" disabled hidden><?php echo e(__('locale.select-option')); ?></option>
                                <?php $__currentLoopData = $riskScoringMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riskScoringMethod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($riskScoringMethod->id); ?>"><?php echo e($riskScoringMethod->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="error error-risk_scoring_method_id"></span>
                        </div>
                        
                        <div class="mb-1">
                            <label class="form-label "><?php echo e(__('report.CurrentLikelihood')); ?></label>
                            <select class="select2 form-select" name="current_likelihood_id">
                                <option value="" disabled hidden selected><?php echo e(__('locale.select-option')); ?>

                                </option>
                                <?php $__currentLoopData = $riskLikelihoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riskLikelihood): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($riskLikelihood->id); ?>"><?php echo e($riskLikelihood->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="error error-current_likelihood_id"></span>
                        </div>
                        
                        <div class="mb-1">
                            <label class="form-label "><?php echo e(__('report.CurrentImpact')); ?></label>
                            <select class="select2 form-select" name="current_impact_id">
                                <option value="" disabled hidden selected><?php echo e(__('locale.select-option')); ?>

                                </option>
                                <?php $__currentLoopData = $impacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $impact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($impact->id); ?>"><?php echo e($impact->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="error error-current_impact_id"></span>
                        </div>
                        
                        <div class="mb-1">
                            <label class="form-label"><?php echo e(__('risk.ResponsiblePart')); ?></label>
                            <textarea class="form-control" name="risk_assessment" rows="3"></textarea>
                            <span class="error error-risk_assessment "></span>
                        </div>

                        <div class="mb-1">
                            <label class="form-label"><?php echo e(__("locale.KRI'S")); ?></label>
                            <div id="risk_addational_notes_submit">
                            </div>
                        </div>

                        
                        


                        
                        <div class="mb-1">
                            <label class="form-label"><?php echo e(__('locale.Description')); ?></label>
                            <textarea class="form-control" name="risk_description" rows="3"></textarea>
                            <span class="error error-risk_description "></span>
                        </div>
                        
                        <div class="mb-1">
                            <label class="form-label"><?php echo e(__('report.SupportingDocumentation')); ?></label>
                            <input type="file" multiple name="supporting_documentation[]"
                                class="form-control dt-post"
                                aria-label="<?php echo e(__('locale.SupportingDocumentation')); ?>" />
                            <span class="error error-supporting_documentation "></span>
                        </div>
                    </div>

                    <div class="col-6">
                        
                        <div class="mb-1">
                            <label class="form-label"> <?php echo e(__('report.Tags')); ?></label>
                            <select name="tags[]" class="form-select multiple-select2" multiple="multiple">
                                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->tag); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="error error-tags "></span>
                        </div>
                    </div>
                    <div class="col-12 text-center mt-2">
                        <button type="Submit" class="btn btn-primary me-1"> <?php echo e(__('locale.Submit')); ?></button>
                        <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                            <?php echo e(__('locale.Cancel')); ?></button>
                    </div>
                </form>
                <!--/ Risk form -->
            </div>
        </div>
    </div>
</div>
<!--/ Risk Modal -->
<?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/components/admin/content/risk-management/submit-risk/form.blade.php ENDPATH**/ ?>