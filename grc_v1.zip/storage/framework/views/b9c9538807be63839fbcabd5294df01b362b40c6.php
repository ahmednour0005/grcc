<!-- BEGIN: Footer-->
<footer class="footer footer-light <?php echo e(($configData['footerType'] === 'footer-hidden') ? 'd-none':''); ?> <?php echo e($configData['footerType']); ?>">
  <p class="clearfix mb-0">
    <span class="float-md-start d-block d-md-inline-block mt-25"><?php echo e(__('locale.COPYRIGHT')); ?> &copy;
      <script>document.write(new Date().getFullYear())</script><a class="ms-25" href="<?php echo e(getSystemSetting('APP_AUTHOR_WEBSITE', 'https://www.pksaudi.com/')); ?>" target="_blank">
        <?php echo e(session()->get('locale') == 'ar' ? getSystemSetting('APP_AUTHOR_ABBR_AR', 'Cyber Mode') : getSystemSetting('APP_AUTHOR_ABBR_EN', 'Cyber Mode')); ?>

        </a>,
      <span class="d-none d-sm-inline-block"><?php echo e(__('locale.All rights Reserved')); ?></span>
    </span>
    
  </p>
</footer>
<button class="btn btn-primary btn-icon scroll-top" type="button"><i data-feather="arrow-up"></i></button>
<!-- END: Footer-->
<?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/admin/panels/footer.blade.php ENDPATH**/ ?>