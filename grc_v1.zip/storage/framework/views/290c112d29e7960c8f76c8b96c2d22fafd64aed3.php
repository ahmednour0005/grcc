<?php
use App\Models\User;
?>

<ul class="dropdown-menu" data-bs-popper="none" style="max-height: 60vh; overflow-y: auto;">
    <?php if(isset($menu)): ?>
    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    
    <?php if(property_exists($submenu, 'route') && $submenu->route == "admin.change_request.index"): ?>
    <!-- Skip if user doesn't have department -->
    <?php if(!(User::whereNotNull('department_id')->where('id', auth()->id())->exists()) || !change_requests_responsible_department_manager_id()): ?>
    <?php continue; ?>
    <?php endif; ?>
    <?php endif; ?>
    
    <?php if((!(property_exists($submenu, 'permission_key') && $submenu->permission_key == '') && !(property_exists($submenu, 'permission_key') && in_array($submenu->permission_key, $permissions))) || !$submenu->showStatus || ($submenu->name == 'SetKPIAssessment' && !isDepartmentManager())): ?>
    <?php continue; ?>
    <?php endif; ?>
    <?php
    $custom_classes = "";
    if(isset($submenu->classlist)) {
    $custom_classes = $submenu->classlist;
    }
    ?>

    <li  class="<?php echo e($custom_classes); ?> <?php echo e((isset($submenu->submenu)) ? 'dropdown dropdown-submenu' : ''); ?>  <?php echo e(property_exists($submenu, 'route') && $submenu->route === Route::currentRouteName() ? 'active' : ''); ?>" <?php if(isset($submenu->submenu)): ?><?php echo e('data-menu=dropdown-submenu'); ?><?php endif; ?>>
        <a href="<?php echo e((isset($submenu->route) && !empty($submenu->route))? route($submenu->route):'javascript:void(0)'); ?>" class="dropdown-item <?php echo e((isset($submenu->submenu)) ? 'dropdown-toggle' : ''); ?> d-flex align-items-center" <?php echo e((isset($submenu->submenu)) ? 'data-bs-toggle=dropdown' : ''); ?> target="<?php echo e(isset($submenu->newTab) && $submenu->newTab === true  ? '_blank':'_self'); ?>">
            <?php if(isset($submenu->icon)): ?>
            <i data-feather="<?php echo e($submenu->icon); ?>"></i>
            <?php endif; ?>
            <span><?php echo e(__('locale.'.$submenu->name)); ?></span>
        </a>
        <?php if(isset($submenu->submenu)): ?>
        <?php echo $__env->make('admin.panels.horizontalSubmenu', ['menu' => $submenu->submenu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</ul>
<?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/admin/panels/horizontalSubmenu.blade.php ENDPATH**/ ?>