<div class="modal modal-slide-in basic-select2 fade bootstrap-select" id="<?php echo e($id); ?>">
    <div class="modal-dialog sidebar-sm">
        <form action="<?php echo e(route('admin.hierarchy.department.ajax.store')); ?>" method="POST" class="modal-content pt-0">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id">
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">×</button>
            <div class="modal-header mb-1">
                <h5 class="modal-title"><?php echo e($title); ?></h5>
            </div>
            <div class="modal-body flex-grow-1">
                
                <div class="mb-1">
                    <label class="form-label"><?php echo e(__('locale.Name')); ?></label>
                    <input type="text" name="name" class="form-control dt-post" aria-label="<?php echo e(__('locale.Name')); ?>" required />
                    <span class="error error-name "></span>
                </div>
                
                <div class="mb-1">
                    <label class="form-label"><?php echo e(__('locale.Code')); ?></label>
                    <input type="text" name="code" class="form-control dt-post" aria-label="<?php echo e(__('locale.}ode')); ?>" />
                    <span class="error error-code "></span>
                </div>
                
                
            
            <div class="mb-1">
                <label class="form-label "><?php echo e(__('locale.DepartmentColor')); ?></label>
                <select class="select2 form-select" name="color_id" required>
                    <option value="" disabled hidden selected><?php echo e(__('locale.select-option')); ?></option>
                    <?php $__currentLoopData = $departmentColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departmentColor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($departmentColor->id); ?>" data-color="<?php echo e($departmentColor->value); ?>"><?php echo e($departmentColor->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span class=" error error-color_id"></span>
            </div>
            
            <div class="mb-1">
                <label class="form-label "><?php echo e(__('locale.Manager')); ?></label>
                <select class="select2 form-select" name="manager_id">
                    <option value="" selected><?php echo e(__('locale.select-option')); ?></option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span class="error error-manager_id"></span>
            </div>
            
            <div class="mb-1">
                <label class="form-label "><?php echo e(__('locale.ParentDepartment')); ?></label>
                <select class="select2 form-select" name="parent_id">
                    <option value="" selected><?php echo e(__('locale.select-option')); ?></option>
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span class="error error-parent_id"></span>
            </div>
            
            <div class="mb-1">
                <label class="form-label"><?php echo e(__('locale.RequiredNumberOfEmplyees')); ?></label>
                <input type="number" min="1" name="required_num_emplyees" class="form-control dt-post" aria-label="<?php echo e(__('locale.RequiredNumberOfEmplyees')); ?>" />
                <span class="error error-required_num_emplyees "></span>
            </div>
            
            <div class="mb-1">
                <label class="form-label" for="exampleFormControlTextarea1"><?php echo e(__('locale.vision')); ?></label>
                <div id="<?php echo e($id); ?>-vision">
                    <textarea class="form-control" hidden name="vision" rows="3"></textarea>
                    <div class="editor">
                    </div>
                </div>
                <span class="error error-vision "></span>
            </div>
            
            <div class="mb-1">
                <label class="form-label" for="exampleFormControlTextarea1"><?php echo e(__('locale.message')); ?></label>
                <div id="<?php echo e($id); ?>-message">
                    <textarea class="form-control" hidden name="message" rows="3"></textarea>
                    <div class="editor">
                    </div>
                </div>
                <span class="error error-message "></span>
            </div>
            
            <div class="mb-1">
                <label class="form-label" for="exampleFormControlTextarea1"><?php echo e(__('locale.mission')); ?></label>
                <div id="<?php echo e($id); ?>-mission">
                    <textarea class="form-control" hidden name="mission" rows="3"></textarea>
                    <div class="editor">
                    </div>
                </div>
                <span class="error error-mission "></span>
            </div>
            
            <div class="mb-1">
                <label class="form-label" for="exampleFormControlTextarea1"><?php echo e(__('locale.objectives')); ?></label>
                <div id="<?php echo e($id); ?>-objectives">
                    <textarea class="form-control" hidden name="objectives" rows="3"></textarea>
                    <div class="editor">
                    </div>
                </div>
                <span class="error error-objectives "></span>
            </div>
            
            <div class="mb-1">
                <label class="form-label" for="exampleFormControlTextarea1"><?php echo e(__('locale.responsibilities')); ?></label>
                <div id="<?php echo e($id); ?>-responsibilities">
                    <textarea class="form-control" hidden name="responsibilities" rows="3"></textarea>
                    <div class="editor">
                    </div>
                </div>
                <span class="error error-responsibilities "></span>
            </div>

            <button type="Submit" class="btn btn-primary data-submit me-1"> <?php echo e(__('locale.Submit')); ?></button>
            <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                <?php echo e(__('locale.Cancel')); ?></button>
    </div>
    </form>
</div>
</div>
<?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/components/admin/content/hierarchy/department/form.blade.php ENDPATH**/ ?>