
<?php $__env->startSection('title', __('assessment.Assessments')); ?>

<style>
    .gov_btn {
        border-color: #0097a7 !important;
        background-color: #0097a7 !important;
        color: #fff !important;
        /* padding: 7px; */
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }

    .gov_check {
        padding: 0.786rem 0.7rem;
        line-height: 1;
        font-weight: 500;
        font-size: 1.2rem;
    }

    .gov_err {

        color: red;
    }

    .gov_btn {
        border-color: #0097a7;
        background-color: #0097a7;
        color: #fff !important;
        /* padding: 7px; */
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }

    .gov_btn_edit {
        border-color: #5388B4 !important;
        background-color: #5388B4 !important;
        color: #fff !important;
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }

    .gov_btn_map {
        border-color: #6c757d !important;
        background-color: #6c757d !important;
        color: #fff !important;
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }

    .gov_btn_delete {
        border-color: red !important;
        background-color: red !important;
        color: #fff !important;
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }
</style>

<?php $__env->startSection('vendor-style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('fonts/fontawesome-6.2.1/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/toastr.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/pickers/pickadate/pickadate.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css'))); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/forms/select/select2.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/toastr.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/base/plugins/extensions/ext-component-toastr.css'))); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/base/plugins/forms/pickers/form-flat-pickr.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/base/plugins/forms/pickers/form-flat-pickr.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/animate/animate.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/sweetalert2.min.css'))); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Advanced Search -->
    <section id="advanced-search-datatable">
        <div class="row">
            <div class="col-12">
                <div class="card">

                    <div class="card-header border-bottom p-1">
                        <div class="head-label">
                            <h4 class="card-title"><?php echo e(__('locale.Assessments')); ?></h4>
                        </div>
                        <div class="dt-action-buttons text-end">
                            <div class="dt-buttons d-inline-flex">
                                <?php if(auth()->user()->hasPermission('assessment.create')): ?>
                                    <button class="dt-button  btn btn-primary  me-2" type="button" data-bs-toggle="modal"
                                        data-bs-target="#add_questionnaire">
                                        <?php echo e(__('assessment.Add')); ?> <?php echo e(__('assessment.Assessment')); ?>

                                    </button>
                                    <a href="<?php echo e(route('admin.questionnaires.notificationsSettingsquestionnaire')); ?>"
                                        class="dt-button btn btn-primary me-2" target="_self">
                                        <?php echo e(__('locale.NotificationsSettings')); ?>

                                    </a>
                                <?php endif; ?>


                            </div>
                        </div>
                    </div>
                    <!--Search Form -->
                    <div class="card-body mt-2">
                        <form id="searchForm" class="dt_adv_search" method="POST">
                            <div class="row g-1 mb-md-1">
                                <div class="col-md-4">
                                    <label class="form-label"><?php echo e(__('locale.Assessment')); ?>:</label>
                                    <select class="form-control dt-input dt-select select2" name="assessment_id"
                                        id="assessmentFilter" data-column="2" data-column-index="2">
                                        <option value=""><?php echo e(__('locale.select-option')); ?></option>
                                        <?php $__currentLoopData = $assessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($assessment->id); ?>"><?php echo e($assessment->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                
                            </div>
                        </form>
                    </div>
                    <hr class="my-0" />
                    <div class="card-datatable table-responsive">
                        <table class="dt-advanced-server-search table">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('locale.#')); ?></th>

                                    <th class="all"><?php echo e(__('assessment.Name')); ?></th>
                                    <th class="all"><?php echo e(__('assessment.Assessment')); ?></th>

                                    <th class="all"><?php echo e(__('assessment.Contacts')); ?></th>
                                    <th class="all"><?php echo e(__('assessment.Actions')); ?></th>
                                </tr>
                            </thead>

                            <tfoot>
                                <tr>
                                    <th><?php echo e(__('locale.#')); ?></th>
                                    <th class="all"><?php echo e(__('assessment.Name')); ?></th>
                                    <th class="all"><?php echo e(__('assessment.Assessment')); ?></th>
                                    <th class="all"><?php echo e(__('assessment.Contacts')); ?></th>

                                    <th class="all"><?php echo e(__('assessment.Actions')); ?></th>
                                </tr>
                            </tfoot>

                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal modal-slide-in sidebar-todo-modal fade" id="add_questionnaire">
            <div class="modal-dialog sidebar-lg">
                <div class="modal-content p-0">
                    <form id="form-add_control" class="form-add_control todo-modal needs-validation" novalidate
                        method="POST" action="<?php echo e(route('admin.questionnaires.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="modal-header align-items-center mb-1">
                            <h5 class="modal-title"><?php echo e(__('assessment.Add')); ?> <?php echo e(__('assessment.Assessment')); ?></h5>
                            <div class="todo-item-action d-flex align-items-center justify-content-between ms-auto">
                                <span class="todo-item-favorite cursor-pointer me-75"><i data-feather="star"
                                        class="font-medium-2"></i></span>
                                <i data-feather="x" class="cursor-pointer" data-bs-dismiss="modal" stroke-width="3"></i>
                            </div>
                        </div>
                        <div class="modal-body flex-grow-1 pb-sm-0 pb-3">
                            <div class="action-tags">
                                <div class="mb-1">
                                    <label for="title" class="form-label"><?php echo e(__('assessment.Name')); ?></label>
                                    <input type="text" name="name" class=" form-control" placeholder=""
                                        required />
                                    <span class="error error-name "></span>

                                </div>

                                <div class="mb-1">
                                    <label for="instructions"
                                        class="form-label"><?php echo e(__('assessment.Instructions')); ?></label>
                                    <textarea class="form-control" name="instructions"></textarea>
                                    <span class="error error-instructions"></span>

                                </div>

                                <div class="mb-1">
                                    <label for="assessment_id"><?php echo e(__('locale.Assessments')); ?></label>
                                    <select class="form-control select2 " name="assessment_id" id="assessment_id">
                                        <option value="---" selected disabled><?php echo e(__('assessment.Assessment')); ?>

                                        </option>
                                        <?php $__currentLoopData = $assessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option data-questions="<?php echo e($assessment->questions); ?>"
                                                value="<?php echo e($assessment->id); ?>"><?php echo e($assessment->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>

                                <div class="mb-1">
                                    <label for="contacts"><?php echo e(__('assessment.Contacts')); ?></label>
                                    <select class="form-control select2" multiple name="contacts[]" id="contacts">
                                        <option value="---" disabled><?php echo e(__('assessment.Contacts')); ?></option>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->username); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>

                                <div class="mb-1">
                                    <label
                                        for="all_questions_mandatory"><?php echo e(__('assessment.all_questions_mandatory')); ?></label>
                                    <input type="checkbox" id="all_questions_mandatory" checked
                                        name="all_questions_mandatory">
                                </div>

                                <div class="question_logic d-none">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label for="percentage_checkbox"><?php echo e(__('percentage')); ?></label>
                                            <input type="checkbox" id="percentage_checkbox" value="1"
                                                class="checkbox" name="answer_percentage">
                                        </div>
                                        <div class="col-md-5 d-none percentage_number_div">

                                            <input type="number" class="form-control d-block" name="percentage_number"
                                                placeholder="Percentage Number">
                                        </div>


                                    </div>

                                    <div class="row">

                                        <div class="col-md-6">
                                            <label
                                                for="specific_questions"><?php echo e(__('assessment.specific_questions')); ?></label>
                                            <input type="checkbox" id="specific_questions" value="1"
                                                class="checkbox" name="specific_mandatory_questions">
                                        </div>
                                        <div class="col-md-12 specific_question_div d-none">
                                            <select class="form-control select2" multiple name="questions[]"
                                                id="questions">

                                            </select>
                                        </div>

                                    </div>

                                </div>

                            </div>

                            <div class="footer mt-2">
                                <button class="btn btn-primary btn-sm" type="submit"><?php echo e(__('locale.Save')); ?></button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('vendor-script'); ?>
    

    <script src="<?php echo e(asset('cdn/picker.js')); ?>"></script>
    <script src="<?php echo e(asset('cdn/picker.date.js')); ?>"></script>

    <script>
        var table = $('.dt-advanced-server-search').DataTable({
            lengthChange: true,
            processing: false,
            serverSide: true,
            ajax: {
                url: '<?php echo e(route('admin.questionnaires.data')); ?>'
            },
            language: {
                // ... your language settings
            },
            columns: [{
                    name: "DT_RowIndex",
                    data: "DT_RowIndex",
                    sortable: false,
                    searchable: false, // Set to false since this column is not searchable
                    orderable: false
                },
                {
                    name: "name",
                    data: "name"
                },
                {
                    name: "assessment_id", // Use the actual column name in your database
                    data: "assessment.name",
                    searchable: true
                },
                {
                    name: "contacts", // Specify the correct column name from your database
                    data: "contacts",
                    searchable: true,
                    orderable: false,
                    render: function(data) {
                        var contacts = '';
                        $.each(data, function(key, value) {
                            contacts += value.name + ',';
                        })
                        return contacts;
                    }
                },
                {
                    name: "actions",
                    data: "actions",
                    searchable: false // Set to false since this column is not searchable
                }
            ],
        });


        // Filter by index in assessment
        $('.dt-input').on('change', function() {
            var value = $(this).val();
            var columnIdx = $(this).data('column-index'); // Get the column index

            table
                .column(columnIdx)
                .search(value ? '^' + value + '$' : '', true, false)
                .draw();
        });

        // // Filter by contacts
        // $('.dt-inputcontact').on('change', function() {
        //     var value = $(this).val();
        //     var columnIdx = $(this).data('column-index'); // Get the column index

        //     table
        //         .column(columnIdx)
        //         .search(value ? value : '', true, false) // Use the actual value for filtering
        //         .draw();
        // });
    </script>

    <script>
        let swal_title = "<?php echo e(__('locale.AreYouSureToDeleteThisRecord')); ?>";
        let swal_text = '<?php echo app('translator')->get('locale.YouWontBeAbleToRevertThis'); ?>';
        let swal_confirmButtonText = "<?php echo e(__('locale.ConfirmDelete')); ?>";
        let swal_cancelButtonText = "<?php echo e(__('locale.Cancel')); ?>";
        let swal_success = "<?php echo e(__('locale.Success')); ?>";

        $('.select2').select2();

        function resetForm() {
            $('#add_questionnaire form').trigger('reset');
            $('.select2').trigger('change');
        }

        $('#add_questionnaire').on('hidden.bs.modal', function() {
            resetForm();
        });
        $('#all_questions_mandatory').on('change', function() {
            if (!$(this).is(':checked')) {
                $('.question_logic').removeClass('d-none');
            } else {
                $('.question_logic').addClass('d-none');
                $('.question_logic').find('input:checkbox').prop('checked', false);
                $('.question_logic').find('input[name="percentage_number"]').val('');
                $('#questions option:selected').prop('selected', false).trigger('change');
                $('.specific_question_div , .percentage_number_div').addClass('d-none');
            }
        });


        $('#specific_questions').on('change', function() {
            if ($(this).is(":checked")) {
                $('.specific_question_div').removeClass('d-none');
                $('#percentage_checkbox').prop('checked', false).trigger('change')

            } else {
                $('.specific_question_div').addClass('d-none');
                $('#questions option:selected').prop('selected', false).trigger('change');
                if ($('#percentage_checkbox:checked').length == 0) {
                    $('#all_questions_mandatory').prop('checked', true).trigger('change');
                }
            }
        });

        $('#percentage_checkbox').on('change', function() {
            if ($(this).is(':checked')) {
                $('.percentage_number_div').removeClass('d-none');
                $('#specific_questions').prop('checked', false).trigger('change');

            } else {

                $('input[name="percentage_number"]').val('');
                $('.percentage_number_div').addClass('d-none');
                if ($('#specific_questions:checked').length == 0) {
                    $('#all_questions_mandatory').prop('checked', true).trigger('change');
                }
            }
        });

        $('#assessment_id').on('change', function() {
            $('#questions').empty();
            let questions = $(this).find('option:selected').data('questions');
            var options = '';
            $.each(questions, function(key, val) {
                options += '<option value="' + val.id + '">' + val.question + '</option>';
            });
            $('#questions').append(options);
        });

        $('#add_questionnaire form').on('submit', function(e) {
            e.preventDefault();
            if ($(this).hasClass('update_questionnaire_modal')) {
                return 0;
            }
            var data = new FormData(this),
                url = $(this).attr('action');

            $.ajax({
                type: "post",
                url: url,
                data: data,
                cache: false,
                contentType: false,
                processData: false,
                beforeSend: function() {
                    $('.is-invalid').removeClass('is-invalid');
                },
                success: function(response) {
                    table.page(table.page.info().page).draw('page');
                    formReset();
                    $('.modal').modal('hide');
                    makeAlert('success', ('<?php echo e(__('assessment.Questionnaire added Successfully')); ?>'),
                        'Success');

                },
                error: function(xhr) {
                    $.each(xhr.responseJSON.errors, function(key, val) {
                        switch (key) {
                            case "contacts":
                                key = 'contacts[]'
                                break;
                            case "questions":
                                key = 'questions[]'
                                break;
                        }


                        makeAlert('error', val);
                        let input = $('input[name="' + key + '"] , textarea[name="' + key +
                            '"] , select[name="' + key + '"]')
                        input.addClass('is-invalid');
                    })
                }
            })
        });


        function formReset() {
            $('.modal form').trigger('reset');
            $('.modal form select').trigger('change');
            $('#question').addClass('d-none')

        }

        $('.modal').on('hidden.bs.modal', function() {
            $('.question_logic').addClass('d-none');
            $('.is-invalid').removeClass('is-invalid');
            $('#question').addClass('d-none');
            $('.update_questionnaire_modal').removeClass('update_questionnaire_modal');
        });

        function makeAlert($status, message, title) {
            // On load Toast
            if (title == 'Success')
                title = '👋' + title;
            toastr[$status](message, title, {
                closeButton: true,
                tapToDismiss: false
            });
        };

        var update_url;

        $(document).on('click', '.edit_questionnaire_btn', function(e) {
            var url = $(this).data('url');
            $.ajax({
                type: "get",
                url: url,
                success: function(response) {
                    update_url = '<?php echo e(route('admin.questionnaires.update', ':id')); ?>';
                    update_url = update_url.replace(':id', response.id);
                    $('.modal form').addClass('update_questionnaire_modal');
                    $('input[name="name"]').val(response.name);
                    $('textarea[name="instructions"]').val(response.instructions);
                    $('#assessment_id option[value="' + response.assessment_id + '"]').prop('selected',
                        true).trigger('change');
                    if (response.contacts != null) {
                        $.each(response.contacts, function(key, val) {
                            $('#contacts option[value="' + val.id + '"]').prop('selected', true)
                                .trigger('change');
                        })
                    }
                    if (response.all_questions_mandatory !== 1) {
                        $('#all_questions_mandatory').prop('checked', false).trigger('change');

                        if (response.answer_percentage === 1) {
                            $('#percentage_checkbox').prop('checked', true).trigger('change');
                            $('input[name="percentage_number"]').val(response.percentage_number)
                        }
                        if (response.specific_mandatory_questions === 1) {
                            $('#specific_questions').prop('checked', true).trigger('change');

                            if (response.questions != null) {
                                $.each(response.questions, function(key, val) {
                                    $('#questions option[value="' + val.id + '"]').prop(
                                        'selected', true);
                                });
                                $('#questions').trigger('change');
                            }

                        } else {
                            $('#specific_questions').prop('checked', false).trigger('change');
                        }
                    } else {
                        $('#all_questions_mandatory').prop('checked', true).trigger('change');
                    }

                }

            }).then(function() {
                $('#add_questionnaire').modal('show')
            })
        });


        $(document).on('submit', '.update_questionnaire_modal', function(e) {
            e.preventDefault();

            var data = new FormData(this);
            data.append('_method', 'put')
            $.ajax({
                type: "post",
                url: update_url,
                data: data,
                cache: false,
                contentType: false,
                processData: false,
                beforeSend: function() {
                    $('.is-invalid').removeClass('is-invalid');
                },
                success: function(response) {
                    table.page(table.page.info().page).draw('page');
                    formReset();
                    $('.modal').modal('hide');
                    makeAlert('success', ('<?php echo e(__('assessment.Questionnaire Updated Successfully')); ?>'),
                        'Success');

                },
                error: function(xhr) {
                    $.each(xhr.responseJSON.errors, function(key, val) {
                        switch (key) {
                            case "contacts":
                                key = 'contacts[]'
                                break;
                            case "questions":
                                key = 'questions[]'
                                break;
                        }


                        makeAlert('error', val);
                        let input = $('input[name="' + key + '"] , textarea[name="' + key +
                            '"] , select[name="' + key + '"]')
                        input.addClass('is-invalid');
                    })
                }
            })

        })


        //delete record
        $(document).on('click', '.delete_questionnaires_btn', function(e) {
            e.preventDefault();
            let url = $(this).data('url');
            Swal.fire({
                title: swal_title,
                text: swal_text,
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: swal_confirmButtonText,
                cancelButtonText: swal_cancelButtonText,
                customClass: {
                    confirmButton: 'btn btn-relief-success ms-1',
                    cancelButton: 'btn btn-outline-danger ms-1'
                },
                buttonsStyling: false
            }).then(function(result) {
                if (result.value) {
                    $.ajax({
                        type: "DELETE",
                        url: url,
                        headers: {
                            'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
                        },
                        success: function(response) {
                            makeAlert('success', (
                                '<?php echo e(__('assessment.Questionnaire Deleted Successfully')); ?>'
                            ), swal_success);
                            table.page(table.page.info().page).draw('page');

                        }
                    })
                }
            });


        })
    </script>

    
    <script>
        $(document).on('click', '.send_email_btn', function(e) {
            e.preventDefault();
            let url = $(this).data('url'),
                id = $(this).data('id');
            Swal.fire({
                title: "<?php echo e(__('assessment.Are You Sure You Want Send Email ?')); ?>",
                text: "<?php echo e(__('assessment.answers  will be replaced if exist !')); ?>",
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: "Yes",
                cancelButtonText: swal_cancelButtonText,
                customClass: {
                    confirmButton: 'btn btn-relief-success ms-1',
                    cancelButton: 'btn btn-outline-danger ms-1'
                },
                buttonsStyling: false
            }).then(function(result) {
                if (result.value) {
                    $.ajax({
                        type: "post",
                        url: url,
                        headers: {
                            'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
                        },
                        data: {
                            '_token': "<?php echo e(csrf_token()); ?>",
                            'questionnaire_id': id,
                        },
                        success: function(response) {
                            makeAlert('success', (
                                '<?php echo e(__('assessment.Questionnaire Send Successfully')); ?>'
                            ), swal_success);

                        },
                        error: function(response) {

                            Swal.fire({
                                icon: 'error',
                                title: '<?php echo e(__('assessment.Oops...')); ?>',
                                text: response.responseText,

                            })

                        }
                    })
                }
            });

        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/admin/content/assessment/questionnaires/index.blade.php ENDPATH**/ ?>