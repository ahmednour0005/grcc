

<?php $__env->startSection('title', __('governance.Define Controls')); ?>

<?php $__env->startSection('vendor-style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('fonts/fontawesome-6.2.1/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/toastr.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/pickers/pickadate/pickadate.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css'))); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/forms/select/select2.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/toastr.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/base/plugins/extensions/ext-component-toastr.css'))); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/base/plugins/forms/pickers/form-flat-pickr.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/base/plugins/forms/pickers/form-flat-pickr.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/animate/animate.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/sweetalert2.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/base/pages/app-chat.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/base/pages/app-chat-list.css'))); ?>">
<?php $__env->stopSection(); ?>


<style>
    .gov_btn {
        border-color: #0097a7 !important;
        background-color: #0097a7 !important;
        color: #fff !important;
        /* padding: 7px; */
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }

    .gov_check {
        padding: 0.786rem 0.7rem;
        line-height: 1;
        font-weight: 500;
        font-size: 1.2rem;
    }

    .gov_err {

        color: red;
    }

    .gov_btn {
        border-color: #0097a7;
        background-color: #0097a7;
        color: #fff !important;
        /* padding: 7px; */
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }

    .gov_btn_edit {
        border-color: #5388B4 !important;
        background-color: #5388B4 !important;
        color: #fff !important;
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }

    .gov_btn_map {
        border-color: #6c757d !important;
        background-color: #6c757d !important;
        color: #fff !important;
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }

    .gov_btn_delete {
        border-color: red !important;
        background-color: red !important;
        color: #fff !important;
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }

    #control_supplemental_guidance {
        height: 90px;
    }

    #control-guide-value {
        width: 364px;
        /* Set the width as per your requirement */
        height: 200px;
    }

    .ql-toolbar.ql-snow {
        width: 364px;
        /* Set the width as per your requirement */
    }
</style>
<?php $__env->startSection('content'); ?>


    <!-- Advanced Search -->
    <section id="advanced-search-datatable">
        <div class="row">
            <div class="col-12">
                <div class="card">

                    <div class="card-header border-bottom p-1">
                        <div class="head-label">
                            <h4 class="card-title"><?php echo e(__('governance.Controls')); ?></h4>
                        </div>
                        <div class="dt-action-buttons text-end">
                            <div class="dt-buttons d-inline-flex">
                                <?php if(auth()->user()->hasPermission('control.create')): ?>
                                    <button class="dt-button  btn btn-primary  me-2" type="button" data-bs-toggle="modal"
                                        data-bs-target="#add_control">
                                        <?php echo e(__('locale.Add')); ?> <?php echo e(__('governance.Control')); ?>

                                    </button>
                                    <a href="<?php echo e(route('admin.governance.notificationsSettingscontrol')); ?>"
                                        class="dt-button btn btn-primary me-2" target="_self">
                                        <?php echo e(__('locale.NotificationsSettings')); ?>

                                    </a>
                                <?php endif; ?>
                                <?php if(auth()->user()->hasPermission('audits.create')): ?>
                                    <button class="dt-button  btn btn-info  me-2" type="button"
                                        onclick="showModalInitiateAuditsForFrameworkControls()">
                                        <?php echo e(__('locale.Initiate Audits')); ?>

                                    </button>
                                <?php endif; ?>

                                <!-- Import and export container -->
                                <?php if (isset($component)) { $__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Export_Import::class, ['name' => ' '.e(__('governance.Control')).'','createPermissionKey' => 'control.create','exportPermissionKey' => 'control.export','exportRouteKey' => 'admin.governance.control.ajax.export','importRouteKey' => 'admin.governance.control.import']); ?>
<?php $component->withName('export-import'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180)): ?>
<?php $component = $__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180; ?>
<?php unset($__componentOriginal9a9d697028d9409877ce173fa7c92bad2d796180); ?>
<?php endif; ?>
                                <!--/ Import and export container -->
                            </div>
                        </div>
                    </div>
                    <!--Search Form -->
                    <div class="card-body mt-2">
                        <form class="dt_adv_search" method="POST">
                            <div class="row g-1 mb-md-1">
                                <!-- Name -->
                                <div class="col-md-4">
                                    <label class="form-label"><?php echo e(__('Name')); ?></label>
                                    <input class="form-control dt-input " name="filter_short_name" data-column="2"
                                        data-column-index="1" type="text">
                                </div>

                                <!-- framework -->
                                <div class="col-md-4">
                                    <label class="form-label"><?php echo e(__('governance.Framework')); ?></label>
                                    <select class="form-control dt-input dt-select select2 " name="filter_Frameworks"
                                        id="framework" data-column="4" data-column-index="3">
                                        <option value=""><?php echo e(__('locale.select-option')); ?></option>
                                        <?php $__currentLoopData = $frameworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $framework): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($framework['name']); ?>" data-id="<?php echo e($framework['id']); ?>">
                                                <?php echo e($framework['name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <!--  families -->
                                <div class="col-md-4 family-container">
                                    <label class="form-label"><?php echo e(__('governance.Domain')); ?></label>
                                    <select class="form-control dt-input dt-select select2 domain_select_filter"
                                        no_datatable_draw="true" name="filter_family_name" data-column="5"
                                        data-column-index="4">
                                        <option value=""><?php echo e(__('locale.select-option')); ?></option>
                                        <?php $__currentLoopData = $families; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($family->name); ?>"
                                                data-families="<?php echo e(json_encode($family->families)); ?>"><?php echo e($family->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                
                                <div class="col-md-4">
                                    <label class="form-label"><?php echo e(__('governance.sub_domain')); ?></label>
                                    <select class="form-control dt-input dt-select select2" name="filter_family_with_parent"
                                        data-column="6" data-column-index="5">
                                        <option value="" selected><?php echo e(__('locale.select-option')); ?></option>

                                    </select>
                                </div>
                                <!--  families -->
                                <!-- //Control Status -->
                                <div class="col-md-4">
                                    <label class="form-label "><?php echo e(__('locale.ControlStatus')); ?></label>
                                    <select class="select2 form-select" name="filter_control_status" data-column="7"
                                        data-column-index="6">
                                        <option value="" selected><?php echo e(__('locale.select-option')); ?></option>
                                        <option value="Not Applicable"> <?php echo e(__('locale.Not Applicable')); ?></option>
                                        <option value="Not Implemented"> <?php echo e(__('locale.Not Implemented')); ?></option>
                                        <option value="Partially Implemented"> <?php echo e(__('locale.Partially Implemented')); ?>

                                        </option>
                                        <option value="Implemented"> <?php echo e(__('locale.Implemented')); ?></option>
                                    </select>
                                    <span class="error error-filter_control_status"></span>
                                </div>
                            </div>

                        </form>
                    </div>
                    <hr class="my-0" />
                    <div class="card-datatable table-responsive">
                        <table class="dt-advanced-server-search table">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('locale.#')); ?></th>
                                    <th class="all"><?php echo e(__('locale.Name')); ?></th>
                                    <th class="all"><?php echo e(__('locale.Description')); ?></th>
                                    <th class="all"><?php echo e(__('governance.Framework')); ?></th>
                                    <th class="all"><?php echo e(__('governance.Domain')); ?></th>
                                    <th class="all"><?php echo e(__('governance.sub_domain')); ?></th>
                                    <th class="all"><?php echo e(__('governance.ControlStatus')); ?></th>
                                    <th class="all"><?php echo e(__('locale.Actions')); ?></th>
                                </tr>
                            </thead>

                            <tfoot>
                                <tr>
                                    <th><?php echo e(__('locale.#')); ?></th>
                                    <th class="all"><?php echo e(__('locale.Name')); ?></th>
                                    <th class="all"><?php echo e(__('locale.Description')); ?></th>
                                    <th class="all"><?php echo e(__('governance.Framework')); ?></th>
                                    <th class="all"><?php echo e(__('governance.Domain')); ?></th>
                                    <th class="all"><?php echo e(__('governance.sub_domain')); ?></th>
                                    <th class="all"><?php echo e(__('governance.ControlStatus')); ?></th>
                                    <th class="all"><?php echo e(__('locale.Actions')); ?></th>
                                </tr>
                            </tfoot>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- // add control modal -->
    <div class="modal modal-slide-in sidebar-todo-modal fade" id="add_control">
        <div class="modal-dialog sidebar-lg">
            <div class="modal-content p-0">
                <form id="form-add_control" class="form-add_control todo-modal" novalidate method="POST"
                    action="<?php echo e(route('admin.governance.control.store2')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="modal-header align-items-center mb-1">
                        <h5 class="modal-title"><?php echo e(__('locale.Add')); ?> <?php echo e(__('governance.Control')); ?></h5>
                        <div class="todo-item-action d-flex align-items-center justify-content-between ms-auto">
                            <span class="todo-item-favorite cursor-pointer me-75"><i data-feather="star"
                                    class="font-medium-2"></i></span>
                            <i data-feather="x" class="cursor-pointer" data-bs-dismiss="modal" stroke-width="3"></i>
                        </div>
                    </div>
                    <div class="modal-body flex-grow-1 pb-sm-0 pb-3">
                        <div class="action-tags">
                            <div class="mb-1">
                                <label for="title" class="form-label"><?php echo e(__('locale.Name')); ?></label>
                                <input type="text" name="name" class=" form-control" placeholder="" required />
                                <span class="error error-name "></span>

                            </div>

                            <div class="mb-1">
                                <label for="desc" class="form-label"><?php echo e(__('locale.Description')); ?></label>
                                <textarea class="form-control" name="description"></textarea>
                                <span class="error error-description"></span>

                            </div>
                            <div class="mb-1">
                                <label for="title" class="form-label"><?php echo e(__('governance.ControlNumber')); ?></label>
                                <input type="text" name="number" class=" form-control" placeholder="" />
                                <span class="error error-number "></span>

                            </div>

                            <!--  long_name -->
                            <div class="mb-1">
                                <label class="form-label" for="long_name"><?php echo e(__('governance.ControlLongName')); ?></label>
                                <input class="form-control" type="text" name="long_name">
                            </div>

                            <!--  framework -->
                            <div class="mb-1 framework-container">
                                <label class="form-label"><?php echo e(__('governance.Framework')); ?></label>
                                <select class="select2 form-select  add-control-framework-select" name="framework"
                                    required>
                                    <option value="" disabled selected><?php echo e(__('locale.select-option')); ?></option>
                                    <?php $__currentLoopData = $frameworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $framework): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($framework['id']); ?>"
                                            data-domains="<?php echo e(json_encode($framework['domains'])); ?>"
                                            data-controls="<?php echo e(json_encode($framework['controls'])); ?>">
                                            <?php echo e($framework['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="error error-framework"></span>
                            </div>

                            <!--  families -->
                            <div class="mb-1 family-container">
                                <label class="form-label" for="family"><?php echo e(__('governance.Domain')); ?></label>

                                <select class="select2 form-select domain_select" name="family" required>
                                    <option value="" disabled selected><?php echo e(__('locale.select-option')); ?></option>
                                </select>
                                <span class="error error-family"></span>
                            </div>

                            
                            <div class="mb-1">
                                <label class="form-label "><?php echo e(__('governance.sub_domain')); ?></label>

                                <select class="select2 form-select" name="sub_family" required>
                                    <option value="" disabled selected><?php echo e(__('locale.select-option')); ?></option>
                                </select>
                                <span class="error error-sub_family"></span>
                            </div>

                            
                            <div class="mb-1">
                                <label class="form-label "><?php echo e(__('governance.ParentControlFramework')); ?></label>
                                <select class="select2 form-select" name="parent_id">
                                    <option value="" selected><?php echo e(__('locale.select-option')); ?></option>
                                </select>
                                <span class="error error-parent_id"></span>
                            </div>

                            <!--  mitigation_guidance -->
                            <div class="mb-1">
                                <label class="form-label"
                                    for="mitigation_percent"><?php echo e(__('governance.mitigationpercent')); ?> </label>
                                <input class="form-control" type="text" name="mitigation_percent">
                            </div>

                            <!--  supplemental_guidance -->

                            <div class="mb-1">
                                <label class="form-label"><?php echo e(__('locale.ControlGuideImplementation')); ?></label>
                                <div id="control_supplemental_guidance">
                                </div>
                            </div>

                            
                            
                            

                            <div class="mb-1">
                                <label class="form-label" for="priority"> <?php echo e(__('governance.ControlPriority')); ?> </label>

                                <select class="select2 form-select" id="task-assigned" name="priority">
                                    <option value="">
                                        <?php echo e(__('governance.selectpriority')); ?>

                                    </option>
                                    <?php $__currentLoopData = $priorities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($priority->id); ?>">
                                            <?php echo e($priority->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="mb-1">
                                <label class="form-label" for="phase"><?php echo e(__('governance.ControlPhase')); ?> </label>

                                <select class="select2 form-select" id="task-assigned" name="phase">
                                    <option value="">
                                        <?php echo e(__('governance.selectphase')); ?>

                                    </option>
                                    <?php $__currentLoopData = $phases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($phase->id); ?>">
                                            <?php echo e($phase->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="mb-1">
                                <label class="form-label" for="type"><?php echo e(__('governance.ControlType')); ?> </label>

                                <select class="select2 form-select" id="task-assigned" name="type">
                                    <option value="">
                                        <?php echo e(__('governance.selectType')); ?>

                                    </option>
                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type->id); ?>">
                                            <?php echo e($type->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>


                            <div class="mb-1">
                                <label class="form-label" for="maturity"> <?php echo e(__('governance.ControlMaturity')); ?> </label>

                                <select class="select2 form-select" id="task-assigned" name="maturity">
                                    <option value="">
                                        <?php echo e(__('governance.selectmaturity')); ?>

                                    </option>
                                    <?php $__currentLoopData = $maturities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maturity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($maturity->id); ?>">
                                            <?php echo e($maturity->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>


                            <div class="mb-1">
                                <label class="form-label" for="class"> <?php echo e(__('governance.ControlClass')); ?> </label>

                                <select class="select2 form-select" id="task-assigned" name="class">
                                    <option value="">
                                        <?php echo e(__('governance.selectClass')); ?>

                                    </option>
                                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($class->id); ?>">
                                            <?php echo e($class->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>


                            <div class="mb-1">

                                <label class="form-label" for="desired_maturity">
                                    <?php echo e(__('governance.ControlDesiredMaturity')); ?> </label>
                                <select class="select2 form-select" id="task-assigned" name="desired_maturity">
                                    <option value=""> <?php echo e(__('governance.selectDesiredMaturity')); ?> </option>
                                    <?php $__currentLoopData = $desiredMaturities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desiredMaturity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($desiredMaturity->id); ?>"> <?php echo e($desiredMaturity->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>

                            <!-- //Control Status -->
                            

                            <!-- //owner -->
                            <div class="mb-1">

                                <label class="form-label" for="owner"> <?php echo e(__('governance.ControlOwner')); ?> </label>
                                <select class="select2 form-select" id="task-assigned" name="owner">
                                    <option value=""><?php echo e(__('governance.selectOwner')); ?> </option>
                                    <?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($owner->id); ?>"> <?php echo e($owner->name); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>



                            <!-- //add test start-->

                            <div class="mb-1">
                                <label class="form-label " for="select2-basic1"><?php echo e(__('locale.Tester')); ?></label>
                                <select class="select2 form-select" name="tester">
                                    <option value="" disabled selected><?php echo e(__('locale.select-option')); ?></option>
                                    <?php $__currentLoopData = $testers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tester->id); ?>"><?php echo e($tester->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                                <span class="error error-tester "></span>
                            </div>

                            

                            <!-- <div class="mb-1">
                                                                                                                                                                                                    <label class="form-label" for="additional_stakeholders"> AdditionalStakeholders </label>
                                                                                                                                                                                                    <select name="additional_stakeholders[]" class="form-select multiple-select2" id="additional_stakeholders" multiple="multiple">
                                                                                                                                                                                                      <option value=""> select-option </option>
                                                                                                                                                                                                       <?php $__currentLoopData = $testers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($tester->id); ?>"><?php echo e($tester->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                                                                                                                                                    </select>
                                                                                                                                                                                                    <span class="error error-additional_stakeholders" ></span>
                                                                                                                                                                                                  </div>
                                                                                                                                                                                                  <div class="mb-1">
                                                                                                                                                                                                    <label class="form-label" for="teams">  Teams </label>
                                                                                                                                                                                                    <select name="teams[]" class="form-select multiple-select2" id="teams" multiple="multiple">
                                                                                                                                                                                                      <option value="" >select teams </option>
                                                                                                                                                                                                       <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($team->id); ?>"><?php echo e($team->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                                                                                                                    </select>
                                                                                                                                                                                                    <span class="error error-teams " ></span>
                                                                                                                                                                                                  </div> -->
                            <div class="mb-1">
                                <label class="form-label" for="normalMultiSelect1"><?php echo e(__('locale.TestFrequency')); ?>

                                    (<?php echo e(__('locale.days')); ?>)</label>
                                <input name="test_frequency" type="number" min="0" class="form-control " />
                                <span class="error error-test_frequency "></span>
                            </div>
                            
                            <div class="mb-1">
                                <label class="form-label"
                                    for="exampleFormControlTextarea1"><?php echo e(__('locale.TestSteps')); ?></label>
                                <textarea class="form-control" name="test_steps" id="exampleFormControlTextarea1" rows="3"></textarea>
                                <span class="error error-test_steps "></span>
                            </div>
                            <div class="mb-1">
                                <label class="form-label" for="normalMultiSelect1"> <?php echo e(__('locale.ApproximateTime')); ?>

                                    (<?php echo e(__('locale.minutes')); ?>)</label>
                                <input name="approximate_time" type="number" min="0"
                                    id="basic-icon-default-post" class="form-control dt-post"
                                    aria-label="Web Developer" />
                                <span class="error error-approximate_time "></span>
                            </div>
                            <div class="mb-1">
                                <label class="form-label" for="exampleFormControlTextarea1">
                                    <?php echo e(__('locale.ExpectedResults')); ?></label>
                                <textarea class="form-control" name="expected_results" id="exampleFormControlTextarea1" rows="3"></textarea>
                                <span class="error error-expected_results"></span>
                            </div>

                            <!--add test end -->

                        </div>
                        <div class="my-1">
                            <button type="submit" class="btn btn-primary   add-todo-item me-1">Add</button>
                            <button type="button" class="btn btn-outline-secondary add-todo-item "
                                data-bs-dismiss="modal">
                                Cancel
                            </button>

                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- // edit control modal -->
    <div class="modal modal-slide-in sidebar-todo-modal fade" id="edit_contModal" role="dialog">
        <div class="modal-dialog sidebar-lg">
            <div class="modal-content p-0">


                <div class="modal-header align-items-center mb-1">
                    <h5 class="modal-title"><?php echo e(__('governance.UpdateControl')); ?></h5>
                    <div class="todo-item-action d-flex align-items-center justify-content-between ms-auto">
                        <span class="todo-item-favorite cursor-pointer me-75"><i data-feather="star"
                                class="font-medium-2"></i></span>
                        <i data-feather="x" class="cursor-pointer" data-bs-dismiss="modal" stroke-width="3"></i>
                    </div>
                </div>

                <form id="update_form" class="todo-modal needs-validation" novalidate method="POST"
                    action="<?php echo e(route('admin.governance.control.update')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="modal-body flex-grow-1 pb-sm-0 pb-3" id="form-modal-edit">

                    </div>


                </form>


            </div>
        </div>
    </div>

    <!-- // map control modal -->

    <div class="modal modal-slide-in sidebar-todo-modal fade" id="empModal" role="dialog">
        <div class="modal-dialog sidebar-lg">
            <div class="modal-content p-0">


                <div class="modal-header align-items-center mb-1">
                    <h5 class="modal-title"><?php echo e(__('governance.Mapping')); ?></h5>
                    <div class="todo-item-action d-flex align-items-center justify-content-between ms-auto">
                        <span class="todo-item-favorite cursor-pointer me-75"><i data-feather="star"
                                class="font-medium-2"></i></span>
                        <i data-feather="x" class="cursor-pointer" data-bs-dismiss="modal" stroke-width="3"></i>
                    </div>
                </div>

                <!-- <h3> Mapped Control Frameworks </h3> -->
                <div class="modal-body flex-grow-1 pb-sm-0 pb-3" id="form-modal-map">


                </div>




            </div>
        </div>
    </div>

    <!-- // List Objectives Modal -->

    <div class="modal modal-slide-in sidebar-todo-modal fade" id="objectiveModal" role="dialog">
        <div class="modal-dialog sidebar-lg" style="width:1200px">
            <div class="modal-content p-0">


                <div class="modal-header align-items-center mb-1">
                    <h5 class="modal-title"><?php echo e(__('governance.Requirements')); ?></h5>
                    <div class="todo-item-action d-flex align-items-center justify-content-between ms-auto">
                        <i data-feather="x" class="cursor-pointer" data-bs-dismiss="modal" stroke-width="3"></i>
                    </div>
                </div>

                <div class="modal-body flex-grow-1 pb-sm-0 pb-3">
                    <div>
                        <h3 style="display: inline-block"><?php echo e(__('governance.Control')); ?> :</h3>
                        <h3 style="display: inline-block" id="controlName"></h3>

                    </div>
                    <br>
                    <div id="objectivesList">

                    </div>
                    <br>
                    <div class="row">


                        <?php if(auth()->user()->hasPermission('control.add_objectives')): ?>
                            <div class="text-center col-md-6">
                                <button class="btn btn-success"
                                    id="addObjective"><?php echo e(__('governance.AddRequirement')); ?></button>
                            </div>
                        <?php endif; ?>
                        <div class="text-center col-md-6">
                            <button class="btn btn-primary"
                                id="controlguide"><?php echo e(__('locale.ControlGuideImplementation')); ?></button>
                        </div>
                    </div> <br>
                    <div id ="control-guide-value">

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- // Add Objective Modal -->

    <div class="modal fade" tabindex="-1" aria-hidden="true" id="addObjectiveModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-transparent">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body px-2 px-md-5 pb-3">
                    <div class="text-center mb-4">
                        <h1 class="role-title"><?php echo e(__('governance.AddRequirement')); ?></h1>
                    </div>
                    <!-- Evidence form -->
                    <form class="row addObjectiveToControlForm" onsubmit="return false" enctype="multipart/form-data">
                        <input type="hidden" name="control_id">
                        <input type="hidden" name="objective_adding_type" value="existing">
                        <?php echo csrf_field(); ?>
                        <div class="col-12 objective_id_container">
                            
                            <div class="mb-1">
                                <label class="form-label "><?php echo e(__('governance.Requirement')); ?></label>
                                <a href="javascript:;"
                                    onclick="showAddNewObjectiveInputs()"><?php echo e(__('governance.AddNewRequirement')); ?>?</a>
                                <select class="select2 form-select" name="objective_id">
                                    <option value="" selected><?php echo e(__('locale.select-option')); ?></option>
                                </select>
                                <span class="error error-objective_id"></span>
                                <span class="error error-control_id"></span>
                            </div>
                        </div>
                        <div class="col-12  objective_name_container" style="display: none;">
                            
                            <div class="mb-1">
                                <label class="form-label "><?php echo e(__('governance.RequirementName')); ?></label>
                                <a onclick="showSelectExistingObjectiveInputs()"
                                    href="javascript:;"><?php echo e(__('locale.SelectExistingRequirement')); ?>?</a>
                                <input type="text" class="form-control" name="objective_name" />
                                <span class="error error-objective_name"></span>
                                <span class="error error-control_id"></span>
                            </div>
                        </div>
                        <div class="col-12 objective_description_container" style="display: none;">
                            
                            <div class="mb-1">
                                <label class="form-label "><?php echo e(__('governance.RequirementDescription')); ?></label>
                                <textarea name="objective_description" class="form-control"></textarea>
                                <span class="error error-objective_description"></span>
                            </div>
                        </div>
                        <div class="col-12">
                            
                            <div class="mb-1">
                                <label for="title" class="form-label"><?php echo e(__('governance.ResponsibleType')); ?></label>
                                <div class="demo-inline-spacing">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="responsible_type"
                                            id="user" value="user" checked />
                                        <label class="form-check-label" for="user"><?php echo e(__('locale.User')); ?></label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="responsible_type"
                                            id="manager" value="manager" />
                                        <label class="form-check-label"
                                            for="manager"><?php echo e(__('locale.DepartmentManager')); ?></label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="responsible_type"
                                            id="team" value="team" />
                                        <label class="form-check-label" for="team"><?php echo e(__('locale.Team')); ?></label>
                                    </div>
                                </div>
                                <span class="error error-responsible_type"></span>
                            </div>
                        </div>
                        <div class="col-12">
                            
                            <div class="mb-1">
                                <label class="form-label "><?php echo e(__('locale.Responsible')); ?>

                                    <small>(<?php echo e(__('governance.ControlOwnerWillBeResponsibleIfYouDidntSelectOne')); ?>)</small></label>
                                <select class="select2 form-select" name="responsible_id">
                                    <option value="" selected><?php echo e(__('locale.select-option')); ?></option>
                                </select>
                                <span class="error error-responsible_id"></span>
                            </div>
                        </div>
                        <div class="col-12">
                            
                            <div class="mb-1">
                                <label class="form-label "><?php echo e(__('locale.DueDate')); ?></label>
                                <input name="due_date" class="form-control flatpickr-date-time-compliance"
                                    placeholder="YYYY-MM-DD" />
                                <span class="error error-due_date"></span>
                            </div>
                        </div>

                        <div class="col-12 text-center mt-2">
                            <button type="Submit" class="btn btn-primary me-1"> <?php echo e(__('locale.Submit')); ?></button>
                            <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                <?php echo e(__('locale.Cancel')); ?></button>
                        </div>
                    </form>
                    <!--/ Evidence form -->
                </div>
            </div>
        </div>
    </div>
    <!-- // edit objective Modal -->

    <div class="modal fade" tabindex="-1" aria-hidden="true" id="editObjectiveModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-transparent">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body px-2 px-md-5 pb-3">
                    <div class="text-center mb-4">
                        <h1 class="role-title"><?php echo e(__('locale.EditRequirement')); ?></h1>
                    </div>
                    <!-- edit objective form -->
                    <form class="row editObjectiveForm" onsubmit="return false" enctype="multipart/form-data">
                        <input type="hidden" name="control_control_objective_id">
                        <?php echo csrf_field(); ?>
                        <div class="col-12">
                            
                            <div class="mb-1">
                                <label for="title" class="form-label"><?php echo e(__('governance.ResponsibleType')); ?></label>
                                <div class="demo-inline-spacing">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="edited_responsible_type"
                                            id="edited_user" value="user" checked />
                                        <label class="form-check-label" for="user"><?php echo e(__('locale.User')); ?></label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="edited_responsible_type"
                                            id="edited_manager" value="manager" />
                                        <label class="form-check-label"
                                            for="manager"><?php echo e(__('locale.DepartmentManager')); ?></label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="edited_responsible_type"
                                            id="edited_team" value="team" />
                                        <label class="form-check-label" for="team"><?php echo e(__('locale.Team')); ?></label>
                                    </div>
                                </div>
                                <span class="error error-edited_responsible_type"></span>
                            </div>
                        </div>
                        <div class="col-12">
                            
                            <div class="mb-1">
                                <label class="form-label "><?php echo e(__('locale.Responsible')); ?>

                                    <small>(<?php echo e(__('governance.ControlOwnerWillBeResponsibleIfYouDidntSelectOne')); ?>)</small></label>
                                <select class="select2 form-select" name="edited_responsible_id">
                                    <option value="" selected><?php echo e(__('locale.select-option')); ?></option>
                                </select>
                                <span class="error error-edited_responsible_id"></span>
                            </div>
                        </div>
                        <div class="col-12">
                            
                            <div class="mb-1">
                                <label class="form-label "><?php echo e(__('locale.DueDate')); ?></label>
                                <input name="edited_due_date" class="form-control flatpickr-date-time-compliance"
                                    placeholder="YYYY-MM-DD" />
                                <span class="error error-edited_due_date"></span>
                            </div>
                        </div>

                        <div class="col-12 text-center mt-2">
                            <button type="Submit" class="btn btn-primary me-1"> <?php echo e(__('locale.Submit')); ?></button>
                            <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                <?php echo e(__('locale.Cancel')); ?></button>
                        </div>
                    </form>
                    <!--/ Edit Objective form -->
                </div>
            </div>
        </div>
    </div>

    <!-- // Add Evidence Modal -->

    <div class="modal fade" tabindex="-1" aria-hidden="true" id="addEvidenceModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-transparent">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body px-2 px-md-5 pb-3">
                    <div class="text-center mb-4">
                        <h1 class="role-title"><?php echo e(__('governance.AddEvidence')); ?></h1>
                    </div>
                    <!-- Evidence form -->
                    <form class="row addEvidenceToObjectiveForm" onsubmit="return false" enctype="multipart/form-data">
                        <input type="hidden" name="control_control_objective_id">
                        <?php echo csrf_field(); ?>
                        <div class="col-12">
                            
                            <div class="mb-1">
                                <label class="form-label "><?php echo e(__('governance.EvidenceDescription')); ?></label>
                                <input class="form-control" type="text" name="evidence_description">
                                <span class="error error-evidence_description"></span>
                            </div>
                        </div>
                        <div class="col-12">
                            
                            <div class="mb-1">
                                <label class="form-label"><?php echo e(__('governance.EvidenceFile')); ?></label>
                                <input type="file" name="evidence_file" class="form-control dt-post"
                                    aria-label="<?php echo e(__('locale.file')); ?>" />
                                <span class="error error-evidence_file "></span>
                            </div>
                        </div>

                        <div class="col-12 text-center mt-2">
                            <button type="Submit" class="btn btn-primary me-1"> <?php echo e(__('locale.Submit')); ?></button>
                            <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                <?php echo e(__('locale.Cancel')); ?></button>
                        </div>
                    </form>
                    <!--/ Evidence form -->
                </div>
            </div>
        </div>
    </div>

    <!-- // List Evidences Modal -->

    <div class="modal modal-slide-in sidebar-todo-modal fade" id="evidencesModal" role="dialog">
        <div class="modal-dialog sidebar-lg" style="width:1200px">
            <div class="modal-content p-0">


                <div class="modal-header align-items-center mb-1">
                    <h5 class="modal-title"><?php echo e(__('locale.Evidences')); ?></h5>
                    <div class="todo-item-action d-flex align-items-center justify-content-between ms-auto">
                        <i data-feather="x" class="cursor-pointer" data-bs-dismiss="modal" stroke-width="3"></i>
                    </div>
                </div>

                <div class="modal-body flex-grow-1 pb-sm-0 pb-3">
                    <div>
                        <h3 style="display: inline-block"><?php echo e(__('governance.Control')); ?> :</h3>
                        <h3 style="display: inline-block" id="evidenceControlName"> </h3>
                        <h3 style="display: inline-block"> / <?php echo e(__('governance.Requirement')); ?> :</h3>
                        <h3 style="display: inline-block" id="evidenceObjectiveName"></h3>

                    </div>
                    <br>
                    <div id="evidencesList">

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- // Edit Evidence Modal -->

    <div class="modal fade" tabindex="-1" aria-hidden="true" id="editEvidenceModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-transparent">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body px-2 px-md-5 pb-3">
                    <div class="text-center mb-4">
                        <h1 class="role-title"><?php echo e(__('governance.EditEvidence')); ?></h1>
                    </div>
                    <!-- Evidence form -->
                    <form class="row editEvidenceForm" onsubmit="return false" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input class="form-control" type="hidden" name="evidence_id">
                        <div class="col-12">
                            
                            <div class="mb-1">
                                <label class="form-label "><?php echo e(__('governance.EvidenceDescription')); ?></label>
                                <input type="text" class="form-control" name="edited_evidence_description">
                                <span class="error error-edited_evidence_description"></span>
                            </div>
                        </div>
                        <div class="col-12">
                            
                            <div class="mb-1">
                                <label class="form-label"><?php echo e(__('governance.EvidenceFile')); ?></label>

                                <input type="file" name="edited_evidence_file" class="form-control dt-post"
                                    aria-label="<?php echo e(__('locale.file')); ?>" />
                                <span class="error error-edited_evidence_file "></span>
                            </div>
                            <div class="mb-1 last_uploaded_file_container" style="display: hidden;">
                                <label class="form-label"><?php echo e(__('locale.LastUploadedFile')); ?></label>
                                <a class="badge bg-secondary last_uploaded_file cursor-pointer text-light"></a>
                            </div>
                        </div>

                        <div class="col-12 text-center mt-2">
                            <button type="Submit" class="btn btn-primary me-1"> <?php echo e(__('locale.Submit')); ?></button>
                            <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                <?php echo e(__('locale.Cancel')); ?></button>
                        </div>
                    </form>
                    <!--/ Evidence form -->
                </div>
            </div>
        </div>
    </div>
    <!-- // View Evidence Modal -->

    <div class="modal fade" tabindex="-1" aria-hidden="true" id="viewEvidenceModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-transparent">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body px-2 px-md-5 pb-3">
                    <div class="text-center mb-4">
                        <h1 class="role-title"><?php echo e(__('locale.ViewEvidence')); ?></h1>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            
                            <div class="mb-1">
                                <label class="form-label "><?php echo e(__('governance.EvidenceDescription')); ?></label>
                                <input class="form-control view_evidence_description" disabled>
                            </div>
                        </div>
                        <div class="col-12 view_evidence_file_container">
                            
                            <div class="mb-1">
                                <label class="form-label"><?php echo e(__('governance.EvidenceFile')); ?></label>
                                <a class="badge bg-secondary view_evidence_file cursor-pointer text-light"></a>
                            </div>
                        </div>

                        <div class="col-12">
                            
                            <div class="mb-1">
                                <label class="form-label "><?php echo e(__('locale.CreatedBy')); ?></label>
                                <input class="form-control view_evidence_created_by" disabled>

                            </div>
                        </div>
                        <div class="col-12">
                            
                            <div class="mb-1">
                                <label class="form-label "><?php echo e(__('locale.CreatedAt')); ?> </label>
                                <input class="form-control view_evidence_created_at" disabled>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- // Objective Comments Modal -->

    <div class="modal modal-slide-in sidebar-todo-modal fade" id="objectiveCommentsModal" role="dialog">
        <div class="modal-dialog sidebar-lg">
            <div class="modal-content p-0">


                <div class="modal-header align-items-center mb-1">
                    <h5 class="modal-title"><?php echo e(__('locale.Comments')); ?></h5>
                    <div class="todo-item-action d-flex align-items-center justify-content-between ms-auto">
                        <i data-feather="x" class="cursor-pointer" data-bs-dismiss="modal" stroke-width="3"></i>
                    </div>
                </div>

                <div class="modal-body flex-grow-1 pb-sm-0 pb-3">
                    <div id="chat-container">
                        <!-- Main chat area -->
                        <section class="chat-app-window">
                            <!-- To load Conversation -->

                            <!--/ To load Conversation -->
                            <!-- Active Chat -->
                            <?php if(auth()->user()->role->name == 'Administrator'): ?>
                            <div class="text-center mb-1">
                                <a  href="javascript:" class="btn btn-danger clearCommentsBtn" title="Clear Comments">
                                    <?php echo e(__('governance.ClearComments')); ?>

                                </a>
                            </div>
                            <?php endif; ?>
                            <div class="active-chat">
                                <!-- User Chat messages -->
                                <div class="user-chats">
                                    <div class="chats">
                                    </div>
                                </div>
                                <!-- User Chat messages -->
                                <p class="my-0 mx-2 file-name"
                                    data-content="<?php echo e(__('locale.FileName', ['name' => ''])); ?>">
                                </p>
                                <!-- Submit Chat form -->
                                <form class="chat-app-form" id="chat-app-form" action="javascript:void(0);"
                                    onsubmit="enterChat('#objectiveCommentsModal');">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="control_control_objective_id" />
                                    <div class="input-group input-group-merge me-1 form-send-message">
                                        <input type="text" class="form-control message" name ="comment"
                                            placeholder="<?php echo e(__('locale.TypeYourComment')); ?>" />
                                        <span class="input-group-text" title="hhhh">
                                            <label for="attach-doc" class="attachment-icon form-label mb-0">
                                                <i data-feather="file" class="cursor-pointer text-secondary"></i>
                                                <input name="comment_file" type="file" class="attach-doc"
                                                    id="attach-doc" hidden /> </label></span>
                                    </div>
                                    <button type="submit" class="btn btn-primary send">
                                        
                                        <i data-feather="send"></i>
                                        
                                    </button>
                                </form>
                                <!--/ Submit Chat form -->
                            </div>
                            <!--/ Active Chat -->
                        </section>
                        <!--/ Main chat area -->
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- // Group Audit Modal -->

    <div class="modal fade" tabindex="-1" aria-hidden="true" id="initiateAuditsForFrameworkControlsModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-transparent">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body px-2 px-md-5 pb-3">
                    <div class="text-center mb-4">
                        <h1 class="role-title"><?php echo e(__('locale.Initiate Audits')); ?></h1>
                    </div>
                    <!-- Evidence form -->
                    <form class="row initiateAuditsForFrameworkControlsForm" onsubmit="return false"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="col-12">
                            
                            <div class="mb-1">
                                <label class="form-label"><?php echo e(__('governance.Framework')); ?></label>
                                <select class="form-control dt-input dt-select select2 " name="audits_framework_id">
                                    <option value=""><?php echo e(__('locale.select-option')); ?></option>
                                    <?php $__currentLoopData = $frameworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $framework): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($framework['id']); ?>">
                                            <?php echo e($framework['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="error error-audits_framework_id"></span>
                            </div>
                        </div>

                        <div class="col-12 text-center mt-2">
                            <button type="Submit" class="btn btn-primary me-1"> <?php echo e(__('locale.Submit')); ?></button>
                            <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                <?php echo e(__('locale.Cancel')); ?></button>
                        </div>
                    </form>
                    <!--/ Evidence form -->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('vendor-script'); ?>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js'))); ?>"></script>
    
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/buttons.print.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/forms/select/select2.full.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/extensions/toastr.min.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/extensions/sweetalert2.all.min.js'))); ?>"></script>
    <script src="<?php echo e(asset('cdn/picker.js')); ?>"></script>
    <script src="<?php echo e(asset('cdn/picker.date.js')); ?>"></script>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
    <script src="<?php echo e(asset(mix('js/scripts/forms/form-select2.js'))); ?>"></script>
    <script>
        var permission = [],
            lang = [],
            URLs = [],
            user_id = <?php echo e(auth()->id()); ?>,
            customUserName =
            "<?php echo e(getFirstChartacterOfEachWord(auth()->user()->name, 2)); ?>";
        userName = "<?php echo e(auth()->user()->name); ?>";
        user_id = <?php echo e(auth()->id()); ?>, customUserName =
            "<?php echo e(getFirstChartacterOfEachWord(auth()->user()->name, 2)); ?>";
        userName = "<?php echo e(auth()->user()->name); ?>";
        URLs['ajax_list'] = "<?php echo e(route('admin.governance.ajax.get-list-control')); ?>";
        URLs['sendObjectiveComment'] = "<?php echo e(route('admin.governance.control.ajax.objective.sendComment')); ?>";
        URLs['downloadObjectiveCommentFile'] =
            "<?php echo e(route('admin.governance.control.ajax.objective.downloadCommentFile', '')); ?>";
        permission['edit'] = <?php echo e(auth()->user()->hasPermission('control.update')? 1: 0); ?>;
        permission['delete'] = <?php echo e(auth()->user()->hasPermission('control.delete')? 1: 0); ?>;
        permission['audits.create'] = <?php echo e(auth()->user()->hasPermission('audits.create')? 1: 0); ?>;
        permission['list_objectives'] = <?php echo e(auth()->user()->hasPermission('control.list_objectives')? 1: 0); ?>;

        lang['DetailsOfItem'] = "<?php echo e(__('locale.DetailsOfItem', ['item' => __('locale.department')])); ?>";
        lang['Edit'] = "<?php echo e(__('locale.Edit')); ?>";
        lang['Objective'] = "<?php echo e(__('governance.Requirement')); ?>";
        lang['Mapping'] = "<?php echo e(__('governance.Mapping')); ?>";
        lang['Delete'] = "<?php echo e(__('locale.Delete')); ?>";
        lang['Audit'] = "<?php echo e(__('governance.Audit')); ?>";
        lang['user'] = "<?php echo e(__('locale.User')); ?>"



        // edit control
        function editControl(data) {
            var url = "<?php echo e(route('admin.governance.ajax.edit_control', '')); ?>" + "/" + data;

            // AJAX request
            $.ajax({
                url: url,
                type: "GET",
                data: {},
                success: function(response) {
                    $('.dtr-bs-modal').modal('hide');
                    $('#edit_contModal').modal('show');
                    $('#form-modal-edit').html(response);

                    // Check if the element exists before creating the Quill instance
                    var quillContainer = document.getElementById('control_guide_implementation');
                    if (quillContainer) {
                        var quill = new Quill(quillContainer, {
                            theme: 'snow',
                            modules: {
                                toolbar: [
                                    [{
                                        'header': [1, 2, 3, 4, 5, 6, false]
                                    }],
                                    ['bold', 'italic', 'underline', 'strike'],
                                    [{
                                        'list': 'ordered'
                                    }, {
                                        'list': 'bullet'
                                    }],
                                    [{
                                        'indent': '-1'
                                    }, {
                                        'indent': '+1'
                                    }],
                                    [{
                                        'direction': 'rtl'
                                    }], // Right-to-left direction
                                    ['clean'],
                                ],
                            },
                        });

                        // Retrieve Quill content and set it in the hidden input


                        var quillContent = quill.root.innerHTML;
                        $('#supplemental_guidance_input').val(quillContent);
                    }

                    $('#form-modal-edit').find('.select2').select2();
                }
            });
        }

        // mapping


        function deleteControl(data) {
            var url = "<?php echo e(route('admin.governance.control.destroy', '')); ?>" + "/" + data;
            // AJAX request
            $.ajax({
                url: url,
                type: "GET",
                data: {},
                success: function(data) {
                    if (data.status) {
                        makeAlert('success', data.message, "<?php echo e(__('locale.Success')); ?>");
                        $('.dtr-bs-modal').modal('hide');
                        redrawDatatable();
                    }
                },
                error: function(response, data) {
                    responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "<?php echo e(__('locale.Error')); ?>");
                }
            });
        }


        function mapControl(data) {


            var url = "<?php echo e(route('admin.governance.ajax.get-list_control-map', '')); ?>" + "/" + data;

            // AJAX request
            $.ajax({
                url: url,
                type: "GET",
                data: {},
                success: function(response) {

                    $('#empModal').modal('show');
                    $('#form-modal-map').html(response);

                }
            });

        }



        function showControlObjectives(data) {
            var url = "<?php echo e(route('admin.governance.control.ajax.objective.get', '')); ?>" + "/" + data;

            // AJAX request
            $.ajax({
                url: url,
                type: "GET",
                data: {},
                success: function(response) {
                    control = response.control;
                    objectives = response.objectives;
                    $('#objectivesList').empty();
                    $('#controlName').html(control.short_name)
                    $('#addObjective').attr('onClick', 'showAddObjectiveForm(' + control.id + ');')
                    $('#controlguide').attr('onClick', 'getControlGuide(' + control.id + ');')
                    $('#control-guide-value').html('');
                    if (objectives.length) {
                        publishTableWithObjectives(objectives)
                    } else {
                        html = '<h4 style="text-align:center; color:red">No Requirements Yet<h4>'
                        $('#objectivesList').html(html);
                    }
                    $('#objectiveModal').modal('show');
                }
            });

        }

        function showEditObjectiveForm(controlControlObjectiveId) {
            var url = "<?php echo e(route('admin.governance.control.ajax.objective.editObjective', '')); ?>" + "/" +
                controlControlObjectiveId;
            $('[name="control_control_objective_id"]').val(controlControlObjectiveId)
            // AJAX request
            $.ajax({
                url: url,
                type: "GET",
                data: {},
                success: function(response) {
                    objective = response.objective;
                    responsibles = response.responsibles;
                    if (objective.responsible_type == 'user') {
                        $("input[name='edited_responsible_type'][value='user']").prop("checked", true);
                        responsibleId = objective.responsible_id
                    } else if (objective.responsible_type == 'manager') {
                        $("input[name='edited_responsible_type'][value='manager']").prop("checked", true);
                        responsibleId = objective.responsible_id
                    } else if (objective.responsible_type == 'team') {
                        $("input[name='edited_responsible_type'][value='team']").prop("checked", true);
                        responsibleId = objective.responsible_team_id
                    }
                    var responsiblesOptions =
                        '<option value="" selected><?php echo e(__('locale.select-option')); ?></option>';
                    $.each(responsibles, function(index, responsible) {
                        responsiblesOptions += '<option value="' + responsible.id + '" ' + (responsible
                                .id == responsibleId ? 'selected' : '') + '>' + responsible
                            .name + '</option>'
                    });
                    $('[name="edited_responsible_id"]').html(responsiblesOptions);

                    $('[name="edited_due_date"]').val(objective.due_date);
                    $('#editObjectiveModal').modal('show');
                }
            });
        }

        $('.editObjectiveForm').submit(function(e) {
            e.preventDefault();
            $('.error').empty();
            var url = "<?php echo e(route('admin.governance.control.ajax.objective.updateObjective')); ?>";
            $.ajax({
                url: url,
                type: 'POST',
                data: $('.editObjectiveForm').serialize(),
                success: function(data) {
                    if (data.status) {
                        objectives = data.data;
                        makeAlert('success', data.message, "<?php echo e(__('locale.Success')); ?>");
                        publishTableWithObjectives(objectives);
                        $('#editObjectiveModal').modal('hide');
                    } else {
                        showError(data['errors']);
                    }
                },
                error: function(response, data) {
                    responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "<?php echo e(__('locale.Error')); ?>");
                    showError(responseData.errors);
                }


            });

        });

        function showAddObjectiveForm(control_id) {

            showSelectExistingObjectiveInputs();
            var url = "<?php echo e(route('admin.governance.control.ajax.objective.getAll', '')); ?>" + "/" + control_id;
            $('[name="control_id"]').val(control_id);
            $("input[name='responsible_type'][value='user']").prop("checked", true);
            $("input[name='due_date']").val('');

            $('.error').empty();
            // AJAX request
            $.ajax({
                url: url,
                type: "GET",
                data: {},
                success: function(response) {

                    objectives = response.objectives;
                    users = response.users;
                    if (objectives.length) {
                        var objectivesOptions =
                            '<option value="" selected><?php echo e(__('locale.select-option')); ?></option>';
                        $.each(objectives, function(index, objective) {
                            objectivesOptions += '<option value="' + objective.id + '"' + (objective
                                    .disabled ? 'disabled' : '') + '>' + objective
                                .name + '</option>'
                        });
                        $('[name="objective_id"]').html(objectivesOptions);

                    }
                    if (users.length) {
                        var usersOptions =
                            '<option value="" selected><?php echo e(__('locale.select-option')); ?></option>';
                        $.each(users, function(index, user) {
                            usersOptions += '<option value="' + user.id + '">' + user
                                .name + '</option>'
                        });
                        $('[name="responsible_id"]').html(usersOptions);

                    }
                    $('#addObjectiveModal').modal('show');
                }
            });
        }


        function getControlGuide(control_id) {

            var url = "<?php echo e(route('admin.governance.control.ajax.objective.getControlGuide', '')); ?>" + "/" + control_id;
            var elementText = $('#control-guide-value').text();

            if ($.trim(elementText).length === 0) {


                $.ajax({
                    url: url,
                    type: "GET",
                    data: {},
                    success: function(response) {
                        $('#control-guide-value').html(response);
                    }
                });
            } else {
                // Element contains text
                $('#control-guide-value').html('');
            }
        }



        $('.addObjectiveToControlForm').submit(function(e) {
            e.preventDefault();
            $('.error').empty();
            var url = "<?php echo e(route('admin.governance.control.ajax.objective.addObjectiveToControl')); ?>";
            $.ajax({
                url: url,
                type: 'POST',
                data: $('.addObjectiveToControlForm').serialize(),
                success: function(data) {
                    if (data.status) {
                        objectives = data.data;
                        makeAlert('success', data.message, "<?php echo e(__('locale.Success')); ?>");
                        publishTableWithObjectives(objectives);
                        $('#addObjectiveModal').modal('hide');
                    } else {
                        showError(data['errors']);
                    }
                },
                error: function(response, data) {
                    responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "<?php echo e(__('locale.Error')); ?>");
                    showError(responseData.errors);
                }


            });

        });


        function showAddEvidenceForm(controlControlObjectiveId) {
            $('[name="control_control_objective_id"]').val(controlControlObjectiveId);
            $('#addEvidenceModal').modal('show');
        }

        $('.addEvidenceToObjectiveForm').submit(function(e) {
            var formData = new FormData(document.querySelector('.addEvidenceToObjectiveForm'));
            e.preventDefault();
            $('.error').empty();
            var url = "<?php echo e(route('admin.governance.control.ajax.objective.storeEvidence')); ?>";
            $.ajax({
                url: url,
                type: 'POST',
                contentType: false,
                processData: false,
                data: formData,
                success: function(data) {
                    if (data.status) {
                        makeAlert('success', data.message, "<?php echo e(__('locale.Success')); ?>");
                        $('#addEvidenceModal').modal('hide');
                        $('[name="control_control_objective_id"]').val('');
                        $('[name="evidence_description"]').val('');
                        $('[name="evidence_file"]').val('');

                    } else {
                        showError(data['errors']);
                    }
                },
                error: function(response, data) {
                    responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "<?php echo e(__('locale.Error')); ?>");
                    showError(responseData.errors);
                }


            });

        });

        function showEvidencesList(objectiveControlId) {
            var url = "<?php echo e(route('admin.governance.control.ajax.objective.getEvidences', '')); ?>" + "/" +
                objectiveControlId;

            // AJAX request
            $.ajax({
                url: url,
                type: "GET",
                data: {},
                success: function(response) {
                    controlName = response.control_name;
                    objectiveName = response.objective_name;
                    evidences = response.evidences;
                    canEditEvidences = response.can_edit_evidences
                    $('#evidencesList').empty();
                    $('#evidenceControlName').html(controlName)
                    $('#evidenceObjectiveName').html(objectiveName)
                    if (evidences.length) {
                        publishTableWithEvidences(evidences, canEditEvidences)
                    } else {
                        html = '<h4 style="text-align:center; color:red">No Evidences Yet<h4>'
                        $('#evidencesList').html(html);
                    }
                    $('#evidencesModal').modal('show');
                }
            });



        }

        function showEvidenceData(evidenceId) {
            var url = "<?php echo e(route('admin.governance.control.ajax.objective.getEvidence', '')); ?>" + "/" +
                evidenceId;

            // AJAX request
            $.ajax({
                url: url,
                type: "GET",
                data: {},
                success: function(response) {
                    evidence = response
                    const date = new Date(evidence.created_at);
                    // convert to local timezone
                    date.setTime(date.getTime() + date.getTimezoneOffset() * 60 * 1000);

                    // format date
                    const dateFormatted = date.toISOString().split('T')[0];
                    $('.view_evidence_description').val(evidence.description);
                    $('.view_evidence_created_by').val(evidence.created_by);
                    $('.view_evidence_created_at').val(dateFormatted);
                    if (evidence.file_name) {
                        $('.view_evidence_file').html(evidence.file_name);
                        $('.view_evidence_file').attr('onclick', 'downloadEvidenceFile(' + evidence.id + ')');
                        $('.view_evidence_file_container').show();
                    } else {
                        $('.view_evidence_file').html('');
                        $('.view_evidence_file').attr('onclick', '');
                        $('.view_evidence_file_container').hide();

                    }
                    $('#viewEvidenceModal').modal('show');
                }
            });
        }

        function showEditEvidenceForm(evidenceId) {
            var url = "<?php echo e(route('admin.governance.control.ajax.objective.getEvidence', '')); ?>" + "/" +
                evidenceId;

            // AJAX request
            $.ajax({
                url: url,
                type: "GET",
                data: {},
                success: function(response) {
                    evidence = response
                    $('[name="evidence_id"]').val(evidence.id);
                    $('[name="edited_evidence_description"]').val(evidence.description)
                    if (evidence.file_name) {
                        $('a.last_uploaded_file').html(evidence.file_name);
                        $('a.last_uploaded_file').attr('onclick', 'downloadEvidenceFile(' + evidence.id + ')');
                        $('.last_uploaded_file_container').show();
                    } else {
                        $('a.last_uploaded_file').html('');
                        $('a.last_uploaded_file').attr('onclick', '');
                        $('.last_uploaded_file_container').hide();

                    }
                    $('#editEvidenceModal').modal('show');
                }
            });
        }

        $('.editEvidenceForm').submit(function(e) {
            var formData = new FormData(document.querySelector('.editEvidenceForm'));
            e.preventDefault();

            $('.error').empty();
            var url = "<?php echo e(route('admin.governance.control.ajax.objective.updateEvidence')); ?>";
            $.ajax({
                url: url,
                type: 'POST',
                contentType: false,
                processData: false,
                data: formData,
                success: function(data) {
                    if (data.status) {
                        makeAlert('success', data.message, "<?php echo e(__('locale.Success')); ?>");
                        $('#editEvidenceModal').modal('hide');
                        $('[name="edited_evidence_description"]').val('');
                        $('[name="edited_evidence_file"]').val('');

                    } else {
                        showError(data['errors']);
                    }
                },
                error: function(response, data) {
                    responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "<?php echo e(__('locale.Error')); ?>");
                    showError(responseData.errors);
                }


            });

        });

        function downloadEvidenceFile(evidenceId) {
            var url = "<?php echo e(route('admin.governance.control.ajax.objective.downloadEvidenceFile', '')); ?>" + "/" +
                evidenceId;
            var link = document.createElement("a");
            link.href = url;
            link.style.display = "none";
            document.body.appendChild(link);

            link.click();

            // Cleanup
            document.body.removeChild(link);
        }




    </script>

    <script>
        function publishTableWithObjectives(objectives) {
            table = ''
            table += "<table width=100% class='table' >";
            table += "<tbody><tr> ";
            table += "<th>#</th> ";
            table += "<th>Requirement Name</th> ";
            table += "<th>Requirement Description</th> ";
            table += "<th>Responsible</th> ";
            table += "<th>Due Date</th> ";
            table += "<th style='width:25%;'>Evidences</th> ";
            table += "</tr>";
            $.each(objectives, function(index, objective) {
                listEvidencesButton =
                    '<a href="javascript:;" class="item-list" title="List Evidences" onclick="showEvidencesList(' +
                    objective.pivot.id + ')">' +
                    feather.icons["list"].toSvg({
                        class: "me-1 font-small-4",
                    }) +
                    "</a>";
                if (objective.canAddEvidence) {
                    addEvidenceButton =
                        '<a  href="javascript:;" class="item-edit" title="Add Evidence" onClick="showAddEvidenceForm(' +
                        objective.pivot.id + ')">' +
                        feather.icons["plus"].toSvg({
                            class: "me-1 font-small-4",
                        }) +
                        "</a>";
                } else {
                    addEvidenceButton = '';
                }
                canEditObjective = <?php echo e(auth()->user()->hasPermission('control.add_objectives')? 1: 0); ?>;
                if (canEditObjective) {
                    editObjectiveButton =
                        '<a  href="javascript:;" class="item-edit" title="Edit Requirement" onClick="showEditObjectiveForm(' +
                        objective.pivot.id + ')">' +
                        feather.icons["edit"].toSvg({
                            class: "me-1  font-small-4",
                        }) +
                        "</a>";
                } else {
                    editObjectiveButton = '';
                }
                canDeleteObjective = <?php echo e(auth()->user()->hasPermission('control.add_objectives')? 1: 0); ?>;
                if (canDeleteObjective) {
                    deleteObjectiveButton =
                        '<a  href="javascript:;" class="item-edit title="Delete Requirement" onClick="ShowModalDeleteObjective(' +
                        objective.pivot.id + ')">' +
                        feather.icons["trash-2"].toSvg({
                            class: "me-1 font-small-4",
                        }) +
                        "</a>";
                } else {
                    deleteObjectiveButton = '';
                }

                commentsButton =
                    '<a  href="javascript:;" class="item-edit title="Comments" onClick="showModalObjectiveComments(' +
                    objective.pivot.id + ')">' +
                    feather.icons["message-square"].toSvg({
                        class: "font-small-4",
                    }) +
                    "</a>";
                row = '<tr><td>' + (index + 1) + '</td><td>' + objective.name +
                    '</td><td>' + objective.description +
                    '</td><td>' + objective.responsible +
                    '</td><td>' + objective.due_date +
                    '</td><td>' + listEvidencesButton + addEvidenceButton + editObjectiveButton +
                    deleteObjectiveButton + commentsButton + '</td></tr>';
                table += row;
            });
            $('#objectivesList').html(table);
        }


        function publishTableWithEvidences(evidences, canEditEvidences = false) {
            table = ''
            table += "<table width=100% class='table' >";
            table += "<tbody><tr> ";
            table += "<th>#</th> ";
            table += "<th>Created By</th> ";
            table += "<th>Created At</th> ";
            table += "<th>actions</th> ";
            table += "</tr>";
            $.each(evidences, function(index, evidence) {
                showEvidencesButton =
                    '<a href="javascript:;" class="item-list " title="Show Evidence" onclick="showEvidenceData(' +
                    evidence.id + ')">' +
                    feather.icons["eye"].toSvg({
                        class: "me-1 font-small-4",
                    }) +
                    "</a>";
                if (canEditEvidences) {
                    editEvidenceButton =
                        '<a  href="javascript:;" class="item-edit "title="Edit Evidence" onClick="showEditEvidenceForm(' +
                        evidence.id + ')">' +
                        feather.icons["edit"].toSvg({
                            class: "me-50 font-small-4",
                        }) +
                        "</a>";
                } else {
                    editEvidenceButton = '';
                }

                if (canEditEvidences) {
                    deleteEvidenceButton =
                        '<a  href="javascript:;" class="item-edit "title=Delete Evidence" onClick="ShowModalDeleteEvidence(' +
                        evidence.id + ')">' +
                        feather.icons["trash-2"].toSvg({
                            class: "me-50 font-small-4",
                        }) +
                        "</a>";
                } else {
                    deleteEvidenceButton = '';
                }
                const date = new Date(evidence.created_at);

                // convert to local timezone
                date.setTime(date.getTime() + date.getTimezoneOffset() * 60 * 1000);

                // format date
                const dateFormatted = date.toISOString().split('T')[0];

                row = '<tr><td>' + (index + 1) + '</td><td>' + evidence.created_by +
                    '</td><td>' + dateFormatted +
                    '</td><td>' + showEvidencesButton + editEvidenceButton + deleteEvidenceButton + '</td></tr>';
                table += row;
            });
            $('#evidencesList').html(table);
        }

        function showAddNewObjectiveInputs() {
            $('.objective_name_container, .objective_description_container').show();
            $('.objective_id_container').hide();
            $('[name="objective_id"]').val('');
            $('[name="objective_adding_type"]').val('new');

        }

        function showSelectExistingObjectiveInputs() {
            $('.objective_id_container').show();
            $('.objective_name_container, .objective_description_container').hide();
            $('[name="objective_name"], [name="objective_description"]').val('');
            $('[name="objective_adding_type"]').val('existing');
        }


        $('[name="responsible_type"]').change(function(e) {
            var url = "<?php echo e(route('admin.governance.control.ajax.objective.getResponsibles')); ?>"
            var responsibleType = $('[name="responsible_type"]:checked').val();
            var csrfToken = $('meta[name="csrf-token"]').attr('content'); // Retrieve CSRF token from meta tag

            $.ajax({
                url: url,
                type: 'POST',
                data: {
                    responsible_type: responsibleType,
                    _token: csrfToken,
                },
                success: function(response) {
                    var responsibles = response;
                    var responsiblesOptions =
                        '<option value="" selected><?php echo e(__('locale.select-option')); ?></option>';
                    $.each(responsibles, function(index, responsible) {
                        responsiblesOptions += '<option value="' + responsible.id + '">' +
                            responsible
                            .name + '</option>'
                    });
                    $('[name="responsible_id"]').html(responsiblesOptions);

                },


            });

        });

        $('[name="edited_responsible_type"]').change(function(e) {
            var url = "<?php echo e(route('admin.governance.control.ajax.objective.getResponsibles')); ?>"
            var responsibleType = $('[name="edited_responsible_type"]:checked').val();
            var csrfToken = $('meta[name="csrf-token"]').attr('content'); // Retrieve CSRF token from meta tag

            $.ajax({
                url: url,
                type: 'POST',
                data: {
                    responsible_type: responsibleType,
                    _token: csrfToken,
                },
                success: function(response) {
                    var responsibles = response;
                    var responsiblesOptions =
                        '<option value="" selected><?php echo e(__('locale.select-option')); ?></option>';
                    $.each(responsibles, function(index, responsible) {
                        responsiblesOptions += '<option value="' + responsible.id + '">' +
                            responsible
                            .name + '</option>'
                    });
                    $('[name="edited_responsible_id"]').html(responsiblesOptions);

                },


            });

        });
    </script>
    <script>
        function formReset() {
            var form = $('.form-add_control')[0];
            form.reset();

            // Reset select elements to their default option
            $('.form-add_control select').each(function() {
                $(this).val($(this).find('option:first').val()); // Reset to the first option
            });
        }
        $('.form-add_control').submit(function(e) {
            e.preventDefault();
            $('.error').empty();

            // Retrieve Quill content
            var supplementalGuidance = quill.root.innerHTML;

            // Create a FormData object for the form
            var formData = new FormData(this);

            // Append Quill content to the FormData object
            formData.append('supplemental_guidance', supplementalGuidance);

            // Make the AJAX request
            $.ajax({
                url: $('.form-add_control').attr('action'),
                type: 'POST',
                data: formData, // Use the FormData object
                processData: false, // Important! Don't process the data
                contentType: false, // Important! Don't set content type
                success: function(data) {
                    if (data.status) {
                        makeAlert('success', data.message, "<?php echo e(__('locale.Success')); ?>");
                        redrawDatatable();
                        // Close the form after success
                        $('.form-add_control').closest('.modal').modal(
                            'hide'); // Assuming your form is within a modal
                        formReset();
                    } else {
                        showError(data.errors);
                    }
                },
                error: function(response, data) {
                    responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "<?php echo e(__('locale.Error')); ?>");
                    showError(responseData.errors);
                }
            });
        });




        $('#update_form').submit(function(e) {
            e.preventDefault();

            var quillContainer = document.getElementById('control_guide_implementation');
            if (quillContainer) {
                var quill = new Quill(quillContainer, {
                    theme: 'snow',
                    modules: {
                        toolbar: [
                            [{
                                'header': [1, 2, 3, 4, 5, 6, false]
                            }],
                            ['bold', 'italic', 'underline', 'strike'],
                            [{
                                'list': 'ordered'
                            }, {
                                'list': 'bullet'
                            }],
                            [{
                                'indent': '-1'
                            }, {
                                'indent': '+1'
                            }],
                            [{
                                'direction': 'rtl'
                            }], // Right-to-left direction
                            ['clean'],
                        ],
                    },
                });

                // Retrieve Quill content and set it in the hidden input


                var quillContent = quill.root.innerHTML;
                $('#supplemental_guidance_input').val(quillContent);
            }

            $.ajax({
                url: $('#update_form').attr('action'),
                type: 'POST',
                data: $('#update_form').serialize(),
                success: function(data) {
                    if (data.status) {
                        makeAlert('success', data.message, "<?php echo e(__('locale.Success')); ?>");
                        $('.dtr-bs-modal').modal('hide');
                        redrawDatatable();
                        $('#update_form').closest('.modal').modal(
                            'hide'); // Assuming your form is within a modal

                    } else {
                        showError(data['errors']);
                    }
                },
                error: function(response, data) {
                    responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "<?php echo e(__('locale.Error')); ?>");
                    showError(responseData.errors);
                }
            });

        });


        function showError(data) {
            $('.error').empty();
            $.each(data, function(key, value) {
                $('.error-' + key).empty();
                $('.error-' + key).append(value);
            });
        }

        // status [warning, success, error]
        function makeAlert($status, message, title) {
            // On load Toast
            if (title == 'Success')
                title = '👋' + title;
            toastr[$status](message, title, {
                closeButton: true,
                tapToDismiss: false,
            });
        }

        $('.multiple-select2').select2();

        function showModalInitiateAuditsForFrameworkControls() {
            $('#initiateAuditsForFrameworkControlsModal').modal('show');
        }

        function CreateAuditSellectAll() {
            var groupTestIds = $('input[name="audits[]"]:checked');
            if (groupTestIds.length <= 0) {
                makeAlert('error', "<?php echo e(__('governance.PleaseSelectOneTestAtLeast')); ?>", ' Error!');
            } else {
                var groupTestIdsString = '';
                groupTestIds.each(function() {
                    if ($(this).is(':checked')) {
                        groupTestIdsString = $(this).val() + ',' + groupTestIdsString;
                    }
                });
                showModalCreateAudit(groupTestIdsString);
            }
        }
        $('.initiateAuditsForFrameworkControlsForm').submit(function() {
            let url = "<?php echo e(route('admin.governance.audit.getFrameworkTests')); ?>";
            frameworkId = $('[name=audits_framework_id]').val()
            $.ajax({
                url: url,
                type: "POST",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: {
                    audits_framework_id: frameworkId
                },
                success: function(data) {
                    if (data.status) {
                        var groupTestIdsString = data.data
                        $('#initiateAuditsForFrameworkControlsModal').modal('hide');
                        showModalCreateAudit(groupTestIdsString);
                    } else {
                        showError(data['errors']);
                    }
                },
                error: function(response, data) {
                    // Display error alert if deletion fails
                    responseData = response.responseJSON;
                    showError(responseData['errors']);
                    makeAlert('error', responseData.message, "<?php echo e(__('locale.Error')); ?>");
                }
            });

        })

        function showModalCreateAudit(id) {
            let idAsString = (typeof id === 'string') ? id : id.toString();
            let count = idAsString.split(",").length;
            $('.dtr-bs-modal').modal('hide');

            Swal.fire({
                title: "<?php echo e(__('governance.InitiateAudit')); ?>",
                text: "<?php echo e(__('governance.YouWillConfrimInitiateAudit')); ?>" + " " + count + " " +
                    "<?php echo e(__('locale.Controls')); ?>",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: "<?php echo e(__('locale.Confrim')); ?>",
                customClass: {
                    confirmButton: 'btn btn-relief-success ms-1',
                    cancelButton: 'btn btn-outline-danger ms-1'
                },
                buttonsStyling: false
            }).then(function(result) {
                if (result.value) {
                    // Show loading overlay
                    $.blockUI({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="me-50 mb-0"><?php echo e(__('locale.PleaseWaitAction', ['action' => __('Initiate Audit')])); ?></p> <div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });

                    // Call CreateAuditTest
                    CreateAuditTest(id).then(() => {
                        // Function completed successfully
                        Swal.fire({
                            icon: "success",
                            title: "<?php echo e(__('governance.InitiateAudit')); ?> ",
                            text: "<?php echo e(__('governance.InitiateAuditSuccessfully')); ?>",
                            customClass: {
                                confirmButton: 'btn btn-success'
                            }
                        });
                    }).catch((error) => {
                        // Handle any errors from CreateAuditTest function
                        console.error(error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'There was an error initiating the audit'
                        });
                    }).finally(() => {
                        // Hide loading overlay after function completes (whether success or failure)
                        $.unblockUI();
                    });
                }
            });
        }

        // create  Audit for list of tests
// Create Audit for list of tests
function CreateAuditTest(id) {
    return new Promise((resolve, reject) => {
        let url = "<?php echo e(route('admin.governance.audit.store')); ?>";

        $.ajax({
            url: url,
            type: "GET",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: {
                id: id
            },
            success: function(data) {
                resolve(data); // Resolve the Promise with the data received
            },
            error: function(jqXHR, textStatus, errorThrown) {
                reject(errorThrown); // Reject the Promise with the error message
            }
        });
    });
}




        // $(document).ready(function() {


        //     'use strict'

        //     // Fetch all the forms we want to apply custom Bootstrap validation styles to
        //     var forms = document.querySelectorAll('form')
        //     // Loop over them and prevent submission
        //     Array.prototype.slice.call(forms)
        //         .forEach(function(form) {
        //             form.addEventListener('submit', function(event) {
        //                 if (!form.checkValidity()) {
        //                     event.preventDefault()
        //                     event.stopPropagation()
        //                 } else if (form.checkValidity() == true) {
        //                     // makeAlert('success', "created successfuly", "<?php echo e(__('locale.Success')); ?>");
        //                     // location.reload();

        //                     // stop form submit only for demo
        //                     // event.preventDefault();
        //                 }

        //                 form.classList.add('was-validated')


        //             }, false)
        //         })
        // });

        // Load subdomains of domain
        $(document).on('change', '.domain_select', function() {
            const subDomains = $(this).find('option:selected').data('families');
            const subDomainSelect = $(this).parents('.family-container').next().find('select');
            subDomainSelect.find('option:not(:first)').remove();
            if (subDomains)
                subDomains.forEach(subDomains => {
                    subDomainSelect.append(
                        `<option value="${subDomains.id}">${subDomains.name}</option>`
                    );
                });
            subDomainSelect.find('option').attr('selected', false);
            subDomainSelect.find('option:first').attr('selected', true);
        });

        $(document).on('change', '.add-control-framework-select', function() {
            const domains = $(this).find('option:selected').data('domains');
            const controls = $(this).find('option:selected').data('controls');
            const domainSelect = $(this).parents('.framework-container').next().find('select');
            const subDomainSelect = $(this).parents('.framework-container').next().next().find('select');
            const parentControlsSelect = $(this).parents('.framework-container').next().next().next().find(
                'select');

            // Add domains
            domainSelect.find('option:not(:first)').remove();
            if (domains)
                domains.forEach(domain => {
                    domainSelect.append(
                        `<option data-families='${JSON.stringify(domain.sub_domains)}' value="${domain.id}">${domain.name}</option>`
                    );
                });
            domainSelect.find('option').attr('selected', false);
            domainSelect.find('option:first').attr('selected', true);
            subDomainSelect.find('option:not(:first)').remove();
            subDomainSelect.find('option:first').attr('selected', true);

            // Add parent controls
            parentControlsSelect.find('option:not(:first)').remove();
            parentControlsSelect.find('option:first').attr('selected', true);
            if (controls)
                controls.forEach(control => {
                    parentControlsSelect.append(
                        `<option value="${control.id}">${control.name}</option>`
                    );
                });

            // Enable domain and sub-domain selects
            $('[name="family"]').prop('disabled', false);
            $('[name="sub_family"]').prop('disabled', false);
        })

        // Load subdomains of domain
        $(document).on('change', '.domain_select_filter', function() {
            const subDomains = $(this).find('option:selected').data('families');
            const subDomainSelect = $(this).parents('.family-container').next().find('select');
            subDomainSelect.find('option:not(:first)').remove();
            subDomainSelect.val('');
            subDomainSelect.trigger('change');
            subDomainSelect.find('option:first').attr('selected', true)
            if (subDomains)
                subDomains.forEach(subDomains => {
                    subDomainSelect.append(
                        `<option value="${subDomains.name}">${subDomains.name}</option>`
                    );
                });
        });

        $(document).ready(function() {
            $('.js-example-basic-multiple').select2();
            //datepicker start

            var $input = $('.js-datepicker').pickadate({
                format: 'yyyy-mm-dd',
                firstDay: 1,
                formatSubmit: 'yyyy-mm-dd',
                hiddenName: true,
                editable: true
            });

            var picker = {};


            // $('button').on('click', function(e) {
            //     e.stopPropagation();
            //     picker[$(e.target).data('i')].open();
            // });

            //datepicker end
        });

        $(document).on('change', '[name="parent_id"]', function() {
            if ($(this).val()) {
                $('[name="family"]').val('').trigger('change').prop('disabled', true);
                $('[name="sub_family"]').val('').trigger('change').prop('disabled', true);
            } else {
                $('[name="family"]').prop('disabled', false);
                $('[name="sub_family"]').prop('disabled', false);
            }
        });
    </script>

    <script>
        // Function to delete an objective via AJAX
        function DeleteObjective(id) {
            // Construct the URL for deleting the objective
            let url = "<?php echo e(route('admin.governance.control.ajax.objective.deleteObjective', ':id')); ?>";
            url = url.replace(':id', id);

            // AJAX request to delete the objective
            $.ajax({
                url: url,
                type: "DELETE",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(data) {
                    if (data.status) {
                        // Display success alert and update objectives list
                        makeAlert('success', data.message, "<?php echo e(__('locale.Success')); ?>");
                        objectives = data.objectives;
                        $('#objectivesList').empty();
                        if (objectives.length) {
                            publishTableWithObjectives(objectives);
                        } else {
                            html = '<h4 style="text-align:center; color:red">No Objectives Yet<h4>';
                            $('#objectivesList').html(html);
                        }
                        $('.dtr-bs-modal').modal('hide');
                    }
                },
                error: function(response, data) {
                    // Display error alert if deletion fails
                    responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "<?php echo e(__('locale.Error')); ?>");
                }
            });
        }

        // Function to show delete confirmation modal for an objective
        function ShowModalDeleteObjective(id) {
            // Display confirmation modal using SweetAlert
            $('.dtr-bs-modal').modal('hide');
            Swal.fire({
                title: "<?php echo e(__('locale.AreYouSureToDeleteThisRecord')); ?>",
                text: '<?php echo app('translator')->get('locale.YouWontBeAbleToRevertThis'); ?>',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: "<?php echo e(__('locale.ConfirmDelete')); ?>",
                cancelButtonText: "<?php echo e(__('locale.Cancel')); ?>",
                customClass: {
                    confirmButton: 'btn btn-relief-success ms-1',
                    cancelButton: 'btn btn-outline-danger ms-1'
                },
                buttonsStyling: false
            }).then(function(result) {
                if (result.value) {
                    // If confirmed, call the DeleteObjective function
                    DeleteObjective(id);
                }
            });
        }

        // Function to delete an evidence via AJAX
        function DeleteEvidence(id) {
            // Construct the URL for deleting the evidence
            let url = "<?php echo e(route('admin.governance.control.ajax.objective.deleteEvidence', ':id')); ?>";
            url = url.replace(':id', id);

            // AJAX request to delete the evidence
            $.ajax({
                url: url,
                type: "DELETE",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(data) {
                    if (data.status) {
                        // Display success alert and update evidences list
                        makeAlert('success', data.message, "<?php echo e(__('locale.Success')); ?>");
                        evidences = data.evidences;
                        canEditEvidences = data.can_edit_evidences;
                        $('#evidencesList').empty();
                        if (evidences.length) {
                            publishTableWithEvidences(evidences, canEditEvidences);
                        } else {
                            html = '<h4 style="text-align:center; color:red">No Evidences Yet<h4>';
                            $('#evidencesList').html(html);
                        }
                        $('.dtr-bs-modal').modal('hide');
                    }
                },
                error: function(response, data) {
                    // Display error alert if deletion fails
                    responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "<?php echo e(__('locale.Error')); ?>");
                }
            });
        }

        // Function to show delete confirmation modal for an evidence
        function ShowModalDeleteEvidence(id) {
            // Display confirmation modal using SweetAlert
            $('.dtr-bs-modal').modal('hide');
            Swal.fire({
                title: "<?php echo e(__('locale.AreYouSureToDeleteThisRecord')); ?>",
                text: '<?php echo app('translator')->get('locale.YouWontBeAbleToRevertThis'); ?>',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: "<?php echo e(__('locale.ConfirmDelete')); ?>",
                cancelButtonText: "<?php echo e(__('locale.Cancel')); ?>",
                customClass: {
                    confirmButton: 'btn btn-relief-success ms-1',
                    cancelButton: 'btn btn-outline-danger ms-1'
                },
                buttonsStyling: false
            }).then(function(result) {
                if (result.value) {
                    // If confirmed, call the DeleteEvidence function
                    DeleteEvidence(id);
                }
            });
        }
    </script>

    <script src="<?php echo e(asset('ajax-files/governance/controls/index.js')); ?>"></script>
    <script src="<?php echo e(asset('ajax-files/governance/controls/app-chat.js')); ?>"></script>

    <script>
        function showModalObjectiveComments(controlControlObjectiveId) {
            var url = "<?php echo e(route('admin.governance.control.ajax.objective.showComments', '')); ?>" + "/" +
                controlControlObjectiveId;
            $('[name="control_control_objective_id"]').val(controlControlObjectiveId);
            // AJAX request
            $.ajax({
                url: url,
                type: "GET",
                data: {},
                success: function(response) {
                    comments = response.data;
                    addMessageToChat(comments);
                    $('.clearCommentsBtn').attr('onclick','showModalClearComments('+controlControlObjectiveId+')')
                    $('#objectiveCommentsModal').modal('show');
                },
                error: function(response, data) {
                    responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "<?php echo e(__('locale.Error')); ?>");
                    showError(responseData.errors);
                }
            });

        }

                  // Function to show delete confirmation modal for an comments
            function showModalClearComments(id) {
            // Display confirmation modal using SweetAlert
            $('.dtr-bs-modal').modal('hide');
            Swal.fire({
                title: "<?php echo e(__('locale.AreYouSureToClearComments')); ?>",
                text: '<?php echo app('translator')->get('locale.YouWontBeAbleToRevertThis'); ?>',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: "<?php echo e(__('locale.ConfirmDelete')); ?>",
                cancelButtonText: "<?php echo e(__('locale.Cancel')); ?>",
                customClass: {
                    confirmButton: 'btn btn-relief-success ms-1',
                    cancelButton: 'btn btn-outline-danger ms-1'
                },
                buttonsStyling: false
            }).then(function(result) {
                if (result.value) {
                    // If confirmed, call the Delete Comments function
                    clearComments(id);
                }
            });
        }

        function clearComments(id) {
            // Construct the URL for deleting the comments
            let url = "<?php echo e(route('admin.governance.control.ajax.objective.clearComments', ':id')); ?>";
            url = url.replace(':id', id);

            // AJAX request to delete the objective
            $.ajax({
                url: url,
                type: "DELETE",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(data) {
                    if (data.status) {
                        // Display success alert and update comments list
                        makeAlert('success', data.message, "<?php echo e(__('locale.Success')); ?>");
                        $('.chats').empty();
                    }
                },
                error: function(response, data) {
                    // Display error alert if deletion fails
                    responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "<?php echo e(__('locale.Error')); ?>");
                }
            });
        }
    </script>
    <script>
        var quill = new Quill('#control_supplemental_guidance', {
            theme: 'snow',
            modules: {
                toolbar: [
                    [{
                        'header': [1, 2, 3, 4, 5, 6, false]
                    }],
                    ['bold', 'italic', 'underline', 'strike'],
                    [{
                        'list': 'ordered'
                    }, {
                        'list': 'bullet'
                    }],
                    [{
                        'indent': '-1'
                    }, {
                        'indent': '+1'
                    }],
                    [{
                        'direction': 'rtl'
                    }], // Right-to-left direction
                    ['clean'],
                ],
            },
        });

        // You can further customize the toolbar based on your specific needs
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\Pk\GRC Project\red hat version\grc\resources\views/admin/content/governance/control_list.blade.php ENDPATH**/ ?>