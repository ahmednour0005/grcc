<!-- Advanced Search -->
<section id="responsive-datatable">
    <div class="row">
        <div class="col-12">
            <div class="card">



                <div class="card-datatable">
                    <table class="dt-responsive table">
                        <thead>
                            <tr>
                                <th></th>
                                <th>{{ __('locale.ID') }}</th>
                                <th>{{ __('locale.User') }}</th>
                                <th>{{ __('locale.message') }}</th>
                                <th>{{ __('locale.CreatedDate') }}</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th></th>
                                <th>{{ __('locale.ID') }}</th>
                                <th>{{ __('locale.User') }}</th>
                                <th>{{ __('locale.message') }}</th>
                                <th>{{ __('locale.CreatedDate') }}</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<!--/ Advanced Search -->


